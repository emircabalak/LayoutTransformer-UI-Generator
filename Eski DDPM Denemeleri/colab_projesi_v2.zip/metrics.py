"""
metrics.py — Degerlendirme Metrikleri
IoU, Overlap Rate, Alignment Score, Constraint Violation Rate
"""
import numpy as np
from config import MAX_PANELS

def compute_iou(box_a, box_b):
    ix1=max(box_a[0],box_b[0]); iy1=max(box_a[1],box_b[1])
    ix2=min(box_a[2],box_b[2]); iy2=min(box_a[3],box_b[3])
    if ix1>=ix2 or iy1>=iy2: return 0.0
    inter=(ix2-ix1)*(iy2-iy1)
    a1=(box_a[2]-box_a[0])*(box_a[3]-box_a[1])
    a2=(box_b[2]-box_b[0])*(box_b[3]-box_b[1])
    union=a1+a2-inter
    return inter/union if union>0 else 0.0

def compute_overlap_rate(elements):
    if len(elements)<2: return 0.0
    total=0; overlapping=0
    for i in range(len(elements)):
        for j in range(i+1,len(elements)):
            total+=1
            if compute_iou(elements[i],elements[j])>0: overlapping+=1
    return overlapping/total

def compute_overlap_area_ratio(elements):
    if len(elements)<2: return 0.0
    total_area=sum(max((e[2]-e[0])*(e[3]-e[1]),0) for e in elements)
    overlap_area=0.0
    for i in range(len(elements)):
        for j in range(i+1,len(elements)):
            ix1=max(elements[i][0],elements[j][0]); iy1=max(elements[i][1],elements[j][1])
            ix2=min(elements[i][2],elements[j][2]); iy2=min(elements[i][3],elements[j][3])
            if ix1<ix2 and iy1<iy2: overlap_area+=(ix2-ix1)*(iy2-iy1)
    return overlap_area/total_area if total_area>0 else 0.0

def compute_alignment_score(elements, threshold=0.02):
    if len(elements)<2: return 1.0
    edges={"left":[],"right":[],"top":[],"bottom":[]}
    for e in elements:
        edges["left"].append(e[0]); edges["top"].append(e[1])
        edges["right"].append(e[2]); edges["bottom"].append(e[3])
    aligned=0; total=0
    for vals in edges.values():
        for i in range(len(vals)):
            total+=1
            for j in range(len(vals)):
                if i!=j and abs(vals[i]-vals[j])<threshold:
                    aligned+=1; break
    return aligned/total if total>0 else 1.0

def compute_constraint_violation_rate(panels, components):
    if not components or not panels: return 0.0
    violations=0
    for c in components:
        bbox=c["bbox"]; pidx=c["parent_idx"]
        if pidx<0 or pidx>=len(panels): violations+=1; continue
        p=panels[pidx]
        if bbox[0]<p[0]-0.01 or bbox[1]<p[1]-0.01 or bbox[2]>p[2]+0.01 or bbox[3]>p[3]+0.01:
            violations+=1
    return violations/len(components)

def evaluate_baseline_batch(samples):
    n=samples.shape[0]; ol=[]; oa=[]; al=[]
    for i in range(n):
        elems=[]
        for j in range(samples.shape[1]):
            e=samples[i,j]
            if e[1:5].sum().item()<0.01: continue
            elems.append([e[1].item(),e[2].item(),e[3].item(),e[4].item()])
        if elems:
            ol.append(compute_overlap_rate(elems))
            oa.append(compute_overlap_area_ratio(elems))
            al.append(compute_alignment_score(elems))
    return {"num_samples":n,
            "avg_overlap_rate":np.mean(ol) if ol else 0.0,"std_overlap_rate":np.std(ol) if ol else 0.0,
            "avg_overlap_area_ratio":np.mean(oa) if oa else 0.0,
            "avg_alignment_score":np.mean(al) if al else 0.0,"std_alignment_score":np.std(al) if al else 0.0}

def evaluate_hierarchical_batch(panels_t, components_t):
    n=panels_t.shape[0]; ol=[]; oa=[]; al=[]; vr=[]
    for i in range(n):
        pbboxes=[]
        for j in range(panels_t.shape[1]):
            p=panels_t[i,j]
            if p[1:5].sum().item()<0.01: continue
            pbboxes.append([p[1].item(),p[2].item(),p[3].item(),p[4].item()])
        clist=[]; cbboxes=[]
        for j in range(components_t.shape[1]):
            c=components_t[i,j]
            if c[1:5].sum().item()<0.01: continue
            bb=[c[1].item(),c[2].item(),c[3].item(),c[4].item()]
            pidx=int(round(c[5].item()*(MAX_PANELS+1)-1))
            clist.append({"bbox":bb,"parent_idx":pidx}); cbboxes.append(bb)
        if cbboxes:
            ol.append(compute_overlap_rate(cbboxes)); oa.append(compute_overlap_area_ratio(cbboxes))
            al.append(compute_alignment_score(cbboxes))
        else: ol.append(0.0); oa.append(0.0); al.append(1.0)
        if pbboxes and clist: vr.append(compute_constraint_violation_rate(pbboxes,clist))
        else: vr.append(0.0)
    return {"num_samples":n,
            "avg_overlap_rate":np.mean(ol),"std_overlap_rate":np.std(ol),
            "avg_overlap_area_ratio":np.mean(oa),
            "avg_alignment_score":np.mean(al),"std_alignment_score":np.std(al),
            "avg_constraint_violation":np.mean(vr),"std_constraint_violation":np.std(vr)}

def print_metrics(results, model_name="Model"):
    print(f"\n{'='*50}\n  {model_name} — Degerlendirme Sonuclari\n{'='*50}")
    print(f"  Ornek sayisi:            {results['num_samples']}")
    print(f"  Ort. Overlap Rate:       {results['avg_overlap_rate']:.4f} (+/-{results['std_overlap_rate']:.4f})")
    print(f"  Ort. Overlap Alan Orani: {results['avg_overlap_area_ratio']:.4f}")
    print(f"  Ort. Alignment Score:    {results['avg_alignment_score']:.4f} (+/-{results['std_alignment_score']:.4f})")
    if "avg_constraint_violation" in results:
        print(f"  Ort. Kisit Ihlal Orani: {results['avg_constraint_violation']:.4f} (+/-{results['std_constraint_violation']:.4f})")
    print(f"{'='*50}")

def compare_metrics(bl, hi):
    print(f"\n{'='*70}\n  KARSILASTIRMA: Baseline vs Hiyerarsik + Kisit-Kilavuzlu DDPM\n{'='*70}")
    print(f"  {'Metrik':<30} {'Baseline':>15} {'Hiyerarsik':>15}")
    print(f"  {'-'*60}")
    print(f"  {'Overlap Rate':<30} {bl['avg_overlap_rate']:>15.4f} {hi['avg_overlap_rate']:>15.4f}")
    print(f"  {'Overlap Alan Orani':<30} {bl['avg_overlap_area_ratio']:>15.4f} {hi['avg_overlap_area_ratio']:>15.4f}")
    print(f"  {'Alignment Score':<30} {bl['avg_alignment_score']:>15.4f} {hi['avg_alignment_score']:>15.4f}")
    if "avg_constraint_violation" in hi:
        print(f"  {'Kisit Ihlal Orani':<30} {'N/A':>15} {hi['avg_constraint_violation']:>15.4f}")
    print(f"{'='*70}")

if __name__=="__main__":
    print("Metrik Testi")
    iou=compute_iou([0,0,0.5,0.5],[0.25,0.25,0.75,0.75])
    expected=0.0625/(0.25+0.25-0.0625)
    print(f"IoU: {iou:.4f} (beklenen: {expected:.4f})")
    assert abs(iou-expected)<0.01
    viol=compute_constraint_violation_rate([[0,0,0.5,1]],[{"bbox":[0.1,0.1,0.4,0.4],"parent_idx":0},{"bbox":[0.3,0.1,0.7,0.4],"parent_idx":0}])
    print(f"Violation: {viol:.4f} (beklenen: 0.5)")
    assert abs(viol-0.5)<0.01
    print("[BASARILI] Metrik testleri tamamlandi!")
