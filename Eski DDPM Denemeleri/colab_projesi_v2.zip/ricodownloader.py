import os
import json
try:
    from datasets import load_dataset
except ImportError:
    print("Lütfen önce 'datasets' kütüphanesini kurun: pip install datasets")
    exit()

def download_and_save_rico(output_folder="data/rico_jsons", image_folder="data/rico_images", max_samples=2000):
    """
    Hugging Face üzerinden alternatif RICO veri setlerini dener, indirir ve JSON formatında kaydeder.
    Eğer varsa görüntüleri (screenshot) de image_folder içine kaydeder.
    Maksimum max_samples kadar veri indirir.
    """
    # Klasörleri oluştur
    os.makedirs(output_folder, exist_ok=True)
    os.makedirs(image_folder, exist_ok=True)
    print(f"📁 Klasörler hazır: '{output_folder}', '{image_folder}'")

    dataset_candidates = [
        "Fliper/rico",
        "jxu124/rico",
        "nateraw/rico",
        "dipanjyoti/rico",
        "rootsautomation/RICO-SCA"
    ]

    dataset = None
    for repo in dataset_candidates:
        print(f"⏳ '{repo}' veri seti deneniyor...")
        try:
            dataset = load_dataset(repo)
            print(f"✅ Başarılı! '{repo}' veri seti indirildi.")
            break 
        except Exception:
            print(f"❌ '{repo}' bulunamadı, bir sonrakine geçiliyor...")
    
    if dataset is None:
        print("🚨 Maalesef listedeki repolara ulaşılamadı.")
        return

    splits = dataset.keys()
    print(f"🔍 Bulunan alt kümeler: {list(splits)}")

    total_saved = 0

    for split in splits:
        split_folder = os.path.join(output_folder, split)
        os.makedirs(split_folder, exist_ok=True)
        img_split_folder = os.path.join(image_folder, split)
        os.makedirs(img_split_folder, exist_ok=True)
            
        print(f"💾 '{split}' verileri JSON ve resim (varsa) olarak kaydediliyor...")
        
        for idx, item in enumerate(dataset[split]):
            if total_saved >= max_samples:
                print(f"⏭️ Maksimum limit ({max_samples}) aşıldığı için kaydetme işlemi sonlandırılıyor.")
                return

            # Resmi kaydetme (Varsa)
            img_obj = item.get("image", None)
            if img_obj is not None and str(type(img_obj)).find("Image") != -1:
                # Orijinal PIL Image
                # 64x64 çözünürlüklü kaydet ki çok yer kaplamasın
                try:
                    img_resized = img_obj.resize((64, 64))
                    img_filename = f"ui_layout_{idx}.png"
                    img_filepath = os.path.join(img_split_folder, img_filename)
                    img_resized.save(img_filepath)
                except Exception as e:
                    print(f"[Uyarı] {idx}. resim kaydedilemedi: {e}")
            
            # Resim objesini JSON'a yazmadan önce çıkar
            keys_to_remove = [key for key, val in item.items() if "Image" in str(type(val)) or key == 'image']
            for key in keys_to_remove:
                del item[key]
                
            # JSON formatında kaydet
            filename = f"ui_layout_{idx}.json"
            filepath = os.path.join(split_folder, filename)
            
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(item, f, ensure_ascii=False, indent=4)
                
            total_saved += 1
            if total_saved % 500 == 0:
                print(f"   -> {total_saved} dosya kaydedildi...")

    print(f"🎉 İşlem tamamlandı! Toplam {total_saved} adet JSON/PNG dosyası başarıyla kaydedildi.")

if __name__ == "__main__":
    download_and_save_rico(max_samples=2000)