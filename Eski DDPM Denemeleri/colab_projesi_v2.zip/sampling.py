"""
sampling.py — Örnekleme ve Kısıt-Kılavuzlu Denoising

DDPM ters sürecini kullanarak gürültüden UI layout üretir.
Kısıt-kılavuzlu (constraint-guided) denoising ile:
- Koordinatları [0,1] sınırlarında tutar (torch.clamp)
- Alt bileşenleri ana panelin içinde tutar (containment)
- Üst üste binmeyi engelleyen iteratif düzeltme (non-overlap)
"""

import torch
import json
import os
from tqdm import tqdm

from config import (
    T, DEVICE, APPLY_CONSTRAINTS, NUM_SAMPLES,
    MAX_ELEMENTS, MAX_PANELS, MAX_COMPONENTS,
    FEATURE_DIM, PANEL_FEATURE_DIM, COMPONENT_FEATURE_DIM,
    NUM_CLASSES, COMPONENT_CLASSES, SAMPLES_DIR
)
from model import NoiseScheduler


# ==============================================================================
# Kısıt Fonksiyonları (Constraint Functions)
# ==============================================================================

def apply_coordinate_clamp(x):
    """
    Tüm koordinatları [-1, 1] arasında sınırlar.
    Sınıf ID'si de DDPM için [-1, 1] aralığına set edilmiştir.
    """
    return torch.clamp(x, -1.0, 1.0)


def apply_valid_bbox(x, feature_dim):
    """
    x_min < x_max ve y_min < y_max olmasını sağlar.
    Koordinat sütunları: [cls, x_min, y_min, x_max, y_max, ...]
    """
    if feature_dim >= 5:
        # x_min < x_max olmalı
        x_min = x[..., 1:2]
        x_max = x[..., 3:4]
        # Eğer x_min > x_max ise, takas et
        new_x_min = torch.min(x_min, x_max)
        new_x_max = torch.max(x_min, x_max)
        # Minimum genişlik garantisi
        min_size = 0.02
        new_x_max = torch.max(new_x_max, new_x_min + min_size)
        new_x_max = torch.clamp(new_x_max, max=1.0)

        # y_min < y_max olmalı
        y_min = x[..., 2:3]
        y_max = x[..., 4:5]
        new_y_min = torch.min(y_min, y_max)
        new_y_max = torch.max(y_min, y_max)
        new_y_max = torch.max(new_y_max, new_y_min + min_size)
        new_y_max = torch.clamp(new_y_max, max=1.0)

        x = x.clone()
        x[..., 1:2] = new_x_min
        x[..., 2:3] = new_y_min
        x[..., 3:4] = new_x_max
        x[..., 4:5] = new_y_max

    return x


def apply_containment_constraint(components, panels, max_panels):
    """
    Alt bileşenlerin ana panellerinin sınırları içinde kalmasını sağlar.
    
    Args:
        components: [batch, max_comp, comp_feature_dim] — [cls, x1, y1, x2, y2, parent_norm]
        panels: [batch, max_panels, panel_feature_dim] — [cls, x1, y1, x2, y2]
        max_panels: Maksimum panel sayısı
    
    Returns:
        Düzeltilmiş components tensörü
    """
    components = components.clone()
    batch_size = components.shape[0]

    for b in range(batch_size):
        for c in range(components.shape[1]):
            # parent_norm [-1, 1] aralığından [0, 1] aralığına çevriliyor
            parent_norm = components[b, c, 5].item()
            parent_norm_01 = (parent_norm + 1.0) / 2.0
            parent_idx = int(round(parent_norm_01 * (max_panels + 1) - 1))

            if parent_idx < 0 or parent_idx >= max_panels:
                continue

            # Panel sınırları
            px1 = panels[b, parent_idx, 1].item()
            py1 = panels[b, parent_idx, 2].item()
            px2 = panels[b, parent_idx, 3].item()
            py2 = panels[b, parent_idx, 4].item()

            # Panel geçersizse atla
            if px2 <= px1 or py2 <= py1:
                continue

            # Bileşeni panelin sınırları içine çek
            margin = 0.005
            cx1 = max(components[b, c, 1].item(), px1 + margin)
            cy1 = max(components[b, c, 2].item(), py1 + margin)
            cx2 = min(components[b, c, 3].item(), px2 - margin)
            cy2 = min(components[b, c, 4].item(), py2 - margin)

            # Minimum boyut garantisi
            if cx2 <= cx1:
                mid = (px1 + px2) / 2
                cx1 = mid - 0.02
                cx2 = mid + 0.02
            if cy2 <= cy1:
                mid = (py1 + py2) / 2
                cy1 = mid - 0.02
                cy2 = mid + 0.02

            components[b, c, 1] = cx1
            components[b, c, 2] = cy1
            components[b, c, 3] = cx2
            components[b, c, 4] = cy2

    return components


def apply_non_overlap_correction(x, feature_dim, max_iter=3):
    """
    Üst üste binen bounding box'ları iteratif olarak düzeltir.
    Çakışan kutuları birbirinden uzaklaştırır.
    
    Args:
        x: [batch, num_elements, feature_dim]
        feature_dim: Özellik boyutu
        max_iter: Maksimum düzeltme iterasyonu
    """
    x = x.clone()
    batch_size, num_elem, _ = x.shape

    for _ in range(max_iter):
        for b in range(batch_size):
            for i in range(num_elem):
                for j in range(i + 1, num_elem):
                    # Padding'leri atla (tamamı sıfır olanlar)
                    if x[b, i, 1:5].sum().item() < 0.01 or x[b, j, 1:5].sum().item() < 0.01:
                        continue

                    # Çakışma hesapla
                    ix1 = max(x[b, i, 1].item(), x[b, j, 1].item())
                    iy1 = max(x[b, i, 2].item(), x[b, j, 2].item())
                    ix2 = min(x[b, i, 3].item(), x[b, j, 3].item())
                    iy2 = min(x[b, i, 4].item(), x[b, j, 4].item())

                    if ix1 < ix2 and iy1 < iy2:
                        # Çakışma var — kutuları birbirinden uzaklaştır
                        overlap_w = ix2 - ix1
                        overlap_h = iy2 - iy1

                        if overlap_w < overlap_h:
                            # Yatay düzeltme
                            shift = overlap_w / 2.0 + 0.005
                            if x[b, i, 1].item() < x[b, j, 1].item():
                                x[b, i, 1] -= shift
                                x[b, i, 3] -= shift
                                x[b, j, 1] += shift
                                x[b, j, 3] += shift
                            else:
                                x[b, i, 1] += shift
                                x[b, i, 3] += shift
                                x[b, j, 1] -= shift
                                x[b, j, 3] -= shift
                        else:
                            # Dikey düzeltme
                            shift = overlap_h / 2.0 + 0.005
                            if x[b, i, 2].item() < x[b, j, 2].item():
                                x[b, i, 2] -= shift
                                x[b, i, 4] -= shift
                                x[b, j, 2] += shift
                                x[b, j, 4] += shift
                            else:
                                x[b, i, 2] += shift
                                x[b, i, 4] += shift
                                x[b, j, 2] -= shift
                                x[b, j, 4] -= shift

    # Sınırlar içinde tut (DDPM için [-1, 1])
    x[..., 1:5] = torch.clamp(x[..., 1:5], -1.0, 1.0)
    return x


# ==============================================================================
# Baseline DDPM Örnekleme
# ==============================================================================

def sample_baseline(model, scheduler, num_samples=NUM_SAMPLES,
                    apply_constraints=APPLY_CONSTRAINTS):
    """
    Baseline DDPM ile gürültüden layout üretir.
    
    Args:
        model: Eğitilmiş BaselineDDPM
        scheduler: NoiseScheduler
        num_samples: Üretilecek örnek sayısı
        apply_constraints: Kısıtları uygula mı?
        
    Returns:
        samples: [num_samples, MAX_ELEMENTS, FEATURE_DIM] — üretilmiş layout'lar
    """
    model.eval()
    print(f"\n[Baseline Sampling] {num_samples} adet layout üretiliyor...")

    with torch.no_grad():
        # Saf Gaussian gürültüden başla
        x = torch.randn(num_samples, MAX_ELEMENTS, FEATURE_DIM, device=DEVICE)

        for t in tqdm(range(T - 1, -1, -1), desc="Ters difüzyon", leave=False):
            t_tensor = torch.full((num_samples,), t, device=DEVICE, dtype=torch.long)

            # Gürültü tahmini
            noise_pred = model(x, t_tensor)

            # Ters adım
            beta_t = scheduler.betas[t]
            alpha_t = scheduler.alphas[t]
            alpha_bar_t = scheduler.alpha_bars[t]
            sqrt_recip_alpha = scheduler.sqrt_recip_alphas[t]
            coeff = beta_t / scheduler.sqrt_one_minus_alpha_bars[t]

            mean = sqrt_recip_alpha * (x - coeff * noise_pred)

            if t > 0:
                noise = torch.randn_like(x)
                sigma = torch.sqrt(scheduler.posterior_variance[t])
                x = mean + sigma * noise
            else:
                x = mean

        # Son düzeltme
        x = apply_coordinate_clamp(x)
        x = apply_valid_bbox(x, FEATURE_DIM)
        if apply_constraints:
            x = apply_non_overlap_correction(x, FEATURE_DIM)

        # DDPM [-1, 1] -> [0, 1] Denormalizasyonu
        x = (x + 1.0) / 2.0
        x = torch.clamp(x, 0.0, 1.0)

    print(f"[Baseline Sampling] Tamamlandı.")
    return x.cpu()


# ==============================================================================
# Hiyerarşik DDPM Örnekleme
# ==============================================================================

def sample_hierarchical(model, scheduler, num_samples=NUM_SAMPLES,
                        apply_constraints=APPLY_CONSTRAINTS):
    """
    Hiyerarşik DDPM ile iki aşamalı layout üretimi.
    
    Aşama 1: PanelGenerator ile paneller üret
    Aşama 2: ComponentGenerator ile (panel koşullamalı) bileşenler üret
    
    Args:
        model: Eğitilmiş HierarchicalDDPM
        scheduler: NoiseScheduler
        num_samples: Üretilecek örnek sayısı
        apply_constraints: Kısıt-kılavuzlu denoising aktif mi?
        
    Returns:
        panels: [num_samples, MAX_PANELS, PANEL_FEATURE_DIM]
        components: [num_samples, MAX_COMPONENTS, COMPONENT_FEATURE_DIM]
    """
    model.eval()

    # ---- AŞAMA 1: Panel Üretimi ----
    print(f"\n[Hiyerarşik Sampling] Aşama 1: Panel üretimi ({num_samples} adet)...")
    with torch.no_grad():
        panels = torch.randn(num_samples, MAX_PANELS, PANEL_FEATURE_DIM, device=DEVICE)

        for t in tqdm(range(T - 1, -1, -1), desc="Panel denoising", leave=False):
            t_tensor = torch.full((num_samples,), t, device=DEVICE, dtype=torch.long)
            noise_pred = model.forward_panel(panels, t_tensor)

            beta_t = scheduler.betas[t]
            sqrt_recip_alpha = scheduler.sqrt_recip_alphas[t]
            coeff = beta_t / scheduler.sqrt_one_minus_alpha_bars[t]
            mean = sqrt_recip_alpha * (panels - coeff * noise_pred)

            if t > 0:
                noise = torch.randn_like(panels)
                sigma = torch.sqrt(scheduler.posterior_variance[t])
                panels = mean + sigma * noise
            else:
                panels = mean

        # Panel son düzeltme
        panels = apply_coordinate_clamp(panels)
        panels = apply_valid_bbox(panels, PANEL_FEATURE_DIM)
        if apply_constraints:
            panels = apply_non_overlap_correction(panels, PANEL_FEATURE_DIM)

    # ---- AŞAMA 2: Bileşen Üretimi ----
    print(f"[Hiyerarşik Sampling] Aşama 2: Bileşen üretimi...")
    with torch.no_grad():
        components = torch.randn(num_samples, MAX_COMPONENTS, COMPONENT_FEATURE_DIM, device=DEVICE)

        for t in tqdm(range(T - 1, -1, -1), desc="Bileşen denoising", leave=False):
            t_tensor = torch.full((num_samples,), t, device=DEVICE, dtype=torch.long)
            noise_pred = model.forward_component(components, t_tensor, panels)

            beta_t = scheduler.betas[t]
            sqrt_recip_alpha = scheduler.sqrt_recip_alphas[t]
            coeff = beta_t / scheduler.sqrt_one_minus_alpha_bars[t]
            mean = sqrt_recip_alpha * (components - coeff * noise_pred)

            if t > 0:
                noise = torch.randn_like(components)
                sigma = torch.sqrt(scheduler.posterior_variance[t])
                components = mean + sigma * noise
            else:
                components = mean

        # Bileşen son düzeltme
        components = apply_coordinate_clamp(components)
        components = apply_valid_bbox(components, COMPONENT_FEATURE_DIM)
        if apply_constraints:
            components = apply_containment_constraint(components, panels, MAX_PANELS)
            components = apply_non_overlap_correction(components, COMPONENT_FEATURE_DIM)

        # DDPM [-1, 1] -> [0, 1] Denormalizasyonu
        panels = (panels + 1.0) / 2.0
        panels = torch.clamp(panels, 0.0, 1.0)
        
        components = (components + 1.0) / 2.0
        components = torch.clamp(components, 0.0, 1.0)

    panels_cpu = panels.cpu()
    components_cpu = components.cpu()
    print(f"[Hiyerarşik Sampling] Tamamlandı.")

    return panels_cpu, components_cpu


# ==============================================================================
# Aşama 2 (Görsel Difüzyonu) Örnekleme
# ==============================================================================

def sample_image_diffusion(model, scheduler, panels, components, num_samples=NUM_SAMPLES):
    """
    1. Aşama'nın (Hiyerarşik DDPM) ürettiği layout'ları girdi (condition)
    olarak alıp 64x64 boyutunda "Sentetik UI Resmi" çizer.
    
    Args:
        model: Eğitilmiş ConditionalUNet (Image Diffusion Modeli)
        scheduler: NoiseScheduler
        panels: [batch, max_pan, panel_dim]
        components: [batch, max_comp, comp_dim]
        num_samples: Örnek sayısı (panels.shape[0] ile uyumlu olmalı)
        
    Returns:
        images: [num_samples, 3, 64, 64] üretilmiş görseller (-1 ile 1 arası)
    """
    model.eval()
    from data_preprocessing import render_layout_to_image
    from config import IMAGE_SIZE
    
    # Adım 1: Panelleri ve Bileşenleri Condition Mask'a Çevir
    conditions = []
    print(f"\n[Aşama 2 Sampling] Layout maskeleri hazırlanıyor...")
    for i in range(num_samples):
        # Sadece bu örneğe ait paneller ve bileşenler
        p = panels[i].numpy() if isinstance(panels, torch.Tensor) else panels[i]
        c = components[i].numpy() if isinstance(components, torch.Tensor) else components[i]
        _, cond_tensor = render_layout_to_image(p, c, image_size=IMAGE_SIZE)
        conditions.append(cond_tensor)
        
    cond_batch = torch.stack(conditions).to(DEVICE) # [num_samples, NUM_CLASSES, 64, 64]
    
    # Adım 2: Saf Gürültüden (Noise) Başla
    print(f"[Aşama 2 Sampling] {num_samples} adet görsel üretiliyor (Ters Difüzyon)...")
    with torch.no_grad():
        x = torch.randn(num_samples, 3, IMAGE_SIZE, IMAGE_SIZE, device=DEVICE)
        
        for t in tqdm(range(T - 1, -1, -1), desc="Görsel Denoising", leave=False):
            t_tensor = torch.full((num_samples,), t, device=DEVICE, dtype=torch.long)
            noise_pred = model(x, t_tensor, cond_batch)
            
            beta_t = scheduler.betas[t]
            sqrt_recip_alpha = scheduler.sqrt_recip_alphas[t]
            coeff = beta_t / scheduler.sqrt_one_minus_alpha_bars[t]
            mean = sqrt_recip_alpha * (x - coeff * noise_pred)
            
            if t > 0:
                noise = torch.randn_like(x)
                sigma = torch.sqrt(scheduler.posterior_variance[t])
                x = mean + sigma * noise
            else:
                x = mean
                
    # x şu an [-1, 1] arası değerlere sahip.
    print("[Aşama 2 Sampling] Tamamlandı.")
    return x.cpu()


def generated_images_to_png(images_tensor, filename_prefix="generated_ui"):
    """
    Üretilen difüzyon görsellerini PNG olarak kaydeder.
    images_tensor: [batch, 3, 64, 64] (değerler -1 ile 1 arasında)
    """
    import matplotlib.pyplot as plt
    import numpy as np
    
    # Klasör kontrolü
    os.makedirs(SAMPLES_DIR, exist_ok=True)
    
    batch_size = images_tensor.shape[0]
    
    # Tensörü geri [0, 1] aralığına çek (Denormalization)
    images_tensor = (images_tensor + 1.0) / 2.0
    images_tensor = torch.clamp(images_tensor, 0.0, 1.0)
    
    for i in range(batch_size):
        img_np = images_tensor[i].permute(1, 2, 0).numpy() # [64, 64, 3]
        
        path = os.path.join(SAMPLES_DIR, f"{filename_prefix}_{i}.png")
        plt.imsave(path, img_np)
        
    print(f"[PNG] {batch_size} adet görsel klasöre kaydedildi: {SAMPLES_DIR}")


# ==============================================================================
# Sonuçları JSON Olarak Kaydetme
# ==============================================================================

def _denormalize_class(cls_norm):
    """Normalize edilmiş sınıf ID'sini gerçek sınıf adına çevirir."""
    cls_idx = int(round(cls_norm * (NUM_CLASSES - 1)))
    cls_idx = max(0, min(cls_idx, NUM_CLASSES - 1))
    return COMPONENT_CLASSES[cls_idx]


def baseline_samples_to_json(samples, filename="baseline_samples.json"):
    """
    Baseline model çıktısını JSON formatına çevirir.
    
    Args:
        samples: [num, MAX_ELEMENTS, FEATURE_DIM]
        filename: Çıktı dosya adı
    """
    results = []
    for i in range(samples.shape[0]):
        layout = {"id": i, "elements": []}
        for j in range(samples.shape[1]):
            elem = samples[i, j]
            # Padding kontrolü
            if elem[1:5].sum().item() < 0.01:
                continue
            layout["elements"].append({
                "class": _denormalize_class(elem[0].item()),
                "x_min": round(elem[1].item(), 4),
                "y_min": round(elem[2].item(), 4),
                "x_max": round(elem[3].item(), 4),
                "y_max": round(elem[4].item(), 4),
            })
        results.append(layout)

    path = os.path.join(SAMPLES_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[JSON] {len(results)} layout kaydedildi: {path}")
    return results


def hierarchical_samples_to_json(panels, components,
                                  filename="hierarchical_samples.json"):
    """
    Hiyerarşik model çıktısını JSON formatına çevirir.
    
    Args:
        panels: [num, MAX_PANELS, PANEL_FEATURE_DIM]
        components: [num, MAX_COMPONENTS, COMPONENT_FEATURE_DIM]
        filename: Çıktı dosya adı
    """
    results = []
    for i in range(panels.shape[0]):
        layout = {"id": i, "panels": [], "components": []}

        for j in range(panels.shape[1]):
            p = panels[i, j]
            if p[1:5].sum().item() < 0.01:
                continue
            layout["panels"].append({
                "class": _denormalize_class(p[0].item()),
                "x_min": round(p[1].item(), 4),
                "y_min": round(p[2].item(), 4),
                "x_max": round(p[3].item(), 4),
                "y_max": round(p[4].item(), 4),
            })

        for j in range(components.shape[1]):
            c = components[i, j]
            if c[1:5].sum().item() < 0.01:
                continue
            parent_norm = c[5].item()
            parent_idx = int(round(parent_norm * (MAX_PANELS + 1) - 1))
            layout["components"].append({
                "class": _denormalize_class(c[0].item()),
                "x_min": round(c[1].item(), 4),
                "y_min": round(c[2].item(), 4),
                "x_max": round(c[3].item(), 4),
                "y_max": round(c[4].item(), 4),
                "parent_panel": parent_idx,
            })

        results.append(layout)

    path = os.path.join(SAMPLES_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[JSON] {len(results)} layout kaydedildi: {path}")
    return results


# ==============================================================================
# Test
# ==============================================================================
if __name__ == "__main__":
    from model import create_baseline_model, create_hierarchical_model

    print("=" * 60)
    print("Örnekleme Testi (eğitimsiz — rastgele ağırlıklar)")
    print("=" * 60)

    scheduler = NoiseScheduler()

    # Baseline sampling testi (az sayıda adım ve örnekle)
    baseline = create_baseline_model()
    # Hızlı test için T'yi geçici olarak düşür
    original_T = scheduler.T
    scheduler.T = 10
    bl_samples = sample_baseline(baseline, scheduler, num_samples=4)
    scheduler.T = original_T
    print(f"[Baseline] Samples shape: {bl_samples.shape}")
    baseline_samples_to_json(bl_samples[:2], "test_baseline.json")

    print("\n[BAŞARILI] Örnekleme testi tamamlandı!")
