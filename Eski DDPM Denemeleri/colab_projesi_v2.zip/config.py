"""
config.py — Merkezi Hiperparametre ve Konfigürasyon Dosyası

Hiyerarşik ve Kısıt-Kılavuzlu DDPM ile UI Bounding Box Üretimi projesi
için tüm ayarlar bu dosyada tanımlanmıştır.
"""

import torch
import os

# ==============================================================================
# Cihaz Ayarı (CUDA varsa GPU, yoksa CPU)
# ==============================================================================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ==============================================================================
# Veri Seti Ayarları
# ==============================================================================
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
RICO_JSON_DIR = os.path.join(DATA_DIR, "rico_jsons")

# Bileşen sınıfları (RICO veri setinden filtrelenen temel UI elemanları)
COMPONENT_CLASSES = [
    "Panel",          # 0 — Ana taşıyıcı panel / container
    "Button",         # 1 — Buton
    "TextInput",      # 2 — Metin giriş alanı
    "Label",          # 3 — Etiket / yazı
    "Icon",           # 4 — İkon
    "CheckBox",       # 5 — Seçim kutusu
    "Dropdown",       # 6 — Açılır menü
    "Slider",         # 7 — Kaydırıcı
    "Toggle",         # 8 — Açma/kapama düğmesi
    "Image",          # 9 — Görsel alanı
]
NUM_CLASSES = len(COMPONENT_CLASSES)

# Her bir UI elemanının özellik boyutu: [class_id, x_min, y_min, x_max, y_max]
FEATURE_DIM = 5  # sınıf_id + 4 koordinat

# Hiyerarşik yapı için panel özellik boyutu
PANEL_FEATURE_DIM = 5  # [class_id, x_min, y_min, x_max, y_max]
# Alt bileşen özellik boyutu (panel_id ek olarak eklenir)
COMPONENT_FEATURE_DIM = 6  # [class_id, x_min, y_min, x_max, y_max, parent_panel_idx]

# Sabit boyutlu padding için maksimum sayılar
MAX_PANELS = 5          # Bir layout'taki maksimum ana panel sayısı
MAX_COMPONENTS = 20     # Bir layout'taki maksimum alt bileşen sayısı
MAX_ELEMENTS = 25       # Baseline model için toplam maksimum eleman (panel + bileşen)

# ==============================================================================
# Difüzyon (DDPM) Hiperparametreleri
# ==============================================================================
T = 1000                # Toplam difüzyon adım sayısı
BETA_START = 1e-4       # Başlangıç beta değeri (linear schedule)
BETA_END = 0.02         # Bitiş beta değeri

# ==============================================================================
# Model Mimarisi Ayarları (Heavyweight GPU Optimizasyonu)
# ==============================================================================
HIDDEN_DIM = 512        # Gizli katman boyutu
NUM_LAYERS = 6          # Residual blok sayısı
TIME_EMB_DIM = 256      # Zaman adımı embedding boyutu
NHEAD = 8               # Dikkat mekanizması kafa sayısı (hiyerarşik model)
DROPOUT = 0.1           # Dropout oranı

# ==============================================================================
# Görüntü (Aşama 2) Difüzyon U-Net Ayarları
# ==============================================================================
IMAGE_SIZE = 64         # Üretilecek sentetik Mock-UI piksel çözünürlüğü (64x64)
IMAGE_CHANNELS = 3      # RGB
UNET_CHANNELS = [64, 128, 256, 256] # Model derinliği ve kanal sayıları
# Her sınıf için renderlanacak renk kodları (R, G, B)
CLASS_COLORS = {
    0: (230, 230, 230), # Panel - Açık Gri
    1: (33, 150, 243),  # Button - Mavi
    2: (255, 193, 7),   # Input - Sarı
    3: (60, 60, 60),    # Text - Koyu Gri
    4: (156, 39, 176),  # Icon - Mor
    5: (76, 175, 80),   # Checkbox - Yeşil
    6: (255, 87, 34),   # Spinner - Turuncu
    7: (0, 188, 212),   # Slider - Camgöbeği
    8: (233, 30, 99),   # Switch - Pembe
    9: (139, 195, 74),  # Image - Açık Yeşil
}

# ==============================================================================
# Eğitim Ayarları
# ==============================================================================
BATCH_SIZE = 16         # Model büyüdüğü için T4 GPU OOM önlemi (64 -> 16'ya düşürüldü)
NUM_EPOCHS = 200
LEARNING_RATE = 1e-4
WEIGHT_DECAY = 1e-5
GRAD_CLIP = 1.0         # Gradient clipping değeri
SAVE_EVERY = 20         # Her kaç epoch'ta bir checkpoint kaydet
EARLY_STOP_PATIENCE = 30  # Early stopping sabır değeri

# ==============================================================================
# Örnekleme (Sampling) Ayarları
# ==============================================================================
NUM_SAMPLES = 1000      # Değerlendirme için üretilecek örnek sayısı
APPLY_CONSTRAINTS = True  # Kısıt-kılavuzlu denoising aktif/pasif

# ==============================================================================
# Çıktı Dizinleri
# ==============================================================================
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")
CHECKPOINT_DIR = os.path.join(OUTPUT_DIR, "checkpoints")
FIGURES_DIR = os.path.join(OUTPUT_DIR, "figures")
SAMPLES_DIR = os.path.join(OUTPUT_DIR, "samples")

# Dizinleri oluştur
for d in [DATA_DIR, OUTPUT_DIR, CHECKPOINT_DIR, FIGURES_DIR, SAMPLES_DIR]:
    os.makedirs(d, exist_ok=True)

# ==============================================================================
# Sentetik (Mock) Veri Ayarları
# ==============================================================================
MOCK_DATASET_SIZE = 2000  # Sentetik veri seti boyutu

# ==============================================================================
# Sınıf renkleri (görselleştirme için)
# ==============================================================================
CLASS_COLORS = {
    0: (0.2, 0.4, 0.8, 0.3),    # Panel — mavi, yarı saydam
    1: (0.9, 0.3, 0.3, 0.7),    # Button — kırmızı
    2: (0.3, 0.8, 0.3, 0.7),    # TextInput — yeşil
    3: (0.9, 0.9, 0.2, 0.7),    # Label — sarı
    4: (0.6, 0.3, 0.9, 0.7),    # Icon — mor
    5: (0.3, 0.9, 0.9, 0.7),    # CheckBox — cyan
    6: (0.9, 0.6, 0.2, 0.7),    # Dropdown — turuncu
    7: (0.5, 0.5, 0.5, 0.7),    # Slider — gri
    8: (0.2, 0.7, 0.5, 0.7),    # Toggle — deniz yeşili
    9: (0.8, 0.4, 0.6, 0.7),    # Image — pembe
}
