"""
train.py — Eğitim Döngüsü

Baseline ve Hiyerarşik DDPM modellerinin eğitim süreçlerini yönetir.
- MSE loss ile noise prediction
- Gradient clipping
- Early stopping
- Checkpoint kaydetme
- Loss grafiği çizme
"""

import os
import time
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
import matplotlib.pyplot as plt

from config import (
    T, DEVICE, NUM_EPOCHS, LEARNING_RATE, WEIGHT_DECAY,
    GRAD_CLIP, SAVE_EVERY, EARLY_STOP_PATIENCE,
    CHECKPOINT_DIR, FIGURES_DIR,
    MAX_ELEMENTS, FEATURE_DIM,
    MAX_PANELS, MAX_COMPONENTS,
    PANEL_FEATURE_DIM, COMPONENT_FEATURE_DIM
)
from model import NoiseScheduler, create_baseline_model, create_hierarchical_model


# ==============================================================================
# Eğitim Yardımcı Fonksiyonları
# ==============================================================================

class EarlyStopping:
    """Early stopping mekanizması — doğrulama kaybı düşmezse eğitimi durdurur."""

    def __init__(self, patience=EARLY_STOP_PATIENCE, min_delta=1e-5):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.should_stop = False

    def step(self, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True
                print(f"[Early Stopping] {self.patience} epoch boyunca iyileşme olmadı. Eğitim durduruluyor.")


def save_checkpoint(model, optimizer, epoch, loss, filename):
    """Model checkpoint'ını kaydeder."""
    path = os.path.join(CHECKPOINT_DIR, filename)
    torch.save({
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "loss": loss,
    }, path)
    print(f"  [Checkpoint] Kaydedildi: {path}")


def load_checkpoint(model, optimizer, filename):
    """Model checkpoint'ını yükler."""
    path = os.path.join(CHECKPOINT_DIR, filename)
    if os.path.exists(path):
        checkpoint = torch.load(path, map_location=DEVICE, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])
        if optimizer is not None:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        print(f"  [Checkpoint] Yüklendi: {path} (epoch {checkpoint['epoch']})")
        return checkpoint["epoch"]
    return 0


def plot_losses(train_losses, val_losses, title, filename):
    """Eğitim ve doğrulama kayıp grafiğini çizer."""
    plt.figure(figsize=(10, 5))
    plt.plot(train_losses, label="Eğitim Kaybı", color="#2196F3", linewidth=2)
    if val_losses:
        plt.plot(val_losses, label="Doğrulama Kaybı", color="#FF5722", linewidth=2)
    plt.xlabel("Epoch", fontsize=12)
    plt.ylabel("MSE Loss", fontsize=12)
    plt.title(title, fontsize=14, fontweight="bold")
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, filename)
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  [Grafik] Kaydedildi: {path}")


# ==============================================================================
# Baseline DDPM Eğitimi
# ==============================================================================

def train_baseline(train_loader, val_loader, num_epochs=NUM_EPOCHS, lr=LEARNING_RATE,
                   resume=False):
    """
    Baseline (tek aşamalı) DDPM eğitimi.
    
    Args:
        train_loader: Eğitim DataLoader (BaselineLayoutDataset)
        val_loader: Doğrulama DataLoader
        num_epochs: Toplam epoch sayısı
        lr: Öğrenme oranı
        resume: True ise kaydedilmiş checkpoint'tan devam et
        
    Returns:
        model: Eğitilmiş model
        train_losses: Eğitim kayıpları listesi
        val_losses: Doğrulama kayıpları listesi
    """
    print("\n" + "=" * 60)
    print("BASELINE DDPM EĞİTİMİ BAŞLIYOR")
    print("=" * 60)

    model = create_baseline_model()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    scheduler = NoiseScheduler()
    criterion = nn.MSELoss()
    early_stopping = EarlyStopping()

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(model, optimizer, "baseline_latest.pt")

    train_losses = []
    val_losses = []
    best_val_loss = float("inf")

    start_time = time.time()
    avg_train_loss, avg_val_loss = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        # ---- Eğitim ----
        model.train()
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(train_loader, desc=f"Epoch {epoch + 1}/{num_epochs} [Eğitim]",
                     leave=False)
        for batch in pbar:
            batch = batch.to(DEVICE)  # [batch, MAX_ELEMENTS, FEATURE_DIM]

            # Rastgele zaman adımı seç
            t = torch.randint(0, T, (batch.shape[0],), device=DEVICE)

            # İleri difüzyon: x_0 → x_t
            x_t, noise = scheduler.q_sample(batch, t)

            # Gürültü tahmini
            noise_pred = model(x_t, t)

            # MSE Loss
            loss = criterion(noise_pred, noise)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            optimizer.step()

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train_loss = epoch_loss / max(num_batches, 1)
        train_losses.append(avg_train_loss)

        # ---- Doğrulama ----
        model.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                batch = batch.to(DEVICE)
                t = torch.randint(0, T, (batch.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(batch, t)
                noise_pred = model(x_t, t)
                loss = criterion(noise_pred, noise)
                val_loss += loss.item()
                val_batches += 1

        avg_val_loss = val_loss / max(val_batches, 1)
        val_losses.append(avg_val_loss)

        elapsed = time.time() - start_time
        print(f"  Epoch {epoch + 1:3d}/{num_epochs} | "
              f"Eğitim: {avg_train_loss:.5f} | Doğrulama: {avg_val_loss:.5f} | "
              f"Süre: {elapsed:.0f}s")

        # En iyi model kaydetme
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            save_checkpoint(model, optimizer, epoch + 1, avg_val_loss,
                            "baseline_best.pt")

        # Düzenli checkpoint
        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(model, optimizer, epoch + 1, avg_val_loss,
                            "baseline_latest.pt")

        # Early stopping kontrolü
        early_stopping.step(avg_val_loss)
        if early_stopping.should_stop:
            break

    # Loss grafiği
    plot_losses(train_losses, val_losses,
                "Baseline DDPM — Eğitim & Doğrulama Kaybı",
                "baseline_loss.png")

    # Son checkpoint
    save_checkpoint(model, optimizer, num_epochs, avg_val_loss,
                    "baseline_latest.pt")

    total_time = time.time() - start_time
    print(f"\n[Baseline] Eğitim tamamlandı! Toplam süre: {total_time:.0f}s")
    print(f"[Baseline] En iyi doğrulama kaybı: {best_val_loss:.5f}")

    return model, train_losses, val_losses


# ==============================================================================
# Hiyerarşik DDPM Eğitimi
# ==============================================================================

def train_hierarchical(train_loader, val_loader, num_epochs=NUM_EPOCHS, lr=LEARNING_RATE,
                       resume=False):
    """
    Hiyerarşik (iki aşamalı) DDPM eğitimi.
    
    Aşama 1: PanelGenerator eğitimi (panellerin koordinatlarını öğren)
    Aşama 2: ComponentGenerator eğitimi (panel bilgisiyle koşullanarak bileşenleri öğren)
    
    Args:
        train_loader: Eğitim DataLoader (HierarchicalLayoutDataset)
        val_loader: Doğrulama DataLoader
        num_epochs: Toplam epoch sayısı (her aşama için)
        lr: Öğrenme oranı
        resume: True ise kaydedilmiş checkpoint'tan devam et
        
    Returns:
        model: Eğitilmiş HierarchicalDDPM
        losses: dict — eğitim/doğrulama kayıpları
    """
    print("\n" + "=" * 60)
    print("HİYERARŞİK DDPM EĞİTİMİ BAŞLIYOR")
    print("=" * 60)

    model = create_hierarchical_model()
    scheduler = NoiseScheduler()
    criterion = nn.MSELoss()

    losses = {
        "panel_train": [], "panel_val": [],
        "comp_train": [], "comp_val": [],
    }

    # ==========================================
    # AŞAMA 1: Panel Generator Eğitimi
    # ==========================================
    print("\n--- AŞAMA 1: Panel Generator Eğitimi ---")
    panel_optimizer = optim.AdamW(
        model.panel_generator.parameters(), lr=lr, weight_decay=WEIGHT_DECAY
    )
    panel_early_stop = EarlyStopping()
    best_panel_val = float("inf")

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(model.panel_generator, panel_optimizer,
                                       "hier_panel_latest.pt")

    start_time = time.time()
    avg_train, avg_val = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        # Eğitim
        model.panel_generator.train()
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(train_loader,
                     desc=f"[Panel] Epoch {epoch + 1}/{num_epochs}",
                     leave=False)
        for batch in pbar:
            panels = batch["panels"].to(DEVICE)
            panel_mask = batch["panel_mask"].to(DEVICE)

            t = torch.randint(0, T, (panels.shape[0],), device=DEVICE)
            x_t, noise = scheduler.q_sample(panels, t)
            noise_pred = model.forward_panel(x_t, t)

            # Mask uygula (yalnızca gerçek panellerin kaybını hesapla)
            mask = panel_mask.unsqueeze(-1).expand_as(noise_pred)
            loss = criterion(noise_pred * mask, noise * mask)

            panel_optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.panel_generator.parameters(), GRAD_CLIP)
            panel_optimizer.step()

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train = epoch_loss / max(num_batches, 1)
        losses["panel_train"].append(avg_train)

        # Doğrulama
        model.panel_generator.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                panels = batch["panels"].to(DEVICE)
                panel_mask = batch["panel_mask"].to(DEVICE)
                t = torch.randint(0, T, (panels.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(panels, t)
                noise_pred = model.forward_panel(x_t, t)
                mask = panel_mask.unsqueeze(-1).expand_as(noise_pred)
                loss = criterion(noise_pred * mask, noise * mask)
                val_loss += loss.item()
                val_batches += 1

        avg_val = val_loss / max(val_batches, 1)
        losses["panel_val"].append(avg_val)

        print(f"  [Panel] Epoch {epoch + 1:3d}/{num_epochs} | "
              f"Eğitim: {avg_train:.5f} | Doğrulama: {avg_val:.5f}")

        if avg_val < best_panel_val:
            best_panel_val = avg_val
            save_checkpoint(model.panel_generator, panel_optimizer,
                            epoch + 1, avg_val, "hier_panel_best.pt")

        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(model.panel_generator, panel_optimizer,
                            epoch + 1, avg_val, "hier_panel_latest.pt")

        panel_early_stop.step(avg_val)
        if panel_early_stop.should_stop:
            break

    panel_time = time.time() - start_time
    print(f"[Panel Generator] Eğitim tamamlandı! Süre: {panel_time:.0f}s")
    save_checkpoint(model.panel_generator, panel_optimizer,
                    num_epochs, avg_val, "hier_panel_latest.pt")

    # ==========================================
    # AŞAMA 2: Component Generator Eğitimi
    # ==========================================
    print("\n--- AŞAMA 2: Component Generator Eğitimi ---")
    comp_optimizer = optim.AdamW(
        model.component_generator.parameters(), lr=lr, weight_decay=WEIGHT_DECAY
    )
    comp_early_stop = EarlyStopping()
    best_comp_val = float("inf")

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(model.component_generator, comp_optimizer,
                                       "hier_comp_latest.pt")

    start_time = time.time()
    avg_train, avg_val = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        # Eğitim
        model.component_generator.train()
        model.panel_generator.eval()  # Panel generator donduruldu
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(train_loader,
                     desc=f"[Comp.] Epoch {epoch + 1}/{num_epochs}",
                     leave=False)
        for batch in pbar:
            panels = batch["panels"].to(DEVICE)
            components = batch["components"].to(DEVICE)
            comp_mask = batch["comp_mask"].to(DEVICE)

            t = torch.randint(0, T, (components.shape[0],), device=DEVICE)
            x_t, noise = scheduler.q_sample(components, t)

            # Panel bilgisini koşullama olarak ver (detached — gradyan yok)
            noise_pred = model.forward_component(x_t, t, panels.detach())

            # Mask uygula
            mask = comp_mask.unsqueeze(-1).expand_as(noise_pred)
            loss = criterion(noise_pred * mask, noise * mask)

            comp_optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.component_generator.parameters(), GRAD_CLIP)
            comp_optimizer.step()

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train = epoch_loss / max(num_batches, 1)
        losses["comp_train"].append(avg_train)

        # Doğrulama
        model.component_generator.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                panels = batch["panels"].to(DEVICE)
                components = batch["components"].to(DEVICE)
                comp_mask = batch["comp_mask"].to(DEVICE)
                t = torch.randint(0, T, (components.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(components, t)
                noise_pred = model.forward_component(x_t, t, panels)
                mask = comp_mask.unsqueeze(-1).expand_as(noise_pred)
                loss = criterion(noise_pred * mask, noise * mask)
                val_loss += loss.item()
                val_batches += 1

        avg_val = val_loss / max(val_batches, 1)
        losses["comp_val"].append(avg_val)

        print(f"  [Comp.] Epoch {epoch + 1:3d}/{num_epochs} | "
              f"Eğitim: {avg_train:.5f} | Doğrulama: {avg_val:.5f}")

        if avg_val < best_comp_val:
            best_comp_val = avg_val
            save_checkpoint(model.component_generator, comp_optimizer,
                            epoch + 1, avg_val, "hier_comp_best.pt")

        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(model.component_generator, comp_optimizer,
                            epoch + 1, avg_val, "hier_comp_latest.pt")

        comp_early_stop.step(avg_val)
        if comp_early_stop.should_stop:
            break

    comp_time = time.time() - start_time
    print(f"[Component Generator] Eğitim tamamlandı! Süre: {comp_time:.0f}s")
    save_checkpoint(model.component_generator, comp_optimizer,
                    num_epochs, avg_val, "hier_comp_latest.pt")

    # Loss grafikleri
    plot_losses(losses["panel_train"], losses["panel_val"],
                "Panel Generator — Eğitim & Doğrulama Kaybı",
                "hier_panel_loss.png")
    plot_losses(losses["comp_train"], losses["comp_val"],
                "Component Generator — Eğitim & Doğrulama Kaybı",
                "hier_comp_loss.png")

    print(f"\n[Hiyerarşik DDPM] Toplam eğitim süresi: {panel_time + comp_time:.0f}s")
    print(f"  Panel en iyi val.: {best_panel_val:.5f}")
    print(f"  Comp. en iyi val.: {best_comp_val:.5f}")

    return model, losses


# ==============================================================================
# Görüntü (Image) Difüzyonu Eğitimi (Aşama 2)
# ==============================================================================

def train_image_diffusion(train_loader, val_loader, num_epochs=NUM_EPOCHS, lr=LEARNING_RATE, resume=False):
    from model import create_image_diffusion_model, NoiseScheduler
    from config import T, DEVICE, GRAD_CLIP, SAVE_EVERY, WEIGHT_DECAY, EARLY_STOP_PATIENCE
    
    print("\n" + "=" * 60)
    print("AŞAMA 2: IMAGE DIFFUSION (U-NET) EĞİTİMİ BAŞLIYOR")
    print("=" * 60)

    model = create_image_diffusion_model()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    scheduler = NoiseScheduler()
    criterion = nn.MSELoss()
    early_stopping = EarlyStopping(patience=EARLY_STOP_PATIENCE)

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(model, optimizer, "image_diffusion_latest.pt")

    train_losses = []
    val_losses = []
    best_val_loss = float("inf")

    start_time = time.time()
    avg_train_loss, avg_val_loss = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        # ---- Eğitim ----
        model.train()
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(train_loader, desc=f"Epoch {epoch + 1}/{num_epochs} [Eğitim]", leave=False)
        for batch in pbar:
            images = batch["image"].to(DEVICE)         # [B, 3, 64, 64]
            conditions = batch["condition"].to(DEVICE) # [B, 10, 64, 64]

            # Rastgele zaman adımı
            t = torch.randint(0, T, (images.shape[0],), device=DEVICE)

            # İleri difüzyon: Gürültü ekle
            x_t, noise = scheduler.q_sample(images, t)

            # Gürültü tahmini (Condition vererek)
            noise_pred = model(x_t, t, conditions)

            loss = criterion(noise_pred, noise)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            optimizer.step()

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train_loss = epoch_loss / max(num_batches, 1)
        train_losses.append(avg_train_loss)

        # ---- Doğrulama ----
        model.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                images = batch["image"].to(DEVICE)
                conditions = batch["condition"].to(DEVICE)
                t = torch.randint(0, T, (images.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(images, t)
                noise_pred = model(x_t, t, conditions)
                loss = criterion(noise_pred, noise)
                val_loss += loss.item()
                val_batches += 1

        avg_val_loss = val_loss / max(val_batches, 1)
        val_losses.append(avg_val_loss)

        elapsed = time.time() - start_time
        print(f"  [Image UNet] Epoch {epoch + 1:3d}/{num_epochs} | "
              f"Eğitim: {avg_train_loss:.5f} | Doğrulama: {avg_val_loss:.5f} | Süre: {elapsed:.0f}s")

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            save_checkpoint(model, optimizer, epoch + 1, avg_val_loss, "image_diffusion_best.pt")

        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(model, optimizer, epoch + 1, avg_val_loss, "image_diffusion_latest.pt")

        early_stopping.step(avg_val_loss)
        if early_stopping.should_stop:
            break

    plot_losses(train_losses, val_losses, "Image Diffusion — Eğitim & Doğrulama Kaybı", "image_diffusion_loss.png")
    save_checkpoint(model, optimizer, num_epochs, avg_val_loss, "image_diffusion_latest.pt")
    
    total_time = time.time() - start_time
    print(f"\n[Image Diffusion] Eğitim tamamlandı! Süre: {total_time:.0f}s")
    print(f"[Image Diffusion] En iyi doğrulama kaybı: {best_val_loss:.5f}")

    return model, train_losses, val_losses


# ==============================================================================
# Test
# ==============================================================================
if __name__ == "__main__":
    from data_preprocessing import get_dataloaders

    print("=" * 60)
    print("Eğitim Testi (5 epoch, mock veri)")
    print("=" * 60)

    loaders = get_dataloaders(use_mock=True, batch_size=32)

    # Baseline eğitim testi
    baseline_model, bl_train_losses, bl_val_losses = train_baseline(
        loaders["baseline_train"], loaders["baseline_val"],
        num_epochs=5
    )

    # Hiyerarşik eğitim testi
    hier_model, hier_losses = train_hierarchical(
        loaders["hierarchical_train"], loaders["hierarchical_val"],
        num_epochs=5
    )

    print("\n[BAŞARILI] Eğitim testi tamamlandı!")
