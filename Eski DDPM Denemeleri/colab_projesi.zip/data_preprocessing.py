"""
data_preprocessing.py — Veri Seti Hazırlama ve Ön İşleme Modülü

RICO veri setinden UI bileşen bilgilerini yükler, hiyerarşik yapıya ayırır
ve PyTorch Dataset/DataLoader oluşturur. RICO bulunamazsa sentetik veri üretir.
"""

import os
import json
import random
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

from config import (
    DATA_DIR, RICO_JSON_DIR, NUM_CLASSES, COMPONENT_CLASSES,
    MAX_PANELS, MAX_COMPONENTS, MAX_ELEMENTS, FEATURE_DIM,
    PANEL_FEATURE_DIM, COMPONENT_FEATURE_DIM,
    BATCH_SIZE, MOCK_DATASET_SIZE, DEVICE
)


# ==============================================================================
# RICO Veri Seti İşleme Yardımcı Fonksiyonları
# ==============================================================================

# RICO bileşen türlerini projemizin sınıflarına eşleyen harita
RICO_CLASS_MAP = {
    # Orijinal RICO componentLabel eşlemeleri
    "Toolbar":       0,  # Panel
    "List Item":     0,  # Panel
    "Card":          0,  # Panel
    "Drawer":        0,  # Panel
    "Modal":         0,  # Panel
    "Bottom Navigation": 0,  # Panel
    "Tab Bar":       0,  # Panel
    "Button":        1,
    "Text Button":   1,
    "Icon Button":   1,
    "FAB":           1,
    "Input":         2,
    "Text":          3,
    "Text View":     3,
    "Icon":          4,
    "Checkbox":      5,
    "Check Box":     5,
    "Spinner":       6,
    "Slider":        7,
    "Switch":        8,
    "Toggle Button": 8,
    "Image":         9,
    "Image View":    9,
    "Web View":      9,
    # Android widget sınıf adı eşlemeleri (Hugging Face RICO formatı)
    "LinearLayout":  0,
    "RelativeLayout": 0,
    "FrameLayout":   0,
    "ConstraintLayout": 0,
    "CoordinatorLayout": 0,
    "RecyclerView":  0,
    "ListView":      0,
    "ScrollView":    0,
    "ViewGroup":     0,
    "CardView":      0,
    "NavigationView": 0,
    "TabLayout":     0,
    "AppBarLayout":  0,
    "ActionBar":     0,
    "button":        1,
    "Button":        1,
    "ImageButton":   1,
    "FloatingActionButton": 1,
    "EditText":      2,
    "AutoCompleteTextView": 2,
    "SearchView":    2,
    "TextInputLayout": 2,
    "TextInputEditText": 2,
    "TextView":      3,
    "ImageView":     9,
    "CheckBox":      5,
    "RadioButton":   5,
    "Spinner":       6,
    "SeekBar":       7,
    "ProgressBar":   7,
    "Switch":        8,
    "ToggleButton":  8,
    "CompoundButton": 8,
}

# Alt bileşen olarak kabul edilebilecek sınıflar (panel hariç)
CHILD_CLASSES = {1, 2, 3, 4, 5, 6, 7, 8, 9}
# Panel sınıfı
PANEL_CLASS = 0


def _parse_rico_hierarchy(node, screen_w, screen_h, panels, components, depth=0):
    """
    RICO JSON ağacını özyinelemeli olarak dolaşarak
    panelleri ve alt bileşenleri ayırır.
    """
    if not isinstance(node, dict):
        return

    bounds = node.get("bounds", None)
    # Öncelik: componentLabel > className > class (Android widget adı)
    class_name = node.get("componentLabel", node.get("className", node.get("class", "")))
    # Android tam sınıf adından kısa adı çıkar (ör. "android.widget.Button" -> "Button")
    if class_name and "." in class_name:
        class_name = class_name.rsplit(".", 1)[-1]

    mapped_class = None
    for key, val in RICO_CLASS_MAP.items():
        if key.lower() in class_name.lower():
            mapped_class = val
            break

    if bounds and mapped_class is not None and len(bounds) == 4:
        x_min = bounds[0] / screen_w
        y_min = bounds[1] / screen_h
        x_max = bounds[2] / screen_w
        y_max = bounds[3] / screen_h

        # Geçerlilik kontrolü
        if 0 <= x_min < x_max <= 1 and 0 <= y_min < y_max <= 1:
            w = x_max - x_min
            h = y_max - y_min
            if w > 0.02 and h > 0.02:  # Çok küçük elemanları atla
                if mapped_class == PANEL_CLASS and depth < 3:
                    panels.append([mapped_class, x_min, y_min, x_max, y_max])
                elif mapped_class in CHILD_CLASSES:
                    components.append([mapped_class, x_min, y_min, x_max, y_max])

    children = node.get("children", [])
    for child in children:
        _parse_rico_hierarchy(child, screen_w, screen_h, panels, components, depth + 1)


def _assign_components_to_panels(panels, components):
    """
    Her alt bileşeni, onu en iyi kapsayan (en küçük alanlı) panele atar.
    Hiçbir panele sığmazsa parent_idx = -1 kalır.
    Döndürülen format: [class_id, x_min, y_min, x_max, y_max, parent_panel_idx]
    """
    assigned = []
    for comp in components:
        _, cx1, cy1, cx2, cy2 = comp
        best_panel_idx = -1
        best_area = float("inf")

        for pi, panel in enumerate(panels):
            _, px1, py1, px2, py2 = panel
            # Bileşen panelin içinde mi?
            if cx1 >= px1 and cy1 >= py1 and cx2 <= px2 and cy2 <= py2:
                area = (px2 - px1) * (py2 - py1)
                if area < best_area:
                    best_area = area
                    best_panel_idx = pi

        assigned.append(comp + [best_panel_idx])

    return assigned


def load_rico_dataset():
    """
    RICO JSON dosyalarını yükleyerek hiyerarşik UI layout veri seti oluşturur.
    Hugging Face RICO-SCA formatını ve orijinal RICO formatını destekler.

    Returns:
        list of dict: Her eleman {'panels': [...], 'components': [...]} formatında
    """
    cache_path = os.path.join(DATA_DIR, "rico_dataset_cache.pt")
    
    # EĞER ÖNBELLEK (CACHE) VARSA ANINDA YÜKLE
    if os.path.exists(cache_path):
        print(f"[BİLGİ] Önbelleğe alınmış (cache) RICO veri seti bulunuyor: {cache_path}")
        try:
            dataset = torch.load(cache_path, weights_only=False)
            print(f"[BİLGİ] {len(dataset)} adet hazır layout saniyeler içinde yüklendi.")
            return dataset
        except Exception as e:
            print(f"[UYARI] Önbellek yüklenemedi: {e}. Yeniden parse edilecek...")

    dataset = []

    if not os.path.exists(RICO_JSON_DIR):
        print(f"[UYARI] RICO JSON dizini bulunamadı: {RICO_JSON_DIR}")
        print("[BİLGİ] Sentetik veri kullanılacak.")
        return None

    # Alt klasörleri de dahil ederek tüm JSON dosyalarını bul
    json_files = []
    for root_dir, dirs, files in os.walk(RICO_JSON_DIR):
        for f in files:
            if f.endswith(".json"):
                json_files.append(os.path.join(root_dir, f))

    if len(json_files) == 0:
        print("[UYARI] RICO JSON dosyası bulunamadı. Sentetik veri kullanılacak.")
        return None

    print(f"[BİLGİ] {len(json_files)} adet RICO JSON dosyası bulundu.")

    skipped = 0
    for jf_path in json_files:
        try:
            with open(jf_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Format tespiti: Hugging Face RICO-SCA mı, orijinal RICO mı?
            root = None

            if "view_hierarchy" in data:
                # Hugging Face RICO-SCA formatı: view_hierarchy bir JSON string
                vh = data["view_hierarchy"]
                if isinstance(vh, str):
                    vh = json.loads(vh)
                activity = vh.get("activity", {})
                root = activity.get("root", vh)
            elif "activity" in data:
                # Orijinal RICO formatı
                activity = data.get("activity", {})
                root = activity.get("root", data)
            else:
                # Doğrudan root düğüm olabilir
                root = data

            if root is None:
                skipped += 1
                continue

            # RICO ekran boyutu genellikle 1440x2560
            screen_w = 1440
            screen_h = 2560

            panels = []
            components = []
            _parse_rico_hierarchy(root, screen_w, screen_h, panels, components)

            if len(panels) == 0:
                skipped += 1
                continue

            panels = panels[:MAX_PANELS]
            components = _assign_components_to_panels(panels, components)
            components = components[:MAX_COMPONENTS]

            if len(components) >= 3:
                dataset.append({
                    "panels": panels,
                    "components": components,
                    "image_path": jf_path.replace('.json', '.png')
                })
            else:
                skipped += 1
        except Exception as e:
            skipped += 1
            continue

    print(f"[BİLGİ] {len(dataset)} adet geçerli layout yüklendi. ({skipped} atlandı)")
    
    # İŞLENMİŞ (PARSE EDİLMİŞ) VERİYİ ÖNBELLEĞE KAYDET
    if len(dataset) > 0:
        try:
            # Klasör yoksa oluştur (güvenlik için)
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            torch.save(dataset, cache_path)
            print(f"[BİLGİ] Veri seti önbelleğe (cache) kaydedildi: {cache_path}")
            print("[BİLGİ] Bir sonraki eğitim başlatışınızda 15 dakika beklemeyeceksiniz, anında yüklenecektir.")
        except Exception as e:
            print(f"[UYARI] Veri seti önbelleğe kaydedilemedi: {e}")

    return dataset if len(dataset) > 0 else None


# ==============================================================================
# Sentetik (Mock) Veri Üretici
# ==============================================================================

def generate_mock_layout():
    """
    Gerçekçi bir IDE eklenti arayüzü layout'u sentetik olarak üretir.
    
    Üretim Stratejisi:
    1. Rastgele 1-MAX_PANELS adet panel yerleştir (üst üste binmeden)
    2. Her panelin içine rastgele alt bileşenler yerleştir
    
    Returns:
        dict: {'panels': [[cls, x1, y1, x2, y2], ...], 
               'components': [[cls, x1, y1, x2, y2, parent_idx], ...]}
    """
    panels = []
    components = []
    num_panels = random.randint(1, MAX_PANELS)

    # Panel yerleşim stratejileri (IDE benzeri düzenler)
    layout_type = random.choice(["vertical_split", "horizontal_split", "grid", "sidebar"])

    if layout_type == "vertical_split":
        # Dikey bölümleme: Ekranı dikey şeritlere böl
        x_positions = sorted([0.0] + sorted(random.sample(
            [i / 10.0 for i in range(1, 10)], min(num_panels - 1, 8)
        )) + [1.0])
        for i in range(min(num_panels, len(x_positions) - 1)):
            y_start = random.uniform(0.0, 0.1)
            y_end = random.uniform(0.85, 1.0)
            panels.append([PANEL_CLASS, x_positions[i], y_start, x_positions[i + 1], y_end])

    elif layout_type == "horizontal_split":
        # Yatay bölümleme: Ekranı yatay şeritlere böl
        y_positions = sorted([0.0] + sorted(random.sample(
            [i / 10.0 for i in range(1, 10)], min(num_panels - 1, 8)
        )) + [1.0])
        for i in range(min(num_panels, len(y_positions) - 1)):
            x_start = random.uniform(0.0, 0.05)
            x_end = random.uniform(0.9, 1.0)
            panels.append([PANEL_CLASS, x_start, y_positions[i], x_end, y_positions[i + 1]])

    elif layout_type == "grid":
        # Izgara düzeni
        cols = random.choice([1, 2])
        rows = max(1, (num_panels + cols - 1) // cols)
        for r in range(rows):
            for c in range(cols):
                if len(panels) >= num_panels:
                    break
                margin = 0.02
                x1 = c / cols + margin
                y1 = r / rows + margin
                x2 = (c + 1) / cols - margin
                y2 = (r + 1) / rows - margin
                panels.append([PANEL_CLASS, x1, y1, x2, y2])

    else:  # sidebar
        # Kenar çubuğu + ana alan
        sidebar_w = random.uniform(0.15, 0.3)
        panels.append([PANEL_CLASS, 0.0, 0.0, sidebar_w, 1.0])
        if num_panels >= 2:
            panels.append([PANEL_CLASS, sidebar_w + 0.01, 0.0, 1.0, 1.0])
        for _ in range(num_panels - 2):
            parent = panels[1] if len(panels) > 1 else panels[0]
            px1, py1, px2, py2 = parent[1], parent[2], parent[3], parent[4]
            pw, ph = px2 - px1, py2 - py1
            cx1 = px1 + random.uniform(0, pw * 0.3)
            cy1 = py1 + random.uniform(0, ph * 0.3)
            cx2 = cx1 + random.uniform(pw * 0.2, pw * 0.6)
            cy2 = cy1 + random.uniform(ph * 0.2, ph * 0.6)
            cx2 = min(cx2, px2)
            cy2 = min(cy2, py2)
            if cx2 > cx1 + 0.05 and cy2 > cy1 + 0.05:
                panels.append([PANEL_CLASS, cx1, cy1, cx2, cy2])

    panels = panels[:MAX_PANELS]

    # Her panelin içine alt bileşenler yerleştir
    for panel_idx, panel in enumerate(panels):
        _, px1, py1, px2, py2 = panel
        pw = px2 - px1
        ph = py2 - py1

        remaining = MAX_COMPONENTS - len(components)
        if remaining <= 0:
            continue
        num_comps = random.randint(1, min(6, remaining))
        if num_comps <= 0:
            continue

        # Bileşenleri sıralı yerleştirme (IDE benzeri düzen)
        comp_strategy = random.choice(["vertical_list", "form", "toolbar", "mixed"])

        if comp_strategy == "vertical_list":
            # Dikey sıralı elemanlar (menü gibi)
            step = ph / (num_comps + 1)
            for i in range(num_comps):
                cls = random.choice([1, 3, 4])  # Button, Label, Icon
                margin_x = pw * random.uniform(0.05, 0.15)
                h = step * random.uniform(0.4, 0.8)
                cx1 = px1 + margin_x
                cy1 = py1 + step * (i + 0.5) - h / 2
                cx2 = px2 - margin_x
                cy2 = cy1 + h
                # Sınırlar içinde tut
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

        elif comp_strategy == "form":
            # Form düzeni: Label + TextInput çiftleri
            step = ph / (num_comps + 1)
            for i in range(num_comps):
                cls = 2 if i % 2 == 1 else 3  # TextInput / Label
                margin_x = pw * 0.1
                h = step * random.uniform(0.3, 0.6)
                cx1 = px1 + margin_x
                cy1 = py1 + step * (i + 0.5) - h / 2
                cx2 = px2 - margin_x
                cy2 = cy1 + h
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

        elif comp_strategy == "toolbar":
            # Yatay araç çubuğu düzeni
            step = pw / (num_comps + 1)
            for i in range(num_comps):
                cls = random.choice([1, 4, 8])  # Button, Icon, Toggle
                w = step * random.uniform(0.4, 0.8)
                margin_y = ph * 0.15
                cx1 = px1 + step * (i + 0.5) - w / 2
                cy1 = py1 + margin_y
                cx2 = cx1 + w
                cy2 = py2 - margin_y
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

        else:  # mixed
            # Karışık yerleşim
            for _ in range(num_comps):
                cls = random.randint(1, NUM_CLASSES - 1)
                margin = 0.02
                w = random.uniform(0.1, 0.5) * pw
                h = random.uniform(0.05, 0.3) * ph
                cx1 = px1 + random.uniform(margin, max(margin, pw - w - margin))
                cy1 = py1 + random.uniform(margin, max(margin, ph - h - margin))
                cx2 = cx1 + w
                cy2 = cy1 + h
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

    components = components[:MAX_COMPONENTS]

    return {"panels": panels, "components": components, "image_path": ""}


def generate_mock_dataset(size=MOCK_DATASET_SIZE):
    """
    Belirtilen sayıda sentetik layout üretir.
    """
    print(f"[BİLGİ] {size} adet sentetik layout üretiliyor...")
    dataset = [generate_mock_layout() for _ in range(size)]
    print(f"[BİLGİ] Sentetik veri seti hazır. Toplam: {len(dataset)} layout.")
    return dataset


# ==============================================================================
# PyTorch Dataset Sınıfları
# ==============================================================================

class BaselineLayoutDataset(Dataset):
    """
    Baseline (tek aşamalı) DDPM için veri seti.
    Tüm elemanlar (panel + bileşen) düz bir listeye dönüştürülür.
    Her eleman: [class_id / NUM_CLASSES, x_min, y_min, x_max, y_max]
    Padding ile sabit boyuta getirilir.
    """

    def __init__(self, raw_data):
        """
        Args:
            raw_data: list of dict, her dict {'panels': [...], 'components': [...]}
        """
        self.data = []
        for item in raw_data:
            elements = []

            # Panelleri ekle
            for panel in item["panels"]:
                cls_norm = panel[0] / max(NUM_CLASSES - 1, 1)
                elements.append([cls_norm, panel[1], panel[2], panel[3], panel[4]])

            # Bileşenleri ekle (parent_idx hariç)
            for comp in item["components"]:
                cls_norm = comp[0] / max(NUM_CLASSES - 1, 1)
                elements.append([cls_norm, comp[1], comp[2], comp[3], comp[4]])

            # Padding (MAX_ELEMENTS'e kadar sıfırla doldur)
            elements = elements[:MAX_ELEMENTS]
            while len(elements) < MAX_ELEMENTS:
                elements.append([0.0, 0.0, 0.0, 0.0, 0.0])

            tensor_data = torch.tensor(elements, dtype=torch.float32)
            # [-1, 1] normalizasyonu (DDPM için zorunlu)
            tensor_data = (tensor_data * 2.0) - 1.0
            
            self.data.append(tensor_data)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class HierarchicalLayoutDataset(Dataset):
    """
    Hiyerarşik (iki aşamalı) DDPM için veri seti.
    Paneller ve alt bileşenler ayrı tensörler olarak döndürülür.
    
    panels:     [MAX_PANELS, PANEL_FEATURE_DIM]
    components: [MAX_COMPONENTS, COMPONENT_FEATURE_DIM]
    panel_mask: [MAX_PANELS] — hangi paneller gerçek, hangileri padding
    comp_mask:  [MAX_COMPONENTS] — hangi bileşenler gerçek, hangileri padding
    """

    def __init__(self, raw_data):
        self.panels_list = []
        self.components_list = []
        self.panel_masks = []
        self.comp_masks = []

        for item in raw_data:
            # Paneller
            panels = []
            panel_mask = []
            for p in item["panels"][:MAX_PANELS]:
                cls_norm = p[0] / max(NUM_CLASSES - 1, 1)
                panels.append([cls_norm, p[1], p[2], p[3], p[4]])
                panel_mask.append(1.0)
            while len(panels) < MAX_PANELS:
                panels.append([0.0, 0.0, 0.0, 0.0, 0.0])
                panel_mask.append(0.0)

            # Bileşenler
            components = []
            comp_mask = []
            for c in item["components"][:MAX_COMPONENTS]:
                cls_norm = c[0] / max(NUM_CLASSES - 1, 1)
                parent_norm = (c[5] + 1) / (MAX_PANELS + 1)  # -1 → 0, 0 → 1/6, ...
                components.append([cls_norm, c[1], c[2], c[3], c[4], parent_norm])
                comp_mask.append(1.0)
            while len(components) < MAX_COMPONENTS:
                components.append([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
                comp_mask.append(0.0)

            panels_tensor = torch.tensor(panels, dtype=torch.float32)
            components_tensor = torch.tensor(components, dtype=torch.float32)
            
            # [-1, 1] normalizasyonu
            panels_tensor = (panels_tensor * 2.0) - 1.0
            components_tensor = (components_tensor * 2.0) - 1.0

            self.panels_list.append(panels_tensor)
            self.components_list.append(components_tensor)
            self.panel_masks.append(torch.tensor(panel_mask, dtype=torch.float32))
            self.comp_masks.append(torch.tensor(comp_mask, dtype=torch.float32))

    def __len__(self):
        return len(self.panels_list)

    def __getitem__(self, idx):
        return {
            "panels": self.panels_list[idx],
            "components": self.components_list[idx],
            "panel_mask": self.panel_masks[idx],
            "comp_mask": self.comp_masks[idx],
        }


# ==============================================================================
# Aşama 2 (Görsel Difüzyonu) Veri Sınıfı
# ==============================================================================

def render_layout_to_image(panels, components, image_size=64, image_path=""):
    """
    Öncelikle gönderilen image_path geçerliyse gerçek resmi yükler. Yoksa
    kutu koordinatlarından 64x64 boyutunda "Sentetik/Mock UI Rengi" üretir.
    Sınıf Haritası (Condition Mask) her zaman üretilir.
    
    Returns:
        img_tensor: [3, 64, 64] RGB hedef görseli ([-1, 1] arası normalize)
        cond_tensor: [NUM_CLASSES, 64, 64] Koşullandırma sınıf maskesi
    """
    from config import CLASS_COLORS, NUM_CLASSES
    from PIL import Image
    
    # Koşul maskesi (Condition) her zaman bbox'lardan üretilir
    cond = np.zeros((NUM_CLASSES, image_size, image_size), dtype=np.float32)

    def draw_box(box, cls_id):
        cls_id = int(cls_id)
        x1, y1 = int(box[1] * image_size), int(box[2] * image_size)
        x2, y2 = int(box[3] * image_size), int(box[4] * image_size)
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(image_size, x2), min(image_size, y2)
        
        if x2 > x1 and y2 > y1:
            cond[cls_id, y1:y2, x1:x2] = 1.0

    for p in panels:
        draw_box(p, p[0])
    for c in components:
        draw_box(c, c[0])
        
    cond_tensor = torch.tensor(cond) # [NUM_CLASSES, 64, 64]

    # Hedef Resim: Gerçek resim varsa onu kullan
    if image_path and os.path.exists(image_path):
        try:
            pil_img = Image.open(image_path).convert("RGB")
            pil_img = pil_img.resize((image_size, image_size))
            img = np.array(pil_img, dtype=np.float32)
        except Exception:
            img = np.ones((image_size, image_size, 3), dtype=np.float32) * 255.0
    else:
        # Sentetik resim (Eski yöntem)
        img = np.ones((image_size, image_size, 3), dtype=np.float32) * 255.0
        def draw_color_box(box, cls_id):
            cls_id = int(cls_id)
            x1, y1 = int(box[1] * image_size), int(box[2] * image_size)
            x2, y2 = int(box[3] * image_size), int(box[4] * image_size)
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(image_size, x2), min(image_size, y2)
            if x2 > x1 and y2 > y1:
                color = CLASS_COLORS.get(cls_id, (100, 100, 100))
                if len(color) > 3:
                    color = color[:3]
                img[y1:y2, x1:x2, :] = color

        for p in panels:
            draw_color_box(p, p[0])
        for c in components:
            draw_color_box(c, c[0])

    # [-1, 1] Normalizasyonu (Difüzyon U-Net için standart)
    img = (img / 127.5) - 1.0
    
    img_tensor = torch.tensor(img).permute(2, 0, 1) # [3, 64, 64]
    return img_tensor, cond_tensor

class ImageDiffusionDataset(Dataset):
    """
    Aşama 2 için RGB Target Mask + Condition Mask DataLoader'ı.
    """
    def __init__(self, data_list):
        self.data_list = data_list
        from config import IMAGE_SIZE
        self.image_size = IMAGE_SIZE

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        item = self.data_list[idx]
        img_path = item.get("image_path", "")
        img_tensor, cond_tensor = render_layout_to_image(
            item["panels"], item["components"], self.image_size, img_path
        )
        return {
            "image": img_tensor,       # Hedef: Pikseller
            "condition": cond_tensor,  # Girdi (Koşul): Segmentasyon Maskesi
        }

# ==============================================================================
# DataLoader Oluşturucu
# ==============================================================================

def get_dataloaders(use_mock=False, batch_size=BATCH_SIZE, val_split=0.1):
    """
    Eğitim ve doğrulama DataLoader'larını oluşturur.
    
    Args:
        use_mock: True ise sentetik veri kullanır
        batch_size: Batch boyutu
        val_split: Doğrulama seti oranı
    
    Returns:
        dict: {
            'baseline_train': DataLoader,
            'baseline_val': DataLoader,
            'hierarchical_train': DataLoader,
            'hierarchical_val': DataLoader,
            'raw_data': list
        }
    """
    # Veri yükleme
    raw_data = None
    if not use_mock:
        raw_data = load_rico_dataset()

    if raw_data is None:
        raw_data = generate_mock_dataset()

    # Eğitim/doğrulama bölme
    random.shuffle(raw_data)
    val_size = max(1, int(len(raw_data) * val_split))
    train_data = raw_data[val_size:]
    val_data = raw_data[:val_size]

    print(f"[BİLGİ] Eğitim seti: {len(train_data)}, Doğrulama seti: {len(val_data)}")

    # Baseline DataLoader
    baseline_train_ds = BaselineLayoutDataset(train_data)
    baseline_val_ds = BaselineLayoutDataset(val_data)

    baseline_train_loader = DataLoader(
        baseline_train_ds, batch_size=batch_size, shuffle=True, drop_last=True
    )
    baseline_val_loader = DataLoader(
        baseline_val_ds, batch_size=batch_size, shuffle=False
    )

    # Hierarchical DataLoader
    hier_train_ds = HierarchicalLayoutDataset(train_data)
    hier_val_ds = HierarchicalLayoutDataset(val_data)

    hier_train_loader = DataLoader(
        hier_train_ds, batch_size=batch_size, shuffle=True, drop_last=True
    )
    hier_val_loader = DataLoader(
        hier_val_ds, batch_size=batch_size, shuffle=False
    )

    # Image Diffusion DataLoader (Aşama 2)
    image_train_ds = ImageDiffusionDataset(train_data)
    image_val_ds = ImageDiffusionDataset(val_data)
    
    image_train_loader = DataLoader(
        image_train_ds, batch_size=batch_size, shuffle=True, drop_last=True
    )
    image_val_loader = DataLoader(
        image_val_ds, batch_size=batch_size, shuffle=False
    )

    return {
        "baseline_train": baseline_train_loader,
        "baseline_val": baseline_val_loader,
        "hierarchical_train": hier_train_loader,
        "hierarchical_val": hier_val_loader,
        "image_train": image_train_loader,
        "image_val": image_val_loader,
        "raw_data": raw_data,
    }


# ==============================================================================
# Test
# ==============================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("Veri Ön İşleme Testi")
    print("=" * 60)

    loaders = get_dataloaders(use_mock=True, batch_size=4)

    # Baseline veri yapısını test et
    for batch in loaders["baseline_train"]:
        print(f"\n[Baseline] Batch shape: {batch.shape}")
        print(f"  İlk örnek, ilk eleman: {batch[0, 0]}")
        break

    # Hiyerarşik veri yapısını test et
    for batch in loaders["hierarchical_train"]:
        print(f"\n[Hierarchical] Panels shape: {batch['panels'].shape}")
        print(f"  Components shape: {batch['components'].shape}")
        print(f"  Panel mask: {batch['panel_mask'][0]}")
        print(f"  Comp mask sum: {batch['comp_mask'][0].sum().item()}")
        break

    print("\n[BAŞARILI] Veri ön işleme testi tamamlandı!")
