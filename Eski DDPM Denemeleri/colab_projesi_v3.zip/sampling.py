"""
sampling.py — Örnekleme ve Kısıt-Kılavuzlu Denoising

DDPM/DDIM ters sürecini kullanarak gürültüden UI layout üretir.
Kısıt-kılavuzlu (constraint-guided) denoising ile:
- Koordinatları [0,1] sınırlarında tutar
- Alt bileşenleri ana panelin içinde tutar (containment)
- Üst üste binmeyi engelleyen iteratif düzeltme (non-overlap)
"""

import torch
import json
import os
from tqdm import tqdm

from config import (
    T, DEVICE, APPLY_CONSTRAINTS, NUM_SAMPLES,
    MAX_ELEMENTS, MAX_PANELS, MAX_COMPONENTS,
    FEATURE_DIM, PANEL_FEATURE_DIM, COMPONENT_FEATURE_DIM,
    NUM_CLASSES, COMPONENT_CLASSES, SAMPLES_DIR,
    USE_DDIM, DDIM_STEPS,
    denormalize_class_id, denormalize_parent_idx,
)
from model import NoiseScheduler


# ==============================================================================
# Kısıt Fonksiyonları (Constraint Functions)
# ==============================================================================

def apply_coordinate_clamp(x):
    """Tüm koordinatları [-1, 1] arasında sınırlar."""
    return torch.clamp(x, -1.0, 1.0)


def apply_valid_bbox(x, feature_dim):
    """
    x_min < x_max ve y_min < y_max olmasını sağlar.
    [-1, 1] aralığında çalışır.
    """
    if feature_dim >= 5:
        x = x.clone()
        x_min = x[..., 1:2]
        x_max = x[..., 3:4]
        new_x_min = torch.min(x_min, x_max)
        new_x_max = torch.max(x_min, x_max)
        # [-1,1] aralığında minimum boyut: 0.04 (≈%2 orijinal ölçekte)
        min_size = 0.04
        new_x_max = torch.max(new_x_max, new_x_min + min_size)
        new_x_max = torch.clamp(new_x_max, max=1.0)

        y_min = x[..., 2:3]
        y_max = x[..., 4:5]
        new_y_min = torch.min(y_min, y_max)
        new_y_max = torch.max(y_min, y_max)
        new_y_max = torch.max(new_y_max, new_y_min + min_size)
        new_y_max = torch.clamp(new_y_max, max=1.0)

        x[..., 1:2] = new_x_min
        x[..., 2:3] = new_y_min
        x[..., 3:4] = new_x_max
        x[..., 4:5] = new_y_max

    return x


def apply_containment_constraint(components, panels, max_panels):
    """
    Alt bileşenlerin ana panellerinin sınırları içinde kalmasını sağlar.
    Tüm değerler [-1, 1] aralığındadır.
    """
    components = components.clone()
    batch_size = components.shape[0]

    for b in range(batch_size):
        for c in range(components.shape[1]):
            # parent_norm [-1, 1] → [0, 1]
            parent_norm = components[b, c, 5].item()
            parent_norm_01 = (parent_norm + 1.0) / 2.0
            parent_idx = denormalize_parent_idx(parent_norm_01)

            if parent_idx < 0 or parent_idx >= max_panels:
                continue

            # Panel sınırları ([-1, 1] aralığında)
            px1 = panels[b, parent_idx, 1].item()
            py1 = panels[b, parent_idx, 2].item()
            px2 = panels[b, parent_idx, 3].item()
            py2 = panels[b, parent_idx, 4].item()

            if px2 <= px1 or py2 <= py1:
                continue

            margin = 0.01  # [-1,1] aralığında ~0.5% margin
            cx1 = max(components[b, c, 1].item(), px1 + margin)
            cy1 = max(components[b, c, 2].item(), py1 + margin)
            cx2 = min(components[b, c, 3].item(), px2 - margin)
            cy2 = min(components[b, c, 4].item(), py2 - margin)

            if cx2 <= cx1:
                mid = (px1 + px2) / 2
                cx1 = mid - 0.02
                cx2 = mid + 0.02
            if cy2 <= cy1:
                mid = (py1 + py2) / 2
                cy1 = mid - 0.02
                cy2 = mid + 0.02

            components[b, c, 1] = cx1
            components[b, c, 2] = cy1
            components[b, c, 3] = cx2
            components[b, c, 4] = cy2

    return components


def apply_non_overlap_correction(x, feature_dim, max_iter=3):
    """Üst üste binen bounding box'ları iteratif olarak düzeltir."""
    x = x.clone()
    batch_size, num_elem, _ = x.shape

    for _ in range(max_iter):
        for b in range(batch_size):
            for i in range(num_elem):
                for j in range(i + 1, num_elem):
                    if x[b, i, 1:5].abs().sum().item() < 0.1:
                        continue
                    if x[b, j, 1:5].abs().sum().item() < 0.1:
                        continue

                    ix1 = max(x[b, i, 1].item(), x[b, j, 1].item())
                    iy1 = max(x[b, i, 2].item(), x[b, j, 2].item())
                    ix2 = min(x[b, i, 3].item(), x[b, j, 3].item())
                    iy2 = min(x[b, i, 4].item(), x[b, j, 4].item())

                    if ix1 < ix2 and iy1 < iy2:
                        overlap_w = ix2 - ix1
                        overlap_h = iy2 - iy1

                        if overlap_w < overlap_h:
                            shift = overlap_w / 2.0 + 0.01
                            if x[b, i, 1].item() < x[b, j, 1].item():
                                x[b, i, 1] -= shift
                                x[b, i, 3] -= shift
                                x[b, j, 1] += shift
                                x[b, j, 3] += shift
                            else:
                                x[b, i, 1] += shift
                                x[b, i, 3] += shift
                                x[b, j, 1] -= shift
                                x[b, j, 3] -= shift
                        else:
                            shift = overlap_h / 2.0 + 0.01
                            if x[b, i, 2].item() < x[b, j, 2].item():
                                x[b, i, 2] -= shift
                                x[b, i, 4] -= shift
                                x[b, j, 2] += shift
                                x[b, j, 4] += shift
                            else:
                                x[b, i, 2] += shift
                                x[b, i, 4] += shift
                                x[b, j, 2] -= shift
                                x[b, j, 4] -= shift

    x[..., 1:5] = torch.clamp(x[..., 1:5], -1.0, 1.0)
    return x


# ==============================================================================
# DDIM Örnekleme (Hızlı — 50-100 adım yeterli)
# ==============================================================================

def ddim_sample_loop(model_fn, scheduler, x, num_steps=DDIM_STEPS, eta=0.0):
    """
    DDIM deterministic/stochastic örnekleme.
    eta=0: tamamen deterministik, eta=1: DDPM'e eşdeğer.
    """
    # Eşit aralıklı zaman adımları seç
    step_size = T // num_steps
    timesteps = list(range(T - 1, -1, -step_size))
    if timesteps[-1] != 0:
        timesteps.append(0)

    for i, t in enumerate(tqdm(timesteps, desc="DDIM Sampling", leave=False)):
        t_tensor = torch.full((x.shape[0],), t, device=x.device, dtype=torch.long)
        noise_pred = model_fn(x, t_tensor)

        alpha_bar_t = scheduler.alpha_bars[t]
        alpha_bar_prev = scheduler.alpha_bars[timesteps[i + 1]] if i + 1 < len(timesteps) else torch.tensor(1.0, device=x.device)

        # x_0 tahmini
        pred_x0 = (x - torch.sqrt(1.0 - alpha_bar_t) * noise_pred) / torch.sqrt(alpha_bar_t)
        pred_x0 = torch.clamp(pred_x0, -1.0, 1.0)

        # DDIM formülü
        sigma = eta * torch.sqrt(
            (1 - alpha_bar_prev) / (1 - alpha_bar_t) * (1 - alpha_bar_t / alpha_bar_prev)
        )
        dir_xt = torch.sqrt(torch.clamp(1.0 - alpha_bar_prev - sigma ** 2, min=0.0)) * noise_pred
        x = torch.sqrt(alpha_bar_prev) * pred_x0 + dir_xt

        if t > 0 and eta > 0:
            noise = torch.randn_like(x)
            x = x + sigma * noise

    return x


def ddpm_sample_loop(model_fn, scheduler, x):
    """Standart DDPM ters difüzyon döngüsü."""
    for t in tqdm(range(T - 1, -1, -1), desc="DDPM Sampling", leave=False):
        t_tensor = torch.full((x.shape[0],), t, device=x.device, dtype=torch.long)
        noise_pred = model_fn(x, t_tensor)

        alpha_bar_t = scheduler.alpha_bars[t]
        alpha_t = scheduler.alphas[t]
        alpha_bar_prev_t = scheduler.alpha_bars_prev[t]
        beta_t = scheduler.betas[t]

        pred_x0 = (x - torch.sqrt(1.0 - alpha_bar_t) * noise_pred) / torch.sqrt(alpha_bar_t)
        pred_x0 = torch.clamp(pred_x0, -1.0, 1.0)

        mean = (
            torch.sqrt(alpha_bar_prev_t) * beta_t / (1.0 - alpha_bar_t) * pred_x0
            + torch.sqrt(alpha_t) * (1.0 - alpha_bar_prev_t) / (1.0 - alpha_bar_t) * x
        )

        if t > 0:
            noise = torch.randn_like(x)
            sigma = torch.sqrt(scheduler.posterior_variance[t])
            x = mean + sigma * noise
        else:
            x = mean

    return x


# ==============================================================================
# Baseline DDPM Örnekleme
# ==============================================================================

def sample_baseline(model, scheduler, num_samples=NUM_SAMPLES,
                    apply_constraints=APPLY_CONSTRAINTS, use_ddim=USE_DDIM):
    """Baseline DDPM ile gürültüden layout üretir."""
    model.eval()
    print(f"\n[Baseline Sampling] {num_samples} adet layout üretiliyor...")

    with torch.no_grad():
        x = torch.randn(num_samples, MAX_ELEMENTS, FEATURE_DIM, device=DEVICE)

        model_fn = lambda xt, tt: model(xt, tt)
        if use_ddim:
            x = ddim_sample_loop(model_fn, scheduler, x)
        else:
            x = ddpm_sample_loop(model_fn, scheduler, x)

        x = apply_coordinate_clamp(x)
        x = apply_valid_bbox(x, FEATURE_DIM)
        if apply_constraints:
            x = apply_non_overlap_correction(x, FEATURE_DIM)

        # [-1, 1] → [0, 1]
        x = (x + 1.0) / 2.0
        x = torch.clamp(x, 0.0, 1.0)

    print(f"[Baseline Sampling] Tamamlandı.")
    return x.cpu()


# ==============================================================================
# Hiyerarşik DDPM Örnekleme
# ==============================================================================

def sample_hierarchical(model, scheduler, num_samples=NUM_SAMPLES,
                        apply_constraints=APPLY_CONSTRAINTS, use_ddim=USE_DDIM):
    """Hiyerarşik DDPM ile iki aşamalı layout üretimi."""
    model.eval()

    # ---- AŞAMA 1: Panel Üretimi ----
    print(f"\n[Hiyerarşik Sampling] Aşama 1: Panel üretimi ({num_samples} adet)...")
    with torch.no_grad():
        panels = torch.randn(num_samples, MAX_PANELS, PANEL_FEATURE_DIM, device=DEVICE)

        panel_fn = lambda xt, tt: model.forward_panel(xt, tt)
        if use_ddim:
            panels = ddim_sample_loop(panel_fn, scheduler, panels)
        else:
            panels = ddpm_sample_loop(panel_fn, scheduler, panels)

        panels = apply_coordinate_clamp(panels)
        panels = apply_valid_bbox(panels, PANEL_FEATURE_DIM)
        if apply_constraints:
            panels = apply_non_overlap_correction(panels, PANEL_FEATURE_DIM)

    # ---- AŞAMA 2: Bileşen Üretimi ----
    print(f"[Hiyerarşik Sampling] Aşama 2: Bileşen üretimi...")
    with torch.no_grad():
        components = torch.randn(
            num_samples, MAX_COMPONENTS, COMPONENT_FEATURE_DIM, device=DEVICE
        )

        comp_fn = lambda xt, tt: model.forward_component(xt, tt, panels)
        if use_ddim:
            components = ddim_sample_loop(comp_fn, scheduler, components)
        else:
            components = ddpm_sample_loop(comp_fn, scheduler, components)

        components = apply_coordinate_clamp(components)
        components = apply_valid_bbox(components, COMPONENT_FEATURE_DIM)
        if apply_constraints:
            components = apply_containment_constraint(components, panels, MAX_PANELS)
            components = apply_non_overlap_correction(components, COMPONENT_FEATURE_DIM)

        # [-1, 1] → [0, 1]
        panels = (panels + 1.0) / 2.0
        panels = torch.clamp(panels, 0.0, 1.0)

        components = (components + 1.0) / 2.0
        components = torch.clamp(components, 0.0, 1.0)

    panels_cpu = panels.cpu()
    components_cpu = components.cpu()
    print(f"[Hiyerarşik Sampling] Tamamlandı.")

    return panels_cpu, components_cpu


# ==============================================================================
# Aşama 2 (Görsel Difüzyonu) Örnekleme
# ==============================================================================

def sample_image_diffusion(model, scheduler, panels, components,
                           num_samples=NUM_SAMPLES, use_ddim=USE_DDIM):
    """Layout koşullu görsel üretimi."""
    model.eval()
    from data_preprocessing import render_layout_to_image
    from config import IMAGE_SIZE

    conditions = []
    print(f"\n[Aşama 2 Sampling] Layout maskeleri hazırlanıyor...")
    for i in range(num_samples):
        p = panels[i].numpy() if isinstance(panels, torch.Tensor) else panels[i]
        c = components[i].numpy() if isinstance(components, torch.Tensor) else components[i]
        _, cond_tensor = render_layout_to_image(p, c, image_size=IMAGE_SIZE)
        conditions.append(cond_tensor)

    cond_batch = torch.stack(conditions).to(DEVICE)

    print(f"[Aşama 2 Sampling] {num_samples} adet görsel üretiliyor...")
    with torch.no_grad():
        x = torch.randn(num_samples, 3, IMAGE_SIZE, IMAGE_SIZE, device=DEVICE)

        img_fn = lambda xt, tt: model(xt, tt, cond_batch)
        if use_ddim:
            x = ddim_sample_loop(img_fn, scheduler, x)
        else:
            x = ddpm_sample_loop(img_fn, scheduler, x)

    print("[Aşama 2 Sampling] Tamamlandı.")
    return x.cpu()


def generated_images_to_png(images_tensor, filename_prefix="generated_ui"):
    """Üretilen difüzyon görsellerini PNG olarak kaydeder."""
    import matplotlib.pyplot as plt

    os.makedirs(SAMPLES_DIR, exist_ok=True)

    batch_size = images_tensor.shape[0]

    images_tensor = (images_tensor + 1.0) / 2.0
    images_tensor = torch.clamp(images_tensor, 0.0, 1.0)

    for i in range(batch_size):
        img_np = images_tensor[i].permute(1, 2, 0).numpy()
        path = os.path.join(SAMPLES_DIR, f"{filename_prefix}_{i}.png")
        plt.imsave(path, img_np)

    print(f"[PNG] {batch_size} adet görsel kaydedildi: {SAMPLES_DIR}")


# ==============================================================================
# Sonuçları JSON Olarak Kaydetme
# ==============================================================================

def _denormalize_class(cls_norm):
    """Normalize edilmiş sınıf ID'sini gerçek sınıf adına çevirir."""
    cls_idx = denormalize_class_id(cls_norm)
    if cls_idx < 0 or cls_idx >= NUM_CLASSES:
        return "Padding"
    return COMPONENT_CLASSES[cls_idx]


def baseline_samples_to_json(samples, filename="baseline_samples.json"):
    """Baseline model çıktısını JSON formatına çevirir."""
    results = []
    for i in range(samples.shape[0]):
        layout = {"id": i, "elements": []}
        for j in range(samples.shape[1]):
            elem = samples[i, j]
            if elem[1:5].sum().item() < 0.01:
                continue
            cls_name = _denormalize_class(elem[0].item())
            if cls_name == "Padding":
                continue
            layout["elements"].append({
                "class": cls_name,
                "x_min": round(elem[1].item(), 4),
                "y_min": round(elem[2].item(), 4),
                "x_max": round(elem[3].item(), 4),
                "y_max": round(elem[4].item(), 4),
            })
        results.append(layout)

    path = os.path.join(SAMPLES_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[JSON] {len(results)} layout kaydedildi: {path}")
    return results


def hierarchical_samples_to_json(panels, components,
                                  filename="hierarchical_samples.json"):
    """Hiyerarşik model çıktısını JSON formatına çevirir."""
    results = []
    for i in range(panels.shape[0]):
        layout = {"id": i, "panels": [], "components": []}

        for j in range(panels.shape[1]):
            p = panels[i, j]
            if p[1:5].sum().item() < 0.01:
                continue
            cls_name = _denormalize_class(p[0].item())
            if cls_name == "Padding":
                continue
            layout["panels"].append({
                "class": cls_name,
                "x_min": round(p[1].item(), 4),
                "y_min": round(p[2].item(), 4),
                "x_max": round(p[3].item(), 4),
                "y_max": round(p[4].item(), 4),
            })

        for j in range(components.shape[1]):
            c = components[i, j]
            if c[1:5].sum().item() < 0.01:
                continue
            cls_name = _denormalize_class(c[0].item())
            if cls_name == "Padding":
                continue
            parent_idx = denormalize_parent_idx(c[5].item())
            layout["components"].append({
                "class": cls_name,
                "x_min": round(c[1].item(), 4),
                "y_min": round(c[2].item(), 4),
                "x_max": round(c[3].item(), 4),
                "y_max": round(c[4].item(), 4),
                "parent_panel": parent_idx,
            })

        results.append(layout)

    path = os.path.join(SAMPLES_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[JSON] {len(results)} layout kaydedildi: {path}")
    return results


# ==============================================================================
# Test
# ==============================================================================
if __name__ == "__main__":
    from model import create_baseline_model, create_hierarchical_model

    print("=" * 60)
    print("Örnekleme Testi (eğitimsiz — rastgele ağırlıklar)")
    print("=" * 60)

    scheduler = NoiseScheduler()

    baseline = create_baseline_model()
    bl_samples = sample_baseline(baseline, scheduler, num_samples=4, use_ddim=True)
    print(f"[Baseline] Samples shape: {bl_samples.shape}")
    baseline_samples_to_json(bl_samples[:2], "test_baseline.json")

    print("\n[BAŞARILI] Örnekleme testi tamamlandı!")
