"""
config.py — Merkezi Hiperparametre ve Konfigürasyon Dosyası

Hiyerarşik ve Kısıt-Kılavuzlu DDPM ile UI Bounding Box Üretimi projesi
için tüm ayarlar bu dosyada tanımlanmıştır.
"""

import torch
import os

# ==============================================================================
# Cihaz Ayarı (CUDA varsa GPU, yoksa CPU)
# ==============================================================================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ==============================================================================
# Veri Seti Ayarları
# ==============================================================================
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
RICO_JSON_DIR = os.path.join(DATA_DIR, "rico_jsons")
RICO_IMAGE_DIR = os.path.join(DATA_DIR, "rico_images")

# Bileşen sınıfları (RICO veri setinden filtrelenen temel UI elemanları)
COMPONENT_CLASSES = [
    "Panel",          # 0 — Ana taşıyıcı panel / container
    "Button",         # 1 — Buton
    "TextInput",      # 2 — Metin giriş alanı
    "Label",          # 3 — Etiket / yazı
    "Icon",           # 4 — İkon
    "CheckBox",       # 5 — Seçim kutusu
    "Dropdown",       # 6 — Açılır menü
    "Slider",         # 7 — Kaydırıcı
    "Toggle",         # 8 — Açma/kapama düğmesi
    "Image",          # 9 — Görsel alanı
]
NUM_CLASSES = len(COMPONENT_CLASSES)

# Her bir UI elemanının özellik boyutu: [class_id, x_min, y_min, x_max, y_max]
FEATURE_DIM = 5  # sınıf_id + 4 koordinat

# Hiyerarşik yapı için panel özellik boyutu
PANEL_FEATURE_DIM = 5  # [class_id, x_min, y_min, x_max, y_max]
# Alt bileşen özellik boyutu (panel_id ek olarak eklenir)
COMPONENT_FEATURE_DIM = 6  # [class_id, x_min, y_min, x_max, y_max, parent_panel_idx]

# Sabit boyutlu padding için maksimum sayılar
MAX_PANELS = 5          # Bir layout'taki maksimum ana panel sayısı
MAX_COMPONENTS = 20     # Bir layout'taki maksimum alt bileşen sayısı
MAX_ELEMENTS = 25       # Baseline model için toplam maksimum eleman (panel + bileşen)

# ==============================================================================
# Normalizasyon Yardımcıları
# ==============================================================================
# Padding ile gerçek elemanları ayırt etmek için class_id'ye +1 offset eklenir.
# Padding = 0.0, Panel(class 0) = 1/11 ≈ 0.09, ..., Image(class 9) = 10/11 ≈ 0.91
# Bu sayede [-1,1] normalizasyonundan sonra padding (-1.0) ile Panel (-0.82) ayırt edilebilir.

def normalize_class_id(cls_id):
    """Sınıf ID'sini [0, 1) aralığına normalize eder. Padding için 0.0 döner."""
    return (cls_id + 1) / (NUM_CLASSES + 1)

def denormalize_class_id(cls_norm):
    """Normalize edilmiş sınıf değerini gerçek sınıf index'ine çevirir. Padding için -1 döner."""
    cls_idx = int(round(cls_norm * (NUM_CLASSES + 1))) - 1
    return max(-1, min(cls_idx, NUM_CLASSES - 1))

def normalize_parent_idx(parent_idx):
    """Parent panel index'ini [0, 1) aralığına normalize eder. Yok (-1) için 0.0."""
    return (parent_idx + 1) / (MAX_PANELS + 1)

def denormalize_parent_idx(parent_norm):
    """Normalize edilmiş parent değerini gerçek panel index'ine çevirir."""
    return int(round(parent_norm * (MAX_PANELS + 1))) - 1


# ==============================================================================
# Difüzyon (DDPM) Hiperparametreleri
# ==============================================================================
T = 1000                # Toplam difüzyon adım sayısı
BETA_START = 1e-4       # Başlangıç beta değeri (linear schedule)
BETA_END = 0.02         # Bitiş beta değeri
NOISE_SCHEDULE = "cosine"  # "cosine" veya "linear" — cosine layout verisi için çok daha iyi

# ==============================================================================
# Model Mimarisi Ayarları (A100 GPU Optimizasyonu)
# ==============================================================================
HIDDEN_DIM = 512        # Gizli katman boyutu
NUM_LAYERS = 8          # Residual blok / transformer katman sayısı
TIME_EMB_DIM = 256      # Zaman adımı embedding boyutu
NHEAD = 8               # Dikkat mekanizması kafa sayısı (hiyerarşik model)
DROPOUT = 0.1           # Dropout oranı

# ==============================================================================
# Görüntü (Aşama 2) Difüzyon U-Net Ayarları
# ==============================================================================
IMAGE_SIZE = 64         # Üretilecek sentetik Mock-UI piksel çözünürlüğü (64x64)
IMAGE_CHANNELS = 3      # RGB

# Rendering için RGB renk kodları (0-255 aralığı) — render_layout_to_image kullanır
CLASS_COLORS_RGB = {
    0: (230, 230, 230),  # Panel — Açık Gri
    1: (33, 150, 243),   # Button — Mavi
    2: (255, 193, 7),    # TextInput — Sarı
    3: (60, 60, 60),     # Label — Koyu Gri
    4: (156, 39, 176),   # Icon — Mor
    5: (76, 175, 80),    # CheckBox — Yeşil
    6: (255, 87, 34),    # Dropdown — Turuncu
    7: (0, 188, 212),    # Slider — Camgöbeği
    8: (233, 30, 99),    # Toggle — Pembe
    9: (139, 195, 74),   # Image — Açık Yeşil
}

# Görselleştirme için RGBA renk kodları (0-1 aralığı) — matplotlib kullanır
CLASS_COLORS_VIZ = {
    0: (0.2, 0.4, 0.8, 0.3),    # Panel — mavi, yarı saydam
    1: (0.9, 0.3, 0.3, 0.7),    # Button — kırmızı
    2: (0.3, 0.8, 0.3, 0.7),    # TextInput — yeşil
    3: (0.9, 0.9, 0.2, 0.7),    # Label — sarı
    4: (0.6, 0.3, 0.9, 0.7),    # Icon — mor
    5: (0.3, 0.9, 0.9, 0.7),    # CheckBox — cyan
    6: (0.9, 0.6, 0.2, 0.7),    # Dropdown — turuncu
    7: (0.5, 0.5, 0.5, 0.7),    # Slider — gri
    8: (0.2, 0.7, 0.5, 0.7),    # Toggle — deniz yeşili
    9: (0.8, 0.4, 0.6, 0.7),    # Image — pembe
}

# ==============================================================================
# Eğitim Ayarları
# ==============================================================================
BATCH_SIZE = 64         # A100 GPU ile 64 batch sorunsuz çalışır
NUM_EPOCHS = 300        # Daha fazla epoch (cosine LR ile iyi çalışır)
LEARNING_RATE = 2e-4    # Cosine annealing ile biraz daha yüksek başlangıç
WEIGHT_DECAY = 1e-4     # Biraz daha güçlü regularization
GRAD_CLIP = 1.0         # Gradient clipping değeri
SAVE_EVERY = 25         # Her kaç epoch'ta bir checkpoint kaydet
EARLY_STOP_PATIENCE = 50  # Cosine LR ile daha sabırlı olunmalı

# LR Scheduler ayarları
LR_WARMUP_STEPS = 500   # İlk 500 adım LR lineer olarak artar
LR_MIN = 1e-6           # Minimum learning rate (cosine annealing sonu)

# EMA (Exponential Moving Average) — daha iyi sample kalitesi
EMA_DECAY = 0.9999      # EMA bozunma katsayısı

# ==============================================================================
# Örnekleme (Sampling) Ayarları
# ==============================================================================
NUM_SAMPLES = 1000      # Değerlendirme için üretilecek örnek sayısı
APPLY_CONSTRAINTS = True  # Kısıt-kılavuzlu denoising aktif/pasif
DDIM_STEPS = 100        # DDIM örnekleme adım sayısı (hızlı örnekleme için)
USE_DDIM = True         # DDIM kullan (True) veya DDPM (False)

# ==============================================================================
# Çıktı Dizinleri
# ==============================================================================
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")
CHECKPOINT_DIR = os.path.join(OUTPUT_DIR, "checkpoints")
FIGURES_DIR = os.path.join(OUTPUT_DIR, "figures")
SAMPLES_DIR = os.path.join(OUTPUT_DIR, "samples")

# Dizinleri oluştur
for d in [DATA_DIR, OUTPUT_DIR, CHECKPOINT_DIR, FIGURES_DIR, SAMPLES_DIR]:
    os.makedirs(d, exist_ok=True)

# ==============================================================================
# Sentetik (Mock) Veri Ayarları
# ==============================================================================
MOCK_DATASET_SIZE = 2000  # Sentetik veri seti boyutu
