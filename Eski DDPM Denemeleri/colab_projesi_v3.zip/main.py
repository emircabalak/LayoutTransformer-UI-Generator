"""
main.py — Ana Calistirma Scripti
Tam pipeline: veri yukleme -> egitim -> ornekleme -> metrik hesaplama -> gorsellestirme

Kullanim:
    python main.py --mode all --model both --epochs 300
    python main.py --mode train --model baseline --epochs 100
    python main.py --mode sample --model hierarchical --num-samples 50
    python main.py --mode evaluate --model both
    python main.py --mode all --model all --epochs 300   (layout + image diffusion)
"""
import argparse
import torch
import os
import sys

from config import DEVICE, NUM_EPOCHS, NUM_SAMPLES, CHECKPOINT_DIR
from data_preprocessing import get_dataloaders
from model import (
    NoiseScheduler,
    create_baseline_model, create_hierarchical_model, create_image_diffusion_model,
)
from train import train_baseline, train_hierarchical, train_image_diffusion
from sampling import (
    sample_baseline, sample_hierarchical, sample_image_diffusion,
    baseline_samples_to_json, hierarchical_samples_to_json, generated_images_to_png,
)
from metrics import (
    evaluate_baseline_batch, evaluate_hierarchical_batch,
    print_metrics, compare_metrics,
)
from visualization import (
    save_baseline_samples, save_hierarchical_samples,
    save_comparison, plot_metrics_comparison,
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Hiyerarsik ve Kisit-Kilavuzlu DDPM ile UI Bounding Box Uretimi"
    )
    parser.add_argument("--mode", type=str, default="all",
                        choices=["train", "sample", "evaluate", "all"],
                        help="Calistirma modu")
    parser.add_argument("--model", type=str, default="both",
                        choices=["baseline", "hierarchical", "image", "both", "all"],
                        help="Hangi model kullanilacak")
    parser.add_argument("--epochs", type=int, default=NUM_EPOCHS,
                        help="Egitim epoch sayisi")
    parser.add_argument("--num-samples", type=int, default=NUM_SAMPLES,
                        help="Uretilecek ornek sayisi")
    parser.add_argument("--use-mock-data", action="store_true",
                        help="Sentetik veri kullan")
    parser.add_argument("--resume", action="store_true",
                        help="Checkpoint'tan devam et")
    parser.add_argument("--batch-size", type=int, default=64,
                        help="Batch boyutu")
    parser.add_argument("--no-constraints", action="store_true",
                        help="Kisit-kilavuzlu denoising'i kapat")
    parser.add_argument("--no-ddim", action="store_true",
                        help="DDIM yerine DDPM kullan (daha yavas ama daha kaliteli)")
    return parser.parse_args()


def _load_ema_or_model(model, ckpt_path, label="Model"):
    """Checkpoint'tan EMA varsa onu, yoksa normal modeli yükler."""
    if os.path.exists(ckpt_path):
        ckpt = torch.load(ckpt_path, map_location=DEVICE, weights_only=False)
        if "ema_state_dict" in ckpt:
            model.load_state_dict(ckpt["ema_state_dict"])
            print(f"  [{label}] EMA checkpoint yuklendi: {ckpt_path}")
        else:
            model.load_state_dict(ckpt["model_state_dict"])
            print(f"  [{label}] Checkpoint yuklendi: {ckpt_path}")
        return True
    else:
        print(f"  [UYARI] {label} checkpoint bulunamadi: {ckpt_path}")
        return False


def main():
    args = parse_args()
    apply_constraints = not args.no_constraints
    use_ddim = not args.no_ddim

    print("=" * 70)
    print("  Hiyerarsik ve Kisit-Kilavuzlu DDPM")
    print("  UI Bounding Box Uretimi Projesi")
    print("=" * 70)
    print(f"  Cihaz:        {DEVICE}")
    print(f"  Mod:          {args.mode}")
    print(f"  Model:        {args.model}")
    print(f"  Epoch:        {args.epochs}")
    print(f"  Ornek sayisi: {args.num_samples}")
    print(f"  Mock veri:    {args.use_mock_data}")
    print(f"  Kisitlar:     {'Aktif' if apply_constraints else 'Pasif'}")
    print(f"  DDIM:         {'Aktif' if use_ddim else 'Pasif (DDPM)'}")
    print("=" * 70)

    scheduler = NoiseScheduler()

    # ==========================
    # VERI YUKLEME
    # ==========================
    if args.mode in ["train", "all"]:
        print("\n[1/4] Veri yukleniyor...")
        loaders = get_dataloaders(use_mock=args.use_mock_data, batch_size=args.batch_size)
    else:
        loaders = None

    # ==========================
    # EGITIM
    # ==========================
    baseline_model = None
    hier_model = None

    if args.mode in ["train", "all"]:
        print("\n[2/4] Egitim basliyor...")

        if args.model in ["baseline", "both"]:
            baseline_model, bl_train, bl_val = train_baseline(
                loaders["baseline_train"], loaders["baseline_val"],
                num_epochs=args.epochs, resume=args.resume
            )

        if args.model in ["hierarchical", "both", "all"]:
            hier_model, hier_losses = train_hierarchical(
                loaders["hierarchical_train"], loaders["hierarchical_val"],
                num_epochs=args.epochs, resume=args.resume
            )

        if args.model in ["image", "all"]:
            image_model, img_train_loss, img_val_loss = train_image_diffusion(
                loaders["image_train"], loaders["image_val"],
                num_epochs=args.epochs, resume=args.resume
            )

    # ==========================
    # ORNEKLEME
    # ==========================
    bl_samples = None
    hi_panels = None
    hi_components = None

    if args.mode in ["sample", "evaluate", "all"]:
        print("\n[3/4] Ornekleme basliyor...")

        # Model yoksa checkpoint'tan yukle
        if args.model in ["baseline", "both"] and baseline_model is None:
            baseline_model = create_baseline_model()
            ckpt_path = os.path.join(CHECKPOINT_DIR, "baseline_best.pt")
            _load_ema_or_model(baseline_model, ckpt_path, "Baseline")

        if args.model in ["hierarchical", "both", "all", "image"] and hier_model is None:
            hier_model = create_hierarchical_model()
            for name, sub in [("panel", hier_model.panel_generator),
                              ("comp", hier_model.component_generator)]:
                ckpt_path = os.path.join(CHECKPOINT_DIR, f"hier_{name}_best.pt")
                _load_ema_or_model(sub, ckpt_path, f"Hier/{name}")

        # Ornekle
        if args.model in ["baseline", "both", "all"] and baseline_model is not None:
            bl_samples = sample_baseline(
                baseline_model, scheduler,
                num_samples=args.num_samples,
                apply_constraints=apply_constraints,
                use_ddim=use_ddim,
            )
            baseline_samples_to_json(bl_samples)

        if args.model in ["hierarchical", "both", "all", "image"] and hier_model is not None:
            hi_panels, hi_components = sample_hierarchical(
                hier_model, scheduler,
                num_samples=args.num_samples,
                apply_constraints=apply_constraints,
                use_ddim=use_ddim,
            )
            hierarchical_samples_to_json(hi_panels, hi_components)

        if args.model in ["image", "all"]:
            image_model = create_image_diffusion_model()
            ckpt_path = os.path.join(CHECKPOINT_DIR, "image_diffusion_best.pt")
            _load_ema_or_model(image_model, ckpt_path, "Image Diff")

            if hi_panels is not None and hi_components is not None:
                images = sample_image_diffusion(
                    image_model, scheduler, hi_panels, hi_components,
                    num_samples=args.num_samples, use_ddim=use_ddim,
                )
                generated_images_to_png(images)

    # ==========================
    # DEGERLENDIRME
    # ==========================
    if args.mode in ["evaluate", "all"] and (bl_samples is not None or hi_panels is not None):
        print("\n[4/4] Degerlendirme...")

        bl_metrics = None
        hi_metrics = None

        if bl_samples is not None:
            bl_metrics = evaluate_baseline_batch(bl_samples)
            print_metrics(bl_metrics, "Baseline DDPM")
            save_baseline_samples(bl_samples, num_show=6)

        if hi_panels is not None:
            hi_metrics = evaluate_hierarchical_batch(hi_panels, hi_components)
            print_metrics(hi_metrics, "Hiyerarsik + Kisit-Kilavuzlu DDPM")
            save_hierarchical_samples(hi_panels, hi_components, num_show=6)

        if bl_metrics and hi_metrics:
            compare_metrics(bl_metrics, hi_metrics)
            save_comparison(bl_samples, hi_panels, hi_components, num_show=3)
            plot_metrics_comparison(bl_metrics, hi_metrics)

    print("\n" + "=" * 70)
    print("  TAMAMLANDI!")
    print("=" * 70)


if __name__ == "__main__":
    main()
