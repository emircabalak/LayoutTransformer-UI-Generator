"""
model.py — DDPM Model Mimarisi

İki model sağlar:
1. BaselineDDPM: Tek aşamalı standart DDPM (tüm UI elemanlarını birden üretir)
2. HierarchicalDDPM: İki aşamalı hiyerarşik DDPM
   - Aşama 1: PanelGenerator — Ana panellerin bounding box'larını üretir
   - Aşama 2: ComponentGenerator — Panel bilgisiyle koşullanarak alt bileşenleri üretir
3. ConditionalUNet: Layout koşullu görsel difüzyon modeli
"""

import math
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import (
    T, BETA_START, BETA_END, NOISE_SCHEDULE,
    HIDDEN_DIM, NUM_LAYERS, TIME_EMB_DIM, NHEAD, DROPOUT, DEVICE,
    MAX_ELEMENTS, MAX_PANELS, MAX_COMPONENTS,
    FEATURE_DIM, PANEL_FEATURE_DIM, COMPONENT_FEATURE_DIM,
    NUM_CLASSES, IMAGE_CHANNELS, EMA_DECAY,
)


# ==============================================================================
# Gürültü Zamanlayıcı (Noise Scheduler)
# ==============================================================================

class NoiseScheduler:
    """
    DDPM gürültü zamanlayıcısı. Cosine veya linear beta schedule destekler.
    Cosine schedule, layout gibi yapısal veriler için çok daha iyi çalışır.
    """

    def __init__(self, T=T, beta_start=BETA_START, beta_end=BETA_END,
                 schedule=NOISE_SCHEDULE, device=DEVICE):
        self.T = T
        self.device = device

        if schedule == "cosine":
            self.betas = self._cosine_beta_schedule(T).to(device)
        else:
            self.betas = torch.linspace(beta_start, beta_end, T, device=device)

        self.alphas = 1.0 - self.betas
        self.alpha_bars = torch.cumprod(self.alphas, dim=0)
        self.alpha_bars_prev = F.pad(self.alpha_bars[:-1], (1, 0), value=1.0)

        self.sqrt_alpha_bars = torch.sqrt(self.alpha_bars)
        self.sqrt_one_minus_alpha_bars = torch.sqrt(1.0 - self.alpha_bars)
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.posterior_variance = (
            self.betas * (1.0 - self.alpha_bars_prev) / (1.0 - self.alpha_bars)
        )

    @staticmethod
    def _cosine_beta_schedule(T, s=0.008):
        """
        Cosine schedule (Nichol & Dhariwal, 2021).
        Veriyi yavaşça bozar, yapısal bilgiyi daha uzun süre korur.
        """
        steps = T + 1
        x = torch.linspace(0, T, steps)
        alphas_cumprod = torch.cos(((x / T) + s) / (1 + s) * math.pi * 0.5) ** 2
        alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
        betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
        return torch.clamp(betas, 0.0001, 0.999)

    def q_sample(self, x_0, t, noise=None):
        """İleri difüzyon: x_0'dan x_t üretir."""
        if noise is None:
            noise = torch.randn_like(x_0)

        sqrt_alpha_bar = self.sqrt_alpha_bars[t]
        sqrt_one_minus_alpha_bar = self.sqrt_one_minus_alpha_bars[t]

        while len(sqrt_alpha_bar.shape) < len(x_0.shape):
            sqrt_alpha_bar = sqrt_alpha_bar.unsqueeze(-1)
            sqrt_one_minus_alpha_bar = sqrt_one_minus_alpha_bar.unsqueeze(-1)

        x_t = sqrt_alpha_bar * x_0 + sqrt_one_minus_alpha_bar * noise
        return x_t, noise

    def p_sample_step(self, model, x_t, t, class_labels=None):
        """Ters difüzyon adımı: x_t'den x_{t-1} üretir."""
        t_tensor = torch.full((x_t.shape[0],), t, device=self.device, dtype=torch.long)

        if class_labels is not None:
            predicted_noise = model(x_t, t_tensor, class_labels)
        else:
            predicted_noise = model(x_t, t_tensor)

        beta_t = self.betas[t]
        alpha_t = self.alphas[t]
        alpha_bar_t = self.alpha_bars[t]
        sqrt_recip_alpha_t = self.sqrt_recip_alphas[t]

        coeff = beta_t / self.sqrt_one_minus_alpha_bars[t]
        mean = sqrt_recip_alpha_t * (x_t - coeff * predicted_noise)

        if t > 0:
            noise = torch.randn_like(x_t)
            sigma = torch.sqrt(self.posterior_variance[t])
            x_prev = mean + sigma * noise
        else:
            x_prev = mean

        return x_prev


# ==============================================================================
# EMA (Exponential Moving Average)
# ==============================================================================

class EMA:
    """
    Model ağırlıklarının üstel hareketli ortalamasını tutar.
    Sample kalitesini önemli ölçüde artırır.
    """

    def __init__(self, model, decay=EMA_DECAY):
        self.decay = decay
        self.shadow = copy.deepcopy(model)
        self.shadow.eval()
        for p in self.shadow.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        for s_param, m_param in zip(self.shadow.parameters(), model.parameters()):
            s_param.data.mul_(self.decay).add_(m_param.data, alpha=1.0 - self.decay)

    def get_model(self):
        return self.shadow


# ==============================================================================
# Yardımcı Katmanlar
# ==============================================================================

class SinusoidalPositionEmbedding(nn.Module):
    """Sinüzoidal zaman adımı embedding'i."""

    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, t):
        device = t.device
        half_dim = self.dim // 2
        emb = math.log(10000) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=device) * -emb)
        emb = t.float().unsqueeze(1) * emb.unsqueeze(0)
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=-1)
        return emb


class ResidualBlock(nn.Module):
    """Residual MLP bloğu + zaman koşullaması."""

    def __init__(self, hidden_dim, time_emb_dim, dropout=DROPOUT):
        super().__init__()
        self.layers = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Dropout(dropout),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Dropout(dropout),
        )
        self.time_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(time_emb_dim, hidden_dim),
        )

    def forward(self, x, t_emb):
        h = self.layers(x) + self.time_mlp(t_emb)
        return x + h


class SequenceResidualBlock(nn.Module):
    """AdaLN ile sekans üzerinde çalışan FeedForward bloğu."""

    def __init__(self, hidden_dim, time_emb_dim, dropout=DROPOUT):
        super().__init__()
        self.norm = nn.LayerNorm(hidden_dim)
        self.fc1 = nn.Linear(hidden_dim, hidden_dim * 4)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_dim * 4, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.time_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(time_emb_dim, hidden_dim * 2),
        )

    def forward(self, x, t_emb):
        residual = x
        h = self.norm(x)

        t = self.time_mlp(t_emb).unsqueeze(1)
        scale, shift = t.chunk(2, dim=-1)
        h = h * (1.0 + scale) + shift

        h = self.fc1(h)
        h = self.act(h)
        h = self.dropout(h)
        h = self.fc2(h)
        h = self.dropout(h)

        return residual + h


# ==============================================================================
# Baseline DDPM Modeli
# ==============================================================================

class BaselineDDPM(nn.Module):
    """
    Standart tek aşamalı DDPM.
    Input:  [batch, MAX_ELEMENTS, FEATURE_DIM]
    Output: [batch, MAX_ELEMENTS, FEATURE_DIM]
    """

    def __init__(
        self,
        max_elements=MAX_ELEMENTS,
        feature_dim=FEATURE_DIM,
        hidden_dim=HIDDEN_DIM,
        time_emb_dim=TIME_EMB_DIM,
        num_layers=NUM_LAYERS,
        dropout=DROPOUT,
    ):
        super().__init__()
        self.max_elements = max_elements
        self.feature_dim = feature_dim
        self.flat_dim = max_elements * feature_dim

        self.time_embedding = nn.Sequential(
            SinusoidalPositionEmbedding(time_emb_dim),
            nn.Linear(time_emb_dim, time_emb_dim),
            nn.SiLU(),
            nn.Linear(time_emb_dim, time_emb_dim),
        )

        self.input_proj = nn.Linear(self.flat_dim, hidden_dim)

        self.blocks = nn.ModuleList([
            ResidualBlock(hidden_dim, time_emb_dim, dropout)
            for _ in range(num_layers)
        ])

        self.output_proj = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, self.flat_dim),
        )

    def forward(self, x, t):
        batch_size = x.shape[0]
        x_flat = x.view(batch_size, -1)
        t_emb = self.time_embedding(t)
        h = self.input_proj(x_flat)
        for block in self.blocks:
            h = block(h, t_emb)
        out = self.output_proj(h)
        out = out.view(batch_size, self.max_elements, self.feature_dim)
        return out


# ==============================================================================
# Hiyerarşik DDPM — Panel Generator (Aşama 1)
# ==============================================================================

class PanelGenerator(nn.Module):
    """
    Hiyerarşik DDPM'in 1. aşaması: Ana panellerin koordinatlarını üretir.
    Input:  [batch, MAX_PANELS, PANEL_FEATURE_DIM]
    Output: [batch, MAX_PANELS, PANEL_FEATURE_DIM]
    """

    def __init__(
        self,
        max_panels=MAX_PANELS,
        feature_dim=PANEL_FEATURE_DIM,
        hidden_dim=HIDDEN_DIM,
        time_emb_dim=TIME_EMB_DIM,
        num_layers=NUM_LAYERS,
        nhead=NHEAD,
        dropout=DROPOUT,
    ):
        super().__init__()
        self.max_panels = max_panels
        self.feature_dim = feature_dim

        self.time_embedding = nn.Sequential(
            SinusoidalPositionEmbedding(time_emb_dim),
            nn.Linear(time_emb_dim, time_emb_dim),
            nn.SiLU(),
            nn.Linear(time_emb_dim, time_emb_dim),
        )

        self.element_proj = nn.Linear(feature_dim, hidden_dim)
        self.pos_embedding = nn.Embedding(max_panels, hidden_dim)

        self.blocks = nn.ModuleList()
        for _ in range(num_layers):
            self.blocks.append(nn.ModuleDict({
                "attn": nn.MultiheadAttention(
                    hidden_dim, nhead, dropout=dropout, batch_first=True
                ),
                "norm_attn": nn.LayerNorm(hidden_dim),
                "res": SequenceResidualBlock(hidden_dim, time_emb_dim, dropout),
            }))

        self.output_proj = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, feature_dim),
        )

    def forward(self, x, t):
        batch_size = x.shape[0]
        t_emb = self.time_embedding(t)

        h = self.element_proj(x)
        pos = self.pos_embedding(torch.arange(self.max_panels, device=x.device))
        h = h + pos.unsqueeze(0)

        for block in self.blocks:
            attn_out, _ = block["attn"](h, h, h)
            h = block["norm_attn"](h + attn_out)
            h = block["res"](h, t_emb)

        out = self.output_proj(h)
        return out


# ==============================================================================
# Hiyerarşik DDPM — Component Generator (Aşama 2)
# ==============================================================================

class ComponentGenerator(nn.Module):
    """
    Hiyerarşik DDPM'in 2. aşaması: Panel bilgisiyle koşullanarak
    alt bileşenlerin koordinatlarını üretir.
    """

    def __init__(
        self,
        max_components=MAX_COMPONENTS,
        max_panels=MAX_PANELS,
        comp_feature_dim=COMPONENT_FEATURE_DIM,
        panel_feature_dim=PANEL_FEATURE_DIM,
        hidden_dim=HIDDEN_DIM,
        time_emb_dim=TIME_EMB_DIM,
        num_layers=NUM_LAYERS,
        nhead=NHEAD,
        dropout=DROPOUT,
    ):
        super().__init__()
        self.max_components = max_components
        self.comp_feature_dim = comp_feature_dim

        self.time_embedding = nn.Sequential(
            SinusoidalPositionEmbedding(time_emb_dim),
            nn.Linear(time_emb_dim, time_emb_dim),
            nn.SiLU(),
            nn.Linear(time_emb_dim, time_emb_dim),
        )

        self.comp_proj = nn.Linear(comp_feature_dim, hidden_dim)
        self.comp_pos_embedding = nn.Embedding(max_components, hidden_dim)

        self.panel_proj = nn.Linear(panel_feature_dim, hidden_dim)
        self.panel_pos_embedding = nn.Embedding(max_panels, hidden_dim)

        self.blocks = nn.ModuleList()
        for _ in range(num_layers):
            self.blocks.append(nn.ModuleDict({
                "self_attn": nn.MultiheadAttention(
                    hidden_dim, nhead, dropout=dropout, batch_first=True
                ),
                "norm_self": nn.LayerNorm(hidden_dim),
                "cross_attn": nn.MultiheadAttention(
                    hidden_dim, nhead, dropout=dropout, batch_first=True
                ),
                "norm_cross": nn.LayerNorm(hidden_dim),
                "res": SequenceResidualBlock(hidden_dim, time_emb_dim, dropout),
            }))

        self.output_proj = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, comp_feature_dim),
        )

    def forward(self, x, t, panels):
        t_emb = self.time_embedding(t)

        h = self.comp_proj(x)
        comp_pos = self.comp_pos_embedding(
            torch.arange(self.max_components, device=x.device)
        )
        h = h + comp_pos.unsqueeze(0)

        panel_h = self.panel_proj(panels)
        panel_pos = self.panel_pos_embedding(
            torch.arange(panels.shape[1], device=x.device)
        )
        panel_h = panel_h + panel_pos.unsqueeze(0)

        for block in self.blocks:
            sa_out, _ = block["self_attn"](h, h, h)
            h = block["norm_self"](h + sa_out)

            ca_out, _ = block["cross_attn"](h, panel_h, panel_h)
            h = block["norm_cross"](h + ca_out)

            h = block["res"](h, t_emb)

        out = self.output_proj(h)
        return out


# ==============================================================================
# Hiyerarşik DDPM — Birleşik Model
# ==============================================================================

class HierarchicalDDPM(nn.Module):
    """İki aşamalı hiyerarşik DDPM."""

    def __init__(self):
        super().__init__()
        self.panel_generator = PanelGenerator()
        self.component_generator = ComponentGenerator()

    def forward_panel(self, x_panels, t):
        return self.panel_generator(x_panels, t)

    def forward_component(self, x_components, t, panels):
        return self.component_generator(x_components, t, panels)


# ==============================================================================
# Görsel Üretimi U-Net (Aşama 2)
# ==============================================================================

class SelfAttention2d(nn.Module):
    """Mekansal Dikkat katmanı."""

    def __init__(self, channels):
        super().__init__()
        self.norm = nn.GroupNorm(8, channels)
        self.q = nn.Conv2d(channels, channels, 1)
        self.k = nn.Conv2d(channels, channels, 1)
        self.v = nn.Conv2d(channels, channels, 1)
        self.proj = nn.Conv2d(channels, channels, 1)

    def forward(self, x):
        h = self.norm(x)
        b, c, height, w = h.shape
        q = self.q(h).view(b, c, -1)
        k = self.k(h).view(b, c, -1)
        v = self.v(h).view(b, c, -1)

        attn = torch.bmm(q.transpose(1, 2), k) * (c ** -0.5)
        attn = F.softmax(attn, dim=-1)

        out = torch.bmm(v, attn.transpose(1, 2))
        out = out.view(b, c, height, w)
        return x + self.proj(out)


class ResNetUNetBlock(nn.Module):
    """AdaLN içeren ResNet Bloğu."""

    def __init__(self, in_ch, out_ch, time_emb_dim, dropout=0.1):
        super().__init__()
        self.in_layers = nn.Sequential(
            nn.GroupNorm(8, in_ch),
            nn.SiLU(),
            nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1),
        )
        self.out_layers = nn.Sequential(
            nn.GroupNorm(8, out_ch),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Conv2d(out_ch, out_ch, kernel_size=3, padding=1),
        )
        self.emb_layers = nn.Sequential(
            nn.SiLU(),
            nn.Linear(time_emb_dim, out_ch * 2),
        )
        self.skip_connection = (
            nn.Conv2d(in_ch, out_ch, kernel_size=1) if in_ch != out_ch else nn.Identity()
        )

    def forward(self, x, t_emb):
        h = self.in_layers(x)
        t = self.emb_layers(t_emb).unsqueeze(-1).unsqueeze(-1)
        scale, shift = t.chunk(2, dim=1)
        h = h * (1.0 + scale) + shift
        h = self.out_layers(h)
        return self.skip_connection(x) + h


class ConditionalUNet(nn.Module):
    """
    Layout koşullu görsel difüzyon U-Net'i.
    Gürültülü piksel hedefini (x_t) ve Layout Maskesini (condition) alır.
    """

    def __init__(
        self,
        in_channels=IMAGE_CHANNELS,
        cond_channels=NUM_CLASSES,
        out_channels=IMAGE_CHANNELS,
        base_channels=128,
        time_emb_dim=512,
    ):
        super().__init__()

        self.time_embedding = nn.Sequential(
            SinusoidalPositionEmbedding(time_emb_dim),
            nn.Linear(time_emb_dim, time_emb_dim * 2),
            nn.SiLU(),
            nn.Linear(time_emb_dim * 2, time_emb_dim),
        )

        total_in_channels = in_channels + cond_channels
        self.init_conv = nn.Conv2d(total_in_channels, base_channels, kernel_size=3, padding=1)

        # DOWNSAMPLE
        self.down1 = ResNetUNetBlock(base_channels, base_channels, time_emb_dim)
        self.down2_pool = nn.MaxPool2d(2)
        self.down2_res = ResNetUNetBlock(base_channels, base_channels * 2, time_emb_dim)
        self.attn2 = SelfAttention2d(base_channels * 2)

        self.down3_pool = nn.MaxPool2d(2)
        self.down3_res = ResNetUNetBlock(base_channels * 2, base_channels * 4, time_emb_dim)
        self.attn3 = SelfAttention2d(base_channels * 4)

        # BOTTLENECK
        self.bot1 = ResNetUNetBlock(base_channels * 4, base_channels * 4, time_emb_dim)
        self.bot_attn = SelfAttention2d(base_channels * 4)
        self.bot2 = ResNetUNetBlock(base_channels * 4, base_channels * 4, time_emb_dim)

        # UPSAMPLE
        self.up3_conv = nn.ConvTranspose2d(
            base_channels * 4, base_channels * 2, kernel_size=2, stride=2
        )
        self.up3_res = ResNetUNetBlock(base_channels * 4, base_channels * 2, time_emb_dim)
        self.up_attn3 = SelfAttention2d(base_channels * 2)

        self.up2_conv = nn.ConvTranspose2d(
            base_channels * 2, base_channels, kernel_size=2, stride=2
        )
        self.up2_res = ResNetUNetBlock(base_channels * 2, base_channels, time_emb_dim)

        # ÇIKIŞ
        self.out = nn.Sequential(
            nn.GroupNorm(8, base_channels),
            nn.SiLU(),
            nn.Conv2d(base_channels, out_channels, kernel_size=3, padding=1),
        )

    def forward(self, x, t, condition):
        t_emb = self.time_embedding(t)
        h_in = torch.cat([x, condition], dim=1)
        h0 = self.init_conv(h_in)

        d1 = self.down1(h0, t_emb)
        d2 = self.down2_res(self.down2_pool(d1), t_emb)
        d2 = self.attn2(d2)
        d3 = self.down3_res(self.down3_pool(d2), t_emb)
        d3 = self.attn3(d3)

        b = self.bot1(d3, t_emb)
        b = self.bot_attn(b)
        b = self.bot2(b, t_emb)

        u3 = self.up3_conv(b)
        u3 = torch.cat([u3, d2], dim=1)
        u3 = self.up3_res(u3, t_emb)
        u3 = self.up_attn3(u3)

        u2 = self.up2_conv(u3)
        u2 = torch.cat([u2, d1], dim=1)
        u2 = self.up2_res(u2, t_emb)

        return self.out(u2)


# ==============================================================================
# Model Oluşturucu
# ==============================================================================

def create_baseline_model():
    model = BaselineDDPM().to(DEVICE)
    num_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"[Baseline DDPM] Toplam eğitilebilir parametre: {num_params:,}")
    return model


def create_hierarchical_model():
    model = HierarchicalDDPM().to(DEVICE)
    panel_params = sum(
        p.numel() for p in model.panel_generator.parameters() if p.requires_grad
    )
    comp_params = sum(
        p.numel() for p in model.component_generator.parameters() if p.requires_grad
    )
    total = panel_params + comp_params
    print(f"[Hierarchical DDPM] Panel Generator: {panel_params:,} parametre")
    print(f"[Hierarchical DDPM] Component Generator: {comp_params:,} parametre")
    print(f"[Hierarchical DDPM] Toplam: {total:,} parametre")
    return model


def create_image_diffusion_model():
    model = ConditionalUNet().to(DEVICE)
    num_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"[Image Diffusion U-Net] Toplam eğitilebilir parametre: {num_params:,}")
    return model


# ==============================================================================
# Test
# ==============================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("Model Mimarisi Testi")
    print("=" * 60)
    print(f"Cihaz: {DEVICE}")

    scheduler = NoiseScheduler()
    x_0 = torch.randn(4, MAX_ELEMENTS, FEATURE_DIM, device=DEVICE)
    t = torch.randint(0, T, (4,), device=DEVICE)
    x_t, noise = scheduler.q_sample(x_0, t)
    print(f"\n[NoiseScheduler] x_0 shape: {x_0.shape}, x_t shape: {x_t.shape}")

    baseline = create_baseline_model()
    noise_pred = baseline(x_t, t)
    print(f"[Baseline] Input shape: {x_t.shape}, Output shape: {noise_pred.shape}")

    hier_model = create_hierarchical_model()

    panels_noisy = torch.randn(4, MAX_PANELS, PANEL_FEATURE_DIM, device=DEVICE)
    t_p = torch.randint(0, T, (4,), device=DEVICE)
    panel_noise_pred = hier_model.forward_panel(panels_noisy, t_p)
    print(f"[Panel Gen.] Input: {panels_noisy.shape}, Output: {panel_noise_pred.shape}")

    comps_noisy = torch.randn(4, MAX_COMPONENTS, COMPONENT_FEATURE_DIM, device=DEVICE)
    panels_clean = torch.randn(4, MAX_PANELS, PANEL_FEATURE_DIM, device=DEVICE)
    t_c = torch.randint(0, T, (4,), device=DEVICE)
    comp_noise_pred = hier_model.forward_component(comps_noisy, t_c, panels_clean)
    print(f"[Comp. Gen.] Input: {comps_noisy.shape}, Output: {comp_noise_pred.shape}")

    # EMA testi
    ema = EMA(baseline)
    ema.update(baseline)
    print(f"[EMA] Shadow model oluşturuldu ve güncellendi.")

    print("\n[BAŞARILI] Model mimarisi testi tamamlandı!")
