"""
visualization.py — Gorsellestirme Modulu
Uretilen bounding box'lari cizer, baseline vs hiyerarsik model karsilastirir.
"""
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

from config import (
    NUM_CLASSES, COMPONENT_CLASSES, CLASS_COLORS_VIZ, FIGURES_DIR,
    MAX_PANELS, denormalize_class_id,
)


def _get_class_info(cls_norm, num_classes=NUM_CLASSES):
    idx = denormalize_class_id(cls_norm)
    if idx < 0 or idx >= num_classes:
        return "Padding", (0.3, 0.3, 0.3, 0.1)
    return COMPONENT_CLASSES[idx], CLASS_COLORS_VIZ.get(idx, (0.5, 0.5, 0.5, 0.5))


def draw_layout_baseline(ax, sample, title="Layout"):
    """Baseline model ciktisini cizer. sample: [MAX_ELEMENTS, FEATURE_DIM]"""
    ax.set_xlim(0, 1); ax.set_ylim(1, 0)
    ax.set_aspect('equal')
    ax.set_facecolor('#1a1a2e')
    ax.set_title(title, fontsize=10, fontweight='bold', color='white', pad=8)
    ax.tick_params(colors='gray', labelsize=7)

    for j in range(sample.shape[0]):
        e = sample[j]
        if e[1:5].sum().item() < 0.01:
            continue
        cls_name, color = _get_class_info(e[0].item())
        if cls_name == "Padding":
            continue
        x1, y1, x2, y2 = e[1].item(), e[2].item(), e[3].item(), e[4].item()
        w, h = x2 - x1, y2 - y1
        if w <= 0 or h <= 0:
            continue
        rect = patches.FancyBboxPatch(
            (x1, y1), w, h, boxstyle="round,pad=0.005",
            linewidth=1.5, edgecolor=color[:3], facecolor=(*color[:3], 0.3)
        )
        ax.add_patch(rect)
        ax.text(x1 + w/2, y1 + h/2, cls_name, ha='center', va='center',
                fontsize=5, color='white', fontweight='bold',
                bbox=dict(boxstyle='round,pad=0.1', facecolor=color[:3], alpha=0.7))


def draw_layout_hierarchical(ax, panels, components, title="Layout"):
    """Hiyerarsik model ciktisini cizer."""
    ax.set_xlim(0, 1); ax.set_ylim(1, 0)
    ax.set_aspect('equal')
    ax.set_facecolor('#1a1a2e')
    ax.set_title(title, fontsize=10, fontweight='bold', color='white', pad=8)
    ax.tick_params(colors='gray', labelsize=7)

    for j in range(panels.shape[0]):
        p = panels[j]
        if p[1:5].sum().item() < 0.01:
            continue
        cls_name, _ = _get_class_info(p[0].item())
        if cls_name == "Padding":
            continue
        x1, y1, x2, y2 = p[1].item(), p[2].item(), p[3].item(), p[4].item()
        w, h = x2 - x1, y2 - y1
        if w <= 0 or h <= 0:
            continue
        rect = patches.FancyBboxPatch(
            (x1, y1), w, h, boxstyle="round,pad=0.008",
            linewidth=2.5, edgecolor=(0.2, 0.5, 1.0), facecolor=(0.2, 0.4, 0.8, 0.15)
        )
        ax.add_patch(rect)
        ax.text(x1 + 0.01, y1 + 0.02, f"Panel {j}", fontsize=6,
                color=(0.5, 0.8, 1.0), fontweight='bold')

    for j in range(components.shape[0]):
        c = components[j]
        if c[1:5].sum().item() < 0.01:
            continue
        cls_name, color = _get_class_info(c[0].item())
        if cls_name == "Padding":
            continue
        x1, y1, x2, y2 = c[1].item(), c[2].item(), c[3].item(), c[4].item()
        w, h = x2 - x1, y2 - y1
        if w <= 0 or h <= 0:
            continue
        rect = patches.FancyBboxPatch(
            (x1, y1), w, h, boxstyle="round,pad=0.003",
            linewidth=1.2, edgecolor=color[:3], facecolor=(*color[:3], 0.4)
        )
        ax.add_patch(rect)
        ax.text(x1 + w/2, y1 + h/2, cls_name, ha='center', va='center',
                fontsize=5, color='white', fontweight='bold',
                bbox=dict(boxstyle='round,pad=0.1', facecolor=color[:3], alpha=0.7))


def save_baseline_samples(samples, num_show=6, filename="baseline_samples.png"):
    num_show = min(num_show, samples.shape[0])
    cols = min(3, num_show)
    rows = (num_show + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(5*cols, 5*rows), facecolor='#0d1117')
    if rows == 1 and cols == 1:
        axes = np.array([axes])
    axes = axes.flatten()
    for i in range(num_show):
        draw_layout_baseline(axes[i], samples[i], f"Baseline #{i+1}")
    for i in range(num_show, len(axes)):
        axes[i].set_visible(False)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, filename)
    plt.savefig(path, dpi=150, facecolor='#0d1117')
    plt.close()
    print(f"[Gorsel] Kaydedildi: {path}")


def save_hierarchical_samples(panels, components, num_show=6, filename="hierarchical_samples.png"):
    num_show = min(num_show, panels.shape[0])
    cols = min(3, num_show)
    rows = (num_show + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(5*cols, 5*rows), facecolor='#0d1117')
    if rows == 1 and cols == 1:
        axes = np.array([axes])
    axes = axes.flatten()
    for i in range(num_show):
        draw_layout_hierarchical(axes[i], panels[i], components[i], f"Hiyerarsik #{i+1}")
    for i in range(num_show, len(axes)):
        axes[i].set_visible(False)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, filename)
    plt.savefig(path, dpi=150, facecolor='#0d1117')
    plt.close()
    print(f"[Gorsel] Kaydedildi: {path}")


def save_comparison(bl_samples, hi_panels, hi_components, num_show=3, filename="comparison.png"):
    num_show = min(num_show, bl_samples.shape[0], hi_panels.shape[0])
    fig, axes = plt.subplots(num_show, 2, figsize=(10, 5*num_show), facecolor='#0d1117')
    if num_show == 1:
        axes = axes.reshape(1, -1)
    for i in range(num_show):
        draw_layout_baseline(axes[i, 0], bl_samples[i], f"Baseline #{i+1}")
        draw_layout_hierarchical(axes[i, 1], hi_panels[i], hi_components[i], f"Hiyerarsik #{i+1}")
    plt.suptitle("Baseline vs Hiyerarsik + Kisit-Kilavuzlu DDPM",
                 fontsize=16, fontweight='bold', color='white', y=1.01)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, filename)
    plt.savefig(path, dpi=150, facecolor='#0d1117', bbox_inches='tight')
    plt.close()
    print(f"[Gorsel] Kaydedildi: {path}")


def plot_metrics_comparison(bl_metrics, hi_metrics, filename="metrics_comparison.png"):
    metrics = ['Overlap\nRate', 'Overlap\nAlan Orani', 'Alignment\nScore']
    bl_vals = [bl_metrics['avg_overlap_rate'], bl_metrics['avg_overlap_area_ratio'], bl_metrics['avg_alignment_score']]
    hi_vals = [hi_metrics['avg_overlap_rate'], hi_metrics['avg_overlap_area_ratio'], hi_metrics['avg_alignment_score']]

    if 'avg_constraint_violation' in hi_metrics:
        metrics.append('Kisit\nIhlal Orani')
        bl_vals.append(0)
        hi_vals.append(hi_metrics['avg_constraint_violation'])

    x = np.arange(len(metrics))
    width = 0.35

    fig, ax = plt.subplots(figsize=(10, 6), facecolor='#0d1117')
    ax.set_facecolor('#1a1a2e')
    bars1 = ax.bar(x - width/2, bl_vals, width, label='Baseline', color='#ff6b6b', alpha=0.85, edgecolor='white', linewidth=0.5)
    bars2 = ax.bar(x + width/2, hi_vals, width, label='Hiyerarsik + Kisit', color='#4ecdc4', alpha=0.85, edgecolor='white', linewidth=0.5)

    ax.set_ylabel('Deger', fontsize=12, color='white')
    ax.set_title('Model Karsilastirmasi — Degerlendirme Metrikleri', fontsize=14, fontweight='bold', color='white')
    ax.set_xticks(x); ax.set_xticklabels(metrics, fontsize=10, color='white')
    ax.legend(fontsize=11, facecolor='#2a2a4a', edgecolor='gray', labelcolor='white')
    ax.tick_params(colors='gray')
    ax.grid(axis='y', alpha=0.2)

    for bar in bars1 + bars2:
        h = bar.get_height()
        ax.annotate(f'{h:.3f}', xy=(bar.get_x()+bar.get_width()/2, h),
                    xytext=(0,3), textcoords="offset points", ha='center', va='bottom',
                    fontsize=8, color='white')

    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, filename)
    plt.savefig(path, dpi=150, facecolor='#0d1117')
    plt.close()
    print(f"[Gorsel] Kaydedildi: {path}")


if __name__ == "__main__":
    import torch
    print("Gorsellestirme testi")
    dummy = torch.rand(3, 25, 5)
    dummy[:, 10:, :] = 0
    save_baseline_samples(dummy, num_show=3, filename="test_vis.png")
    print("[BASARILI] Gorsellestirme testi tamamlandi!")
