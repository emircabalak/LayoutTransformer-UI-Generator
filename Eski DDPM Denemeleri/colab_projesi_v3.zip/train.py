"""
train.py — Eğitim Döngüsü

Baseline ve Hiyerarşik DDPM modellerinin eğitim süreçlerini yönetir.
- Masked MSE loss (padding elemanlarını yok sayar)
- Cosine annealing LR scheduler + warmup
- EMA (Exponential Moving Average)
- Gradient clipping, early stopping, checkpoint kaydetme
"""

import os
import time
import math
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from config import (
    T, DEVICE, NUM_EPOCHS, LEARNING_RATE, WEIGHT_DECAY,
    GRAD_CLIP, SAVE_EVERY, EARLY_STOP_PATIENCE,
    CHECKPOINT_DIR, FIGURES_DIR,
    LR_WARMUP_STEPS, LR_MIN, EMA_DECAY,
)
from model import NoiseScheduler, EMA, create_baseline_model, create_hierarchical_model


# ==============================================================================
# Eğitim Yardımcı Fonksiyonları
# ==============================================================================

class EarlyStopping:
    """Early stopping mekanizması."""

    def __init__(self, patience=EARLY_STOP_PATIENCE, min_delta=1e-5):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.should_stop = False

    def step(self, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True
                print(
                    f"[Early Stopping] {self.patience} epoch boyunca "
                    f"iyileşme olmadı. Eğitim durduruluyor."
                )


def get_cosine_schedule_with_warmup(optimizer, warmup_steps, total_steps, lr_min=LR_MIN):
    """Cosine annealing LR scheduler with linear warmup."""

    def lr_lambda(current_step):
        if current_step < warmup_steps:
            return float(current_step) / float(max(1, warmup_steps))
        progress = float(current_step - warmup_steps) / float(
            max(1, total_steps - warmup_steps)
        )
        return max(lr_min / LEARNING_RATE, 0.5 * (1.0 + math.cos(math.pi * progress)))

    return optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def masked_mse_loss(pred, target, mask):
    """
    Mask-weighted MSE loss.
    Padding elemanlarının kaybını sıfırlar.

    Args:
        pred: [batch, seq, feat]
        target: [batch, seq, feat]
        mask: [batch, seq] — 1.0 gerçek eleman, 0.0 padding
    """
    mask_expanded = mask.unsqueeze(-1).expand_as(pred)
    diff = (pred - target) ** 2
    masked_diff = diff * mask_expanded
    num_active = mask_expanded.sum().clamp(min=1.0)
    return masked_diff.sum() / num_active


DRIVE_CKPT_DIR = "/content/drive/MyDrive/ui_ddpm_checkpoints"


def save_checkpoint(model, optimizer, epoch, loss, filename, ema=None):
    """Model checkpoint'ını kaydeder. Otomatik olarak Drive'a da kopyalar."""
    path = os.path.join(CHECKPOINT_DIR, filename)
    data = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "loss": loss,
    }
    if ema is not None:
        data["ema_state_dict"] = ema.get_model().state_dict()
    torch.save(data, path)
    print(f"  [Checkpoint] Kaydedildi: {path}")

    # Drive'a otomatik yedekle (Colab kapanirsa kaybolmasin)
    try:
        import shutil
        os.makedirs(DRIVE_CKPT_DIR, exist_ok=True)
        drive_path = os.path.join(DRIVE_CKPT_DIR, filename)
        shutil.copy2(path, drive_path)
        print(f"  [Checkpoint] Drive'a yedeklendi: {drive_path}")
    except Exception as e:
        print(f"  [Checkpoint] Drive yedekleme atlandı: {e}")


def load_checkpoint(model, optimizer, filename):
    """Model checkpoint'ını yükler. Yerelde yoksa Drive'dan alır."""
    path = os.path.join(CHECKPOINT_DIR, filename)

    # Yerelde yoksa Drive'dan kopyala
    if not os.path.exists(path):
        drive_path = os.path.join(DRIVE_CKPT_DIR, filename)
        if os.path.exists(drive_path):
            import shutil
            os.makedirs(CHECKPOINT_DIR, exist_ok=True)
            shutil.copy2(drive_path, path)
            print(f"  [Checkpoint] Drive'dan geri yüklendi: {drive_path}")

    if os.path.exists(path):
        checkpoint = torch.load(path, map_location=DEVICE, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])
        if optimizer is not None:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        print(f"  [Checkpoint] Yüklendi: {path} (epoch {checkpoint['epoch']})")
        return checkpoint["epoch"]
    return 0


def plot_losses(train_losses, val_losses, title, filename):
    """Eğitim ve doğrulama kayıp grafiğini çizer."""
    plt.figure(figsize=(10, 5))
    plt.plot(train_losses, label="Eğitim Kaybı", color="#2196F3", linewidth=2)
    if val_losses:
        plt.plot(val_losses, label="Doğrulama Kaybı", color="#FF5722", linewidth=2)
    plt.xlabel("Epoch", fontsize=12)
    plt.ylabel("MSE Loss", fontsize=12)
    plt.title(title, fontsize=14, fontweight="bold")
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    path = os.path.join(FIGURES_DIR, filename)
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  [Grafik] Kaydedildi: {path}")


# ==============================================================================
# Baseline DDPM Eğitimi
# ==============================================================================

def train_baseline(train_loader, val_loader, num_epochs=NUM_EPOCHS,
                   lr=LEARNING_RATE, resume=False):
    """
    Baseline (tek aşamalı) DDPM eğitimi.
    Masked MSE loss ile padding elemanlarını yok sayar.
    """
    print("\n" + "=" * 60)
    print("BASELINE DDPM EĞİTİMİ BAŞLIYOR")
    print("=" * 60)

    model = create_baseline_model()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    scheduler = NoiseScheduler()
    early_stopping = EarlyStopping()
    ema = EMA(model, decay=EMA_DECAY)

    # LR Scheduler
    total_steps = num_epochs * len(train_loader)
    lr_scheduler = get_cosine_schedule_with_warmup(optimizer, LR_WARMUP_STEPS, total_steps)

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(model, optimizer, "baseline_latest.pt")

    train_losses = []
    val_losses = []
    best_val_loss = float("inf")

    start_time = time.time()
    avg_train_loss, avg_val_loss = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        # ---- Eğitim ----
        model.train()
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(
            train_loader,
            desc=f"Epoch {epoch + 1}/{num_epochs} [Eğitim]",
            leave=False,
        )
        for batch in pbar:
            data = batch["data"].to(DEVICE)
            mask = batch["mask"].to(DEVICE)

            t = torch.randint(0, T, (data.shape[0],), device=DEVICE)
            x_t, noise = scheduler.q_sample(data, t)
            noise_pred = model(x_t, t)

            # Masked MSE loss — padding elemanlarını yok say
            loss = masked_mse_loss(noise_pred, noise, mask)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            optimizer.step()
            lr_scheduler.step()
            ema.update(model)

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train_loss = epoch_loss / max(num_batches, 1)
        train_losses.append(avg_train_loss)

        # ---- Doğrulama ----
        model.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                data = batch["data"].to(DEVICE)
                mask = batch["mask"].to(DEVICE)
                t = torch.randint(0, T, (data.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(data, t)
                noise_pred = model(x_t, t)
                loss = masked_mse_loss(noise_pred, noise, mask)
                val_loss += loss.item()
                val_batches += 1

        avg_val_loss = val_loss / max(val_batches, 1)
        val_losses.append(avg_val_loss)

        elapsed = time.time() - start_time
        current_lr = optimizer.param_groups[0]["lr"]
        print(
            f"  Epoch {epoch + 1:3d}/{num_epochs} | "
            f"Eğitim: {avg_train_loss:.5f} | Doğrulama: {avg_val_loss:.5f} | "
            f"LR: {current_lr:.2e} | Süre: {elapsed:.0f}s"
        )

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            save_checkpoint(
                model, optimizer, epoch + 1, avg_val_loss,
                "baseline_best.pt", ema=ema,
            )

        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(
                model, optimizer, epoch + 1, avg_val_loss,
                "baseline_latest.pt", ema=ema,
            )

        early_stopping.step(avg_val_loss)
        if early_stopping.should_stop:
            break

    plot_losses(
        train_losses, val_losses,
        "Baseline DDPM — Eğitim & Doğrulama Kaybı", "baseline_loss.png",
    )
    save_checkpoint(
        model, optimizer, num_epochs, avg_val_loss,
        "baseline_latest.pt", ema=ema,
    )

    total_time = time.time() - start_time
    print(f"\n[Baseline] Eğitim tamamlandı! Toplam süre: {total_time:.0f}s")
    print(f"[Baseline] En iyi doğrulama kaybı: {best_val_loss:.5f}")

    return model, train_losses, val_losses


# ==============================================================================
# Hiyerarşik DDPM Eğitimi
# ==============================================================================

def train_hierarchical(train_loader, val_loader, num_epochs=NUM_EPOCHS,
                       lr=LEARNING_RATE, resume=False):
    """
    Hiyerarşik (iki aşamalı) DDPM eğitimi.
    Her iki aşamada da masked loss, cosine LR ve EMA kullanır.
    """
    print("\n" + "=" * 60)
    print("HİYERARŞİK DDPM EĞİTİMİ BAŞLIYOR")
    print("=" * 60)

    model = create_hierarchical_model()
    scheduler = NoiseScheduler()

    losses = {
        "panel_train": [], "panel_val": [],
        "comp_train": [], "comp_val": [],
    }

    # ==========================================
    # AŞAMA 1: Panel Generator Eğitimi
    # ==========================================
    print("\n--- AŞAMA 1: Panel Generator Eğitimi ---")
    panel_optimizer = optim.AdamW(
        model.panel_generator.parameters(), lr=lr, weight_decay=WEIGHT_DECAY
    )
    panel_ema = EMA(model.panel_generator, decay=EMA_DECAY)
    panel_early_stop = EarlyStopping()
    best_panel_val = float("inf")

    total_steps = num_epochs * len(train_loader)
    panel_lr_scheduler = get_cosine_schedule_with_warmup(
        panel_optimizer, LR_WARMUP_STEPS, total_steps
    )

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(
            model.panel_generator, panel_optimizer, "hier_panel_latest.pt"
        )

    start_time = time.time()
    avg_train, avg_val = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        model.panel_generator.train()
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(
            train_loader,
            desc=f"[Panel] Epoch {epoch + 1}/{num_epochs}",
            leave=False,
        )
        for batch in pbar:
            panels = batch["panels"].to(DEVICE)
            panel_mask = batch["panel_mask"].to(DEVICE)

            t = torch.randint(0, T, (panels.shape[0],), device=DEVICE)
            x_t, noise = scheduler.q_sample(panels, t)
            noise_pred = model.forward_panel(x_t, t)

            loss = masked_mse_loss(noise_pred, noise, panel_mask)

            panel_optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.panel_generator.parameters(), GRAD_CLIP
            )
            panel_optimizer.step()
            panel_lr_scheduler.step()
            panel_ema.update(model.panel_generator)

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train = epoch_loss / max(num_batches, 1)
        losses["panel_train"].append(avg_train)

        model.panel_generator.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                panels = batch["panels"].to(DEVICE)
                panel_mask = batch["panel_mask"].to(DEVICE)
                t = torch.randint(0, T, (panels.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(panels, t)
                noise_pred = model.forward_panel(x_t, t)
                loss = masked_mse_loss(noise_pred, noise, panel_mask)
                val_loss += loss.item()
                val_batches += 1

        avg_val = val_loss / max(val_batches, 1)
        losses["panel_val"].append(avg_val)

        current_lr = panel_optimizer.param_groups[0]["lr"]
        print(
            f"  [Panel] Epoch {epoch + 1:3d}/{num_epochs} | "
            f"Eğitim: {avg_train:.5f} | Doğrulama: {avg_val:.5f} | LR: {current_lr:.2e}"
        )

        if avg_val < best_panel_val:
            best_panel_val = avg_val
            save_checkpoint(
                model.panel_generator, panel_optimizer,
                epoch + 1, avg_val, "hier_panel_best.pt", ema=panel_ema,
            )

        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(
                model.panel_generator, panel_optimizer,
                epoch + 1, avg_val, "hier_panel_latest.pt", ema=panel_ema,
            )

        panel_early_stop.step(avg_val)
        if panel_early_stop.should_stop:
            break

    panel_time = time.time() - start_time
    print(f"[Panel Generator] Eğitim tamamlandı! Süre: {panel_time:.0f}s")
    save_checkpoint(
        model.panel_generator, panel_optimizer,
        num_epochs, avg_val, "hier_panel_latest.pt", ema=panel_ema,
    )

    # ==========================================
    # AŞAMA 2: Component Generator Eğitimi
    # ==========================================
    print("\n--- AŞAMA 2: Component Generator Eğitimi ---")
    comp_optimizer = optim.AdamW(
        model.component_generator.parameters(), lr=lr, weight_decay=WEIGHT_DECAY
    )
    comp_ema = EMA(model.component_generator, decay=EMA_DECAY)
    comp_early_stop = EarlyStopping()
    best_comp_val = float("inf")

    comp_lr_scheduler = get_cosine_schedule_with_warmup(
        comp_optimizer, LR_WARMUP_STEPS, total_steps
    )

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(
            model.component_generator, comp_optimizer, "hier_comp_latest.pt"
        )

    start_time = time.time()
    avg_train, avg_val = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        model.component_generator.train()
        model.panel_generator.eval()
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(
            train_loader,
            desc=f"[Comp.] Epoch {epoch + 1}/{num_epochs}",
            leave=False,
        )
        for batch in pbar:
            panels = batch["panels"].to(DEVICE)
            components = batch["components"].to(DEVICE)
            comp_mask = batch["comp_mask"].to(DEVICE)

            t = torch.randint(0, T, (components.shape[0],), device=DEVICE)
            x_t, noise = scheduler.q_sample(components, t)
            noise_pred = model.forward_component(x_t, t, panels.detach())

            loss = masked_mse_loss(noise_pred, noise, comp_mask)

            comp_optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.component_generator.parameters(), GRAD_CLIP
            )
            comp_optimizer.step()
            comp_lr_scheduler.step()
            comp_ema.update(model.component_generator)

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train = epoch_loss / max(num_batches, 1)
        losses["comp_train"].append(avg_train)

        model.component_generator.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                panels = batch["panels"].to(DEVICE)
                components = batch["components"].to(DEVICE)
                comp_mask = batch["comp_mask"].to(DEVICE)
                t = torch.randint(0, T, (components.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(components, t)
                noise_pred = model.forward_component(x_t, t, panels)
                loss = masked_mse_loss(noise_pred, noise, comp_mask)
                val_loss += loss.item()
                val_batches += 1

        avg_val = val_loss / max(val_batches, 1)
        losses["comp_val"].append(avg_val)

        current_lr = comp_optimizer.param_groups[0]["lr"]
        print(
            f"  [Comp.] Epoch {epoch + 1:3d}/{num_epochs} | "
            f"Eğitim: {avg_train:.5f} | Doğrulama: {avg_val:.5f} | LR: {current_lr:.2e}"
        )

        if avg_val < best_comp_val:
            best_comp_val = avg_val
            save_checkpoint(
                model.component_generator, comp_optimizer,
                epoch + 1, avg_val, "hier_comp_best.pt", ema=comp_ema,
            )

        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(
                model.component_generator, comp_optimizer,
                epoch + 1, avg_val, "hier_comp_latest.pt", ema=comp_ema,
            )

        comp_early_stop.step(avg_val)
        if comp_early_stop.should_stop:
            break

    comp_time = time.time() - start_time
    print(f"[Component Generator] Eğitim tamamlandı! Süre: {comp_time:.0f}s")
    save_checkpoint(
        model.component_generator, comp_optimizer,
        num_epochs, avg_val, "hier_comp_latest.pt", ema=comp_ema,
    )

    plot_losses(
        losses["panel_train"], losses["panel_val"],
        "Panel Generator — Eğitim & Doğrulama Kaybı", "hier_panel_loss.png",
    )
    plot_losses(
        losses["comp_train"], losses["comp_val"],
        "Component Generator — Eğitim & Doğrulama Kaybı", "hier_comp_loss.png",
    )

    print(f"\n[Hiyerarşik DDPM] Toplam eğitim süresi: {panel_time + comp_time:.0f}s")
    print(f"  Panel en iyi val.: {best_panel_val:.5f}")
    print(f"  Comp. en iyi val.: {best_comp_val:.5f}")

    return model, losses


# ==============================================================================
# Görüntü (Image) Difüzyonu Eğitimi (Aşama 2)
# ==============================================================================

def train_image_diffusion(train_loader, val_loader, num_epochs=NUM_EPOCHS,
                          lr=LEARNING_RATE, resume=False):
    from model import create_image_diffusion_model

    print("\n" + "=" * 60)
    print("AŞAMA 2: IMAGE DIFFUSION (U-NET) EĞİTİMİ BAŞLIYOR")
    print("=" * 60)

    model = create_image_diffusion_model()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    scheduler = NoiseScheduler()
    criterion = nn.MSELoss()
    early_stopping = EarlyStopping()
    ema = EMA(model, decay=EMA_DECAY)

    total_steps = num_epochs * len(train_loader)
    lr_scheduler = get_cosine_schedule_with_warmup(optimizer, LR_WARMUP_STEPS, total_steps)

    start_epoch = 0
    if resume:
        start_epoch = load_checkpoint(model, optimizer, "image_diffusion_latest.pt")

    train_losses = []
    val_losses = []
    best_val_loss = float("inf")

    start_time = time.time()
    avg_train_loss, avg_val_loss = 0.0, 0.0

    for epoch in range(start_epoch, num_epochs):
        model.train()
        epoch_loss = 0.0
        num_batches = 0

        pbar = tqdm(
            train_loader,
            desc=f"Epoch {epoch + 1}/{num_epochs} [Eğitim]",
            leave=False,
        )
        for batch in pbar:
            images = batch["image"].to(DEVICE)
            conditions = batch["condition"].to(DEVICE)

            t = torch.randint(0, T, (images.shape[0],), device=DEVICE)
            x_t, noise = scheduler.q_sample(images, t)
            noise_pred = model(x_t, t, conditions)

            loss = criterion(noise_pred, noise)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            optimizer.step()
            lr_scheduler.step()
            ema.update(model)

            epoch_loss += loss.item()
            num_batches += 1
            pbar.set_postfix({"loss": f"{loss.item():.5f}"})

        avg_train_loss = epoch_loss / max(num_batches, 1)
        train_losses.append(avg_train_loss)

        model.eval()
        val_loss = 0.0
        val_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                images = batch["image"].to(DEVICE)
                conditions = batch["condition"].to(DEVICE)
                t = torch.randint(0, T, (images.shape[0],), device=DEVICE)
                x_t, noise = scheduler.q_sample(images, t)
                noise_pred = model(x_t, t, conditions)
                loss = criterion(noise_pred, noise)
                val_loss += loss.item()
                val_batches += 1

        avg_val_loss = val_loss / max(val_batches, 1)
        val_losses.append(avg_val_loss)

        elapsed = time.time() - start_time
        current_lr = optimizer.param_groups[0]["lr"]
        print(
            f"  [Image UNet] Epoch {epoch + 1:3d}/{num_epochs} | "
            f"Eğitim: {avg_train_loss:.5f} | Doğrulama: {avg_val_loss:.5f} | "
            f"LR: {current_lr:.2e} | Süre: {elapsed:.0f}s"
        )

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            save_checkpoint(
                model, optimizer, epoch + 1, avg_val_loss,
                "image_diffusion_best.pt", ema=ema,
            )

        if (epoch + 1) % SAVE_EVERY == 0:
            save_checkpoint(
                model, optimizer, epoch + 1, avg_val_loss,
                "image_diffusion_latest.pt", ema=ema,
            )

        early_stopping.step(avg_val_loss)
        if early_stopping.should_stop:
            break

    plot_losses(
        train_losses, val_losses,
        "Image Diffusion — Eğitim & Doğrulama Kaybı", "image_diffusion_loss.png",
    )
    save_checkpoint(
        model, optimizer, num_epochs, avg_val_loss,
        "image_diffusion_latest.pt", ema=ema,
    )

    total_time = time.time() - start_time
    print(f"\n[Image Diffusion] Eğitim tamamlandı! Süre: {total_time:.0f}s")
    print(f"[Image Diffusion] En iyi doğrulama kaybı: {best_val_loss:.5f}")

    return model, train_losses, val_losses


# ==============================================================================
# Test
# ==============================================================================
if __name__ == "__main__":
    from data_preprocessing import get_dataloaders

    print("=" * 60)
    print("Eğitim Testi (5 epoch, mock veri)")
    print("=" * 60)

    loaders = get_dataloaders(use_mock=True, batch_size=32)

    baseline_model, bl_train_losses, bl_val_losses = train_baseline(
        loaders["baseline_train"], loaders["baseline_val"], num_epochs=5
    )

    hier_model, hier_losses = train_hierarchical(
        loaders["hierarchical_train"], loaders["hierarchical_val"], num_epochs=5
    )

    print("\n[BAŞARILI] Eğitim testi tamamlandı!")
