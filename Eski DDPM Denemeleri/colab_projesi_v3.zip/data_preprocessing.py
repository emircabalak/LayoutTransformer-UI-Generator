"""
data_preprocessing.py — Veri Seti Hazırlama ve Ön İşleme Modülü

RICO veri setinden UI bileşen bilgilerini yükler, hiyerarşik yapıya ayırır
ve PyTorch Dataset/DataLoader oluşturur. RICO bulunamazsa sentetik veri üretir.
"""

import os
import json
import random
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader

from config import (
    DATA_DIR, RICO_JSON_DIR, RICO_IMAGE_DIR, NUM_CLASSES, COMPONENT_CLASSES,
    MAX_PANELS, MAX_COMPONENTS, MAX_ELEMENTS, FEATURE_DIM,
    PANEL_FEATURE_DIM, COMPONENT_FEATURE_DIM,
    BATCH_SIZE, MOCK_DATASET_SIZE, DEVICE,
    IMAGE_SIZE, CLASS_COLORS_RGB,
    normalize_class_id, normalize_parent_idx,
)


# ==============================================================================
# RICO Veri Seti İşleme Yardımcı Fonksiyonları
# ==============================================================================

# RICO bileşen türlerini projemizin sınıflarına eşleyen harita
RICO_CLASS_MAP = {
    # Orijinal RICO componentLabel eşlemeleri
    "Toolbar":       0,
    "List Item":     0,
    "Card":          0,
    "Drawer":        0,
    "Modal":         0,
    "Bottom Navigation": 0,
    "Tab Bar":       0,
    "Button":        1,
    "Text Button":   1,
    "Icon Button":   1,
    "FAB":           1,
    "Input":         2,
    "Text":          3,
    "Text View":     3,
    "Icon":          4,
    "Checkbox":      5,
    "Check Box":     5,
    "Spinner":       6,
    "Slider":        7,
    "Switch":        8,
    "Toggle Button": 8,
    "Image":         9,
    "Image View":    9,
    "Web View":      9,
    # Android widget sınıf adı eşlemeleri
    "LinearLayout":  0,
    "RelativeLayout": 0,
    "FrameLayout":   0,
    "ConstraintLayout": 0,
    "CoordinatorLayout": 0,
    "RecyclerView":  0,
    "ListView":      0,
    "ScrollView":    0,
    "ViewGroup":     0,
    "CardView":      0,
    "NavigationView": 0,
    "TabLayout":     0,
    "AppBarLayout":  0,
    "ActionBar":     0,
    "ImageButton":   1,
    "FloatingActionButton": 1,
    "EditText":      2,
    "AutoCompleteTextView": 2,
    "SearchView":    2,
    "TextInputLayout": 2,
    "TextInputEditText": 2,
    "TextView":      3,
    "ImageView":     9,
    "CheckBox":      5,
    "RadioButton":   5,
    "SeekBar":       7,
    "ProgressBar":   7,
    "ToggleButton":  8,
    "CompoundButton": 8,
}

CHILD_CLASSES = {1, 2, 3, 4, 5, 6, 7, 8, 9}
PANEL_CLASS = 0


def _parse_rico_hierarchy(node, screen_w, screen_h, panels, components, depth=0):
    """
    RICO JSON ağacını özyinelemeli olarak dolaşarak
    panelleri ve alt bileşenleri ayırır.
    """
    if not isinstance(node, dict):
        return

    bounds = node.get("bounds", None)
    class_name = node.get("componentLabel", node.get("className", node.get("class", "")))
    if class_name and "." in class_name:
        class_name = class_name.rsplit(".", 1)[-1]

    mapped_class = None
    for key, val in RICO_CLASS_MAP.items():
        if key.lower() in class_name.lower():
            mapped_class = val
            break

    if bounds and mapped_class is not None and len(bounds) == 4:
        x_min = bounds[0] / screen_w
        y_min = bounds[1] / screen_h
        x_max = bounds[2] / screen_w
        y_max = bounds[3] / screen_h

        if 0 <= x_min < x_max <= 1 and 0 <= y_min < y_max <= 1:
            w = x_max - x_min
            h = y_max - y_min
            if w > 0.02 and h > 0.02:
                if mapped_class == PANEL_CLASS and depth < 3:
                    panels.append([mapped_class, x_min, y_min, x_max, y_max])
                elif mapped_class in CHILD_CLASSES:
                    components.append([mapped_class, x_min, y_min, x_max, y_max])

    children = node.get("children", [])
    for child in children:
        _parse_rico_hierarchy(child, screen_w, screen_h, panels, components, depth + 1)


def _assign_components_to_panels(panels, components):
    """
    Her alt bileşeni, onu en iyi kapsayan (en küçük alanlı) panele atar.
    Döndürülen format: [class_id, x_min, y_min, x_max, y_max, parent_panel_idx]
    """
    assigned = []
    for comp in components:
        _, cx1, cy1, cx2, cy2 = comp
        best_panel_idx = -1
        best_area = float("inf")

        for pi, panel in enumerate(panels):
            _, px1, py1, px2, py2 = panel
            if cx1 >= px1 and cy1 >= py1 and cx2 <= px2 and cy2 <= py2:
                area = (px2 - px1) * (py2 - py1)
                if area < best_area:
                    best_area = area
                    best_panel_idx = pi

        assigned.append(comp + [best_panel_idx])

    return assigned


def _find_image_for_json(jf_path):
    """
    Bir RICO JSON dosyasına karşılık gelen görsel dosyasını bulmaya çalışır.
    Önce rico_images dizininde arar, sonra JSON'un yanında arar.
    """
    basename = os.path.splitext(os.path.basename(jf_path))[0]  # "ui_layout_0"
    # JSON'un bulunduğu alt dizin (ör. "train")
    parent_dir = os.path.basename(os.path.dirname(jf_path))

    # 1. rico_images/<split>/<basename>.png
    img_path = os.path.join(RICO_IMAGE_DIR, parent_dir, f"{basename}.png")
    if os.path.exists(img_path):
        return img_path

    # 2. JSON'un yanında aynı isimle .png
    img_path = os.path.join(os.path.dirname(jf_path), f"{basename}.png")
    if os.path.exists(img_path):
        return img_path

    # 3. JSON'un yanında aynı isimle .jpg
    img_path = os.path.join(os.path.dirname(jf_path), f"{basename}.jpg")
    if os.path.exists(img_path):
        return img_path

    return ""


def load_rico_dataset():
    """
    RICO JSON dosyalarını yükleyerek hiyerarşik UI layout veri seti oluşturur.

    Returns:
        list of dict: Her eleman {'panels': [...], 'components': [...], 'image_path': str}
    """
    cache_path = os.path.join(DATA_DIR, "rico_dataset_cache_v2.pt")

    if os.path.exists(cache_path):
        print(f"[BİLGİ] Önbelleğe alınmış RICO veri seti bulunuyor: {cache_path}")
        try:
            dataset = torch.load(cache_path, weights_only=False)
            print(f"[BİLGİ] {len(dataset)} adet hazır layout yüklendi.")
            return dataset
        except Exception as e:
            print(f"[UYARI] Önbellek yüklenemedi: {e}. Yeniden parse edilecek...")

    dataset = []

    if not os.path.exists(RICO_JSON_DIR):
        print(f"[HATA] RICO JSON dizini bulunamadı: {RICO_JSON_DIR}")
        return None

    json_files = []
    for root_dir, dirs, files in os.walk(RICO_JSON_DIR):
        for f in files:
            if f.endswith(".json"):
                json_files.append(os.path.join(root_dir, f))

    if len(json_files) == 0:
        print("[HATA] Klasörde hiçbir RICO JSON dosyası bulunamadı.")
        return None

    print(f"[BİLGİ] {len(json_files)} adet RICO JSON dosyası bulundu.")

    skipped = 0
    for jf_path in json_files:
        try:
            with open(jf_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            root = None
            if "view_hierarchy" in data:
                vh = data["view_hierarchy"]
                if isinstance(vh, str):
                    vh = json.loads(vh)
                activity = vh.get("activity", {})
                root = activity.get("root", vh)
            elif "activity" in data:
                activity = data.get("activity", {})
                root = activity.get("root", data)
            else:
                root = data

            if root is None:
                skipped += 1
                continue

            screen_w = 1440
            screen_h = 2560

            panels = []
            components = []
            _parse_rico_hierarchy(root, screen_w, screen_h, panels, components)

            if len(panels) == 0:
                skipped += 1
                continue

            panels = panels[:MAX_PANELS]
            components = _assign_components_to_panels(panels, components)
            components = components[:MAX_COMPONENTS]

            if len(components) >= 3:
                image_path = _find_image_for_json(jf_path)
                dataset.append({
                    "panels": panels,
                    "components": components,
                    "image_path": image_path,
                })
            else:
                skipped += 1
        except Exception:
            skipped += 1
            continue

    print(f"[BİLGİ] {len(dataset)} adet geçerli layout yüklendi. ({skipped} atlandı)")

    if len(dataset) > 0:
        try:
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            torch.save(dataset, cache_path)
            print(f"[BİLGİ] Veri seti önbelleğe kaydedildi: {cache_path}")
        except Exception as e:
            print(f"[UYARI] Veri seti önbelleğe kaydedilemedi: {e}")

    return dataset if len(dataset) > 0 else None


# ==============================================================================
# Sentetik (Mock) Veri Üretici
# ==============================================================================

def generate_mock_layout():
    """
    Gerçekçi bir UI layout'u sentetik olarak üretir.
    """
    panels = []
    components = []
    num_panels = random.randint(1, MAX_PANELS)

    layout_type = random.choice(["vertical_split", "horizontal_split", "grid", "sidebar"])

    if layout_type == "vertical_split":
        x_positions = sorted([0.0] + sorted(random.sample(
            [i / 10.0 for i in range(1, 10)], min(num_panels - 1, 8)
        )) + [1.0])
        for i in range(min(num_panels, len(x_positions) - 1)):
            y_start = random.uniform(0.0, 0.1)
            y_end = random.uniform(0.85, 1.0)
            panels.append([PANEL_CLASS, x_positions[i], y_start, x_positions[i + 1], y_end])

    elif layout_type == "horizontal_split":
        y_positions = sorted([0.0] + sorted(random.sample(
            [i / 10.0 for i in range(1, 10)], min(num_panels - 1, 8)
        )) + [1.0])
        for i in range(min(num_panels, len(y_positions) - 1)):
            x_start = random.uniform(0.0, 0.05)
            x_end = random.uniform(0.9, 1.0)
            panels.append([PANEL_CLASS, x_start, y_positions[i], x_end, y_positions[i + 1]])

    elif layout_type == "grid":
        cols = random.choice([1, 2])
        rows = max(1, (num_panels + cols - 1) // cols)
        for r in range(rows):
            for c in range(cols):
                if len(panels) >= num_panels:
                    break
                margin = 0.02
                x1 = c / cols + margin
                y1 = r / rows + margin
                x2 = (c + 1) / cols - margin
                y2 = (r + 1) / rows - margin
                panels.append([PANEL_CLASS, x1, y1, x2, y2])

    else:  # sidebar
        sidebar_w = random.uniform(0.15, 0.3)
        panels.append([PANEL_CLASS, 0.0, 0.0, sidebar_w, 1.0])
        if num_panels >= 2:
            panels.append([PANEL_CLASS, sidebar_w + 0.01, 0.0, 1.0, 1.0])
        for _ in range(num_panels - 2):
            parent = panels[1] if len(panels) > 1 else panels[0]
            px1, py1, px2, py2 = parent[1], parent[2], parent[3], parent[4]
            pw, ph = px2 - px1, py2 - py1
            cx1 = px1 + random.uniform(0, pw * 0.3)
            cy1 = py1 + random.uniform(0, ph * 0.3)
            cx2 = cx1 + random.uniform(pw * 0.2, pw * 0.6)
            cy2 = cy1 + random.uniform(ph * 0.2, ph * 0.6)
            cx2 = min(cx2, px2)
            cy2 = min(cy2, py2)
            if cx2 > cx1 + 0.05 and cy2 > cy1 + 0.05:
                panels.append([PANEL_CLASS, cx1, cy1, cx2, cy2])

    panels = panels[:MAX_PANELS]

    for panel_idx, panel in enumerate(panels):
        _, px1, py1, px2, py2 = panel
        pw = px2 - px1
        ph = py2 - py1

        remaining = MAX_COMPONENTS - len(components)
        if remaining <= 0:
            continue
        num_comps = random.randint(1, min(6, remaining))

        comp_strategy = random.choice(["vertical_list", "form", "toolbar", "mixed"])

        if comp_strategy == "vertical_list":
            step = ph / (num_comps + 1)
            for i in range(num_comps):
                cls = random.choice([1, 3, 4])
                margin_x = pw * random.uniform(0.05, 0.15)
                h = step * random.uniform(0.4, 0.8)
                cx1 = px1 + margin_x
                cy1 = py1 + step * (i + 0.5) - h / 2
                cx2 = px2 - margin_x
                cy2 = cy1 + h
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

        elif comp_strategy == "form":
            step = ph / (num_comps + 1)
            for i in range(num_comps):
                cls = 2 if i % 2 == 1 else 3
                margin_x = pw * 0.1
                h = step * random.uniform(0.3, 0.6)
                cx1 = px1 + margin_x
                cy1 = py1 + step * (i + 0.5) - h / 2
                cx2 = px2 - margin_x
                cy2 = cy1 + h
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

        elif comp_strategy == "toolbar":
            step = pw / (num_comps + 1)
            for i in range(num_comps):
                cls = random.choice([1, 4, 8])
                w = step * random.uniform(0.4, 0.8)
                margin_y = ph * 0.15
                cx1 = px1 + step * (i + 0.5) - w / 2
                cy1 = py1 + margin_y
                cx2 = cx1 + w
                cy2 = py2 - margin_y
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

        else:  # mixed
            for _ in range(num_comps):
                cls = random.randint(1, NUM_CLASSES - 1)
                margin = 0.02
                w = random.uniform(0.1, 0.5) * pw
                h = random.uniform(0.05, 0.3) * ph
                cx1 = px1 + random.uniform(margin, max(margin, pw - w - margin))
                cy1 = py1 + random.uniform(margin, max(margin, ph - h - margin))
                cx2 = cx1 + w
                cy2 = cy1 + h
                cx1 = max(cx1, px1 + 0.005)
                cy1 = max(cy1, py1 + 0.005)
                cx2 = min(cx2, px2 - 0.005)
                cy2 = min(cy2, py2 - 0.005)
                if cx2 > cx1 + 0.01 and cy2 > cy1 + 0.01:
                    components.append([cls, cx1, cy1, cx2, cy2, panel_idx])

    components = components[:MAX_COMPONENTS]
    return {"panels": panels, "components": components, "image_path": ""}


def generate_mock_dataset(size=MOCK_DATASET_SIZE):
    print(f"[BİLGİ] {size} adet sentetik layout üretiliyor...")
    dataset = [generate_mock_layout() for _ in range(size)]
    print(f"[BİLGİ] Sentetik veri seti hazır. Toplam: {len(dataset)} layout.")
    return dataset


# ==============================================================================
# PyTorch Dataset Sınıfları
# ==============================================================================

class BaselineLayoutDataset(Dataset):
    """
    Baseline DDPM için veri seti.
    Tüm elemanlar düz bir listeye dönüştürülür.
    Mask ile padding elemanları ayrılır.
    """

    def __init__(self, raw_data):
        self.data = []
        self.masks = []

        for item in raw_data:
            elements = []
            mask = []

            for panel in item["panels"]:
                cls_norm = normalize_class_id(panel[0])
                elements.append([cls_norm, panel[1], panel[2], panel[3], panel[4]])
                mask.append(1.0)

            for comp in item["components"]:
                cls_norm = normalize_class_id(comp[0])
                elements.append([cls_norm, comp[1], comp[2], comp[3], comp[4]])
                mask.append(1.0)

            elements = elements[:MAX_ELEMENTS]
            mask = mask[:MAX_ELEMENTS]
            while len(elements) < MAX_ELEMENTS:
                elements.append([0.0, 0.0, 0.0, 0.0, 0.0])
                mask.append(0.0)

            tensor_data = torch.tensor(elements, dtype=torch.float32)
            # [-1, 1] normalizasyonu (DDPM için)
            tensor_data = (tensor_data * 2.0) - 1.0

            self.data.append(tensor_data)
            self.masks.append(torch.tensor(mask, dtype=torch.float32))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return {
            "data": self.data[idx],
            "mask": self.masks[idx],
        }


class HierarchicalLayoutDataset(Dataset):
    """
    Hiyerarşik DDPM için veri seti.
    Paneller ve alt bileşenler ayrı tensörler olarak döndürülür.
    """

    def __init__(self, raw_data):
        self.panels_list = []
        self.components_list = []
        self.panel_masks = []
        self.comp_masks = []

        for item in raw_data:
            panels = []
            panel_mask = []
            for p in item["panels"][:MAX_PANELS]:
                cls_norm = normalize_class_id(p[0])
                panels.append([cls_norm, p[1], p[2], p[3], p[4]])
                panel_mask.append(1.0)
            while len(panels) < MAX_PANELS:
                panels.append([0.0, 0.0, 0.0, 0.0, 0.0])
                panel_mask.append(0.0)

            components = []
            comp_mask = []
            for c in item["components"][:MAX_COMPONENTS]:
                cls_norm = normalize_class_id(c[0])
                parent_norm = normalize_parent_idx(c[5])
                components.append([cls_norm, c[1], c[2], c[3], c[4], parent_norm])
                comp_mask.append(1.0)
            while len(components) < MAX_COMPONENTS:
                components.append([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
                comp_mask.append(0.0)

            panels_tensor = torch.tensor(panels, dtype=torch.float32)
            components_tensor = torch.tensor(components, dtype=torch.float32)

            # [-1, 1] normalizasyonu
            panels_tensor = (panels_tensor * 2.0) - 1.0
            components_tensor = (components_tensor * 2.0) - 1.0

            self.panels_list.append(panels_tensor)
            self.components_list.append(components_tensor)
            self.panel_masks.append(torch.tensor(panel_mask, dtype=torch.float32))
            self.comp_masks.append(torch.tensor(comp_mask, dtype=torch.float32))

    def __len__(self):
        return len(self.panels_list)

    def __getitem__(self, idx):
        return {
            "panels": self.panels_list[idx],
            "components": self.components_list[idx],
            "panel_mask": self.panel_masks[idx],
            "comp_mask": self.comp_masks[idx],
        }


# ==============================================================================
# Aşama 2 (Görsel Difüzyonu) Veri Sınıfı
# ==============================================================================

def render_layout_to_image(panels, components, image_size=IMAGE_SIZE, image_path=""):
    """
    Layout bilgisinden hedef görsel ve koşul maskesi üretir.
    Gerçek resim varsa onu yükler, yoksa sentetik render yapar.

    Returns:
        img_tensor: [3, H, W] RGB görseli ([-1, 1] arası)
        cond_tensor: [NUM_CLASSES, H, W] Koşullandırma sınıf maskesi
    """
    from PIL import Image

    # Koşul maskesi (Condition) — sınıf bazlı segmentasyon haritası
    cond = np.zeros((NUM_CLASSES, image_size, image_size), dtype=np.float32)

    def draw_cond_box(box, cls_id):
        cls_id = int(cls_id)
        if cls_id < 0 or cls_id >= NUM_CLASSES:
            return
        x1, y1 = int(box[1] * image_size), int(box[2] * image_size)
        x2, y2 = int(box[3] * image_size), int(box[4] * image_size)
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(image_size, x2), min(image_size, y2)
        if x2 > x1 and y2 > y1:
            cond[cls_id, y1:y2, x1:x2] = 1.0

    for p in panels:
        draw_cond_box(p, p[0])
    for c in components:
        draw_cond_box(c, c[0])

    cond_tensor = torch.tensor(cond)

    # Hedef Resim
    if image_path and os.path.exists(image_path):
        try:
            pil_img = Image.open(image_path).convert("RGB")
            pil_img = pil_img.resize((image_size, image_size))
            img = np.array(pil_img, dtype=np.float32)
        except Exception:
            img = _render_synthetic_image(panels, components, image_size)
    else:
        img = _render_synthetic_image(panels, components, image_size)

    # [-1, 1] Normalizasyonu
    img = (img / 127.5) - 1.0

    img_tensor = torch.tensor(img).permute(2, 0, 1)  # [3, H, W]
    return img_tensor, cond_tensor


def _render_synthetic_image(panels, components, image_size):
    """
    Bounding box'lardan sentetik UI görseli render eder.
    CLASS_COLORS_RGB (0-255 RGB) kullanır.
    """
    img = np.ones((image_size, image_size, 3), dtype=np.float32) * 240.0  # Açık gri arka plan

    def draw_color_box(box, cls_id):
        cls_id = int(cls_id)
        x1, y1 = int(box[1] * image_size), int(box[2] * image_size)
        x2, y2 = int(box[3] * image_size), int(box[4] * image_size)
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(image_size, x2), min(image_size, y2)
        if x2 > x1 and y2 > y1:
            color = CLASS_COLORS_RGB.get(cls_id, (100, 100, 100))
            # Kutu dolgusu
            img[y1:y2, x1:x2, 0] = color[0]
            img[y1:y2, x1:x2, 1] = color[1]
            img[y1:y2, x1:x2, 2] = color[2]
            # Kenarlık çiz (2px)
            border = min(2, (x2 - x1) // 4, (y2 - y1) // 4)
            if border > 0:
                darker = tuple(max(0, c - 40) for c in color)
                # Üst ve alt kenarlık
                img[y1:y1+border, x1:x2, :] = darker
                img[y2-border:y2, x1:x2, :] = darker
                # Sol ve sağ kenarlık
                img[y1:y2, x1:x1+border, :] = darker
                img[y1:y2, x2-border:x2, :] = darker

    # Önce panelleri çiz (arka plan), sonra bileşenleri (ön plan)
    for p in panels:
        draw_color_box(p, p[0])
    for c in components:
        draw_color_box(c, c[0])

    return img


class ImageDiffusionDataset(Dataset):
    """Aşama 2 için RGB Target + Condition Mask DataLoader'ı."""

    def __init__(self, data_list):
        self.data_list = data_list
        self.image_size = IMAGE_SIZE

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        item = self.data_list[idx]
        img_path = item.get("image_path", "")
        img_tensor, cond_tensor = render_layout_to_image(
            item["panels"], item["components"], self.image_size, img_path
        )
        return {
            "image": img_tensor,
            "condition": cond_tensor,
        }


# ==============================================================================
# DataLoader Oluşturucu
# ==============================================================================

def get_dataloaders(use_mock=False, batch_size=BATCH_SIZE, val_split=0.1):
    """
    Eğitim ve doğrulama DataLoader'larını oluşturur.
    """
    raw_data = None
    if not use_mock:
        raw_data = load_rico_dataset()

    if raw_data is None:
        if use_mock:
            raw_data = generate_mock_dataset()
        else:
            raise FileNotFoundError(
                "\n[KRİTİK HATA] Gerçek RICO veri seti bulunamadı! "
                "Lütfen önce veri setini indirin."
            )

    random.shuffle(raw_data)
    val_size = max(1, int(len(raw_data) * val_split))
    train_data = raw_data[val_size:]
    val_data = raw_data[:val_size]

    print(f"[BİLGİ] Eğitim seti: {len(train_data)}, Doğrulama seti: {len(val_data)}")

    # Baseline DataLoader
    baseline_train_ds = BaselineLayoutDataset(train_data)
    baseline_val_ds = BaselineLayoutDataset(val_data)

    baseline_train_loader = DataLoader(
        baseline_train_ds, batch_size=batch_size, shuffle=True, drop_last=True,
        num_workers=2, pin_memory=True,
    )
    baseline_val_loader = DataLoader(
        baseline_val_ds, batch_size=batch_size, shuffle=False,
        num_workers=2, pin_memory=True,
    )

    # Hierarchical DataLoader
    hier_train_ds = HierarchicalLayoutDataset(train_data)
    hier_val_ds = HierarchicalLayoutDataset(val_data)

    hier_train_loader = DataLoader(
        hier_train_ds, batch_size=batch_size, shuffle=True, drop_last=True,
        num_workers=2, pin_memory=True,
    )
    hier_val_loader = DataLoader(
        hier_val_ds, batch_size=batch_size, shuffle=False,
        num_workers=2, pin_memory=True,
    )

    # Image Diffusion DataLoader
    image_train_ds = ImageDiffusionDataset(train_data)
    image_val_ds = ImageDiffusionDataset(val_data)

    image_train_loader = DataLoader(
        image_train_ds, batch_size=batch_size, shuffle=True, drop_last=True,
        num_workers=2, pin_memory=True,
    )
    image_val_loader = DataLoader(
        image_val_ds, batch_size=batch_size, shuffle=False,
        num_workers=2, pin_memory=True,
    )

    return {
        "baseline_train": baseline_train_loader,
        "baseline_val": baseline_val_loader,
        "hierarchical_train": hier_train_loader,
        "hierarchical_val": hier_val_loader,
        "image_train": image_train_loader,
        "image_val": image_val_loader,
        "raw_data": raw_data,
    }


# ==============================================================================
# Test
# ==============================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("Veri Ön İşleme Testi")
    print("=" * 60)

    loaders = get_dataloaders(use_mock=True, batch_size=4)

    for batch in loaders["baseline_train"]:
        print(f"\n[Baseline] Data shape: {batch['data'].shape}")
        print(f"  Mask shape: {batch['mask'].shape}")
        print(f"  İlk örnek, ilk eleman: {batch['data'][0, 0]}")
        print(f"  Mask[0]: {batch['mask'][0]}")
        break

    for batch in loaders["hierarchical_train"]:
        print(f"\n[Hierarchical] Panels shape: {batch['panels'].shape}")
        print(f"  Components shape: {batch['components'].shape}")
        print(f"  Panel mask: {batch['panel_mask'][0]}")
        print(f"  Comp mask sum: {batch['comp_mask'][0].sum().item()}")
        break

    print("\n[BAŞARILI] Veri ön işleme testi tamamlandı!")
