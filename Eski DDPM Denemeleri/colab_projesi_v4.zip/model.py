"""
model.py — LayoutTransformer Modeli

GPT tarzı autoregressive transformer ile UI layout üretimi.
Her layout elemanı 5 token olarak temsil edilir: [class, x_min, y_min, x_max, y_max]
Model, bir sonraki token'ı tahmin ederek sıralı şekilde layout üretir.
"""

import torch
import torch.nn as nn

from config import (
    VOCAB_SIZE, MAX_SEQ_LEN, HIDDEN_DIM, NUM_LAYERS, NHEAD, DROPOUT, DEVICE,
)


class LayoutTransformer(nn.Module):
    """
    GPT-tarzı autoregressive transformer.
    Layout elemanlarını token dizisi olarak modelleyip bir sonraki token'ı tahmin eder.
    """

    def __init__(self, vocab_size=VOCAB_SIZE, max_seq_len=MAX_SEQ_LEN,
                 d_model=HIDDEN_DIM, nhead=NHEAD, num_layers=NUM_LAYERS,
                 dropout=DROPOUT):
        super().__init__()
        self.d_model = d_model
        self.max_seq_len = max_seq_len
        self.vocab_size = vocab_size

        # Token embedding + pozisyonel encoding
        self.token_embedding = nn.Embedding(vocab_size, d_model)
        self.position_embedding = nn.Embedding(max_seq_len, d_model)
        self.drop = nn.Dropout(dropout)

        # Transformer decoder katmanları (causal self-attention)
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            activation='gelu',
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerDecoder(decoder_layer, num_layers=num_layers)

        # Çıkış katmanı
        self.ln_f = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)

        # Ağırlık paylaşımı (weight tying)
        self.head.weight = self.token_embedding.weight

        self._init_weights()

    def _init_weights(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def _generate_causal_mask(self, seq_len, device):
        """Causal (üst üçgen) maske — gelecek token'ları maskeler."""
        mask = torch.triu(torch.ones(seq_len, seq_len, device=device), diagonal=1)
        return mask.bool()

    def forward(self, x, padding_mask=None):
        """
        x: [batch, seq_len] — token ID'leri
        padding_mask: [batch, seq_len] — True = pad pozisyonu (opsiyonel)

        Returns: [batch, seq_len, vocab_size] — logits
        """
        batch_size, seq_len = x.shape
        device = x.device

        positions = torch.arange(seq_len, device=device).unsqueeze(0).expand(batch_size, -1)
        tok_emb = self.token_embedding(x)
        pos_emb = self.position_embedding(positions)
        h = self.drop(tok_emb + pos_emb)

        causal_mask = self._generate_causal_mask(seq_len, device)

        # Decoder-only: boş memory ile self-attention
        memory = torch.zeros(batch_size, 1, self.d_model, device=device)

        h = self.transformer(
            h, memory,
            tgt_mask=causal_mask,
            tgt_key_padding_mask=padding_mask,
        )

        h = self.ln_f(h)
        logits = self.head(h)
        return logits


def create_model():
    """LayoutTransformer modelini oluşturur ve cihaza taşır."""
    model = LayoutTransformer().to(DEVICE)
    num_params = sum(p.numel() for p in model.parameters())
    print(f"[Model] LayoutTransformer: {num_params / 1e6:.1f}M parametre")
    return model
