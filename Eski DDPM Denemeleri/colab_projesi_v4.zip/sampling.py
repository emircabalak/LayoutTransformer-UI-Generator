"""
sampling.py — LayoutTransformer Örnekleme

Autoregressive token üretimi ile UI layout oluşturur.
- Serbest üretim: Model tüm layout'u sıfırdan üretir
- Sınıf-koşullu üretim: Kullanıcı sınıfları belirler, model koordinatları üretir

Temperature, top-k ve nucleus (top-p) sampling destekler.
"""

import torch
import json
import os
from tqdm import tqdm

from config import (
    DEVICE, NUM_SAMPLES, MAX_SEQ_LEN, TOKENS_PER_ELEMENT,
    VOCAB_SIZE, PAD_TOKEN, BOS_TOKEN, EOS_TOKEN,
    COORD_OFFSET, CLASS_OFFSET, STYLE_OFFSET,
    NUM_COORD_BINS, NUM_CLASSES, NUM_STYLES,
    COMPONENT_CLASSES, SAMPLES_DIR,
    TEMPERATURE, TOP_K, TOP_P,
    token_to_class, token_to_coord, class_to_token, token_to_style,
)
from data_preprocessing import tokens_to_layout


def top_k_top_p_filtering(logits, top_k=0, top_p=0.0, temperature=1.0):
    """Top-k ve/veya nucleus (top-p) filtering uygular."""
    logits = logits / max(temperature, 1e-8)

    if top_k > 0:
        top_k = min(top_k, logits.size(-1))
        indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
        logits[indices_to_remove] = float('-inf')

    if top_p > 0.0:
        sorted_logits, sorted_indices = torch.sort(logits, descending=True)
        cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
        sorted_indices_to_remove = cumulative_probs > top_p
        sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
        sorted_indices_to_remove[..., 0] = 0
        indices_to_remove = sorted_indices_to_remove.scatter(
            dim=-1, index=sorted_indices, src=sorted_indices_to_remove
        )
        logits[indices_to_remove] = float('-inf')

    return logits


def _get_valid_token_mask(position_in_element, device):
    """
    Pozisyona göre geçerli token'ları belirler.
    position_in_element: 0=class, 1-4=koordinat, 5=stil
    """
    mask = torch.zeros(VOCAB_SIZE, device=device)

    if position_in_element == 0:
        # Sınıf token'ı veya EOS
        for c in range(NUM_CLASSES):
            mask[CLASS_OFFSET + c] = 1.0
        mask[EOS_TOKEN] = 1.0
    elif position_in_element <= 4:
        # Koordinat token'ları
        for b in range(NUM_COORD_BINS):
            mask[COORD_OFFSET + b] = 1.0
    else:
        # Stil token'ları (pozisyon 5)
        for s in range(NUM_STYLES):
            mask[STYLE_OFFSET + s] = 1.0

    return mask


# ==============================================================================
# Serbest Üretim (Unconditional)
# ==============================================================================

@torch.no_grad()
def sample_layouts(model, num_samples=NUM_SAMPLES, temperature=TEMPERATURE,
                   top_k=TOP_K, top_p=TOP_P):
    """
    Serbest autoregressive layout üretimi.
    Model tüm token'ları kendisi üretir: [BOS, cls, x1, y1, x2, y2, ..., EOS]
    """
    model.eval()
    print(f"\n[Ornekleme] {num_samples} adet layout uretiliyor...")

    generated = torch.full((num_samples, 1), BOS_TOKEN, dtype=torch.long, device=DEVICE)
    finished = torch.zeros(num_samples, dtype=torch.bool, device=DEVICE)

    for step in tqdm(range(MAX_SEQ_LEN - 1), desc="Token uretimi", leave=False):
        if finished.all():
            break

        logits = model(generated)
        next_logits = logits[:, -1, :]

        tokens_generated = generated.shape[1] - 1
        pos_in_elem = tokens_generated % TOKENS_PER_ELEMENT

        valid_mask = _get_valid_token_mask(pos_in_elem, DEVICE)
        valid_mask[PAD_TOKEN] = 0.0
        valid_mask[BOS_TOKEN] = 0.0

        next_logits = next_logits + (1 - valid_mask).unsqueeze(0) * (-1e10)

        filtered_logits = top_k_top_p_filtering(
            next_logits.clone(), top_k=top_k, top_p=top_p, temperature=temperature
        )

        probs = torch.softmax(filtered_logits, dim=-1)
        next_token = torch.multinomial(probs, num_samples=1)

        next_token[finished] = PAD_TOKEN
        finished = finished | (next_token.squeeze(-1) == EOS_TOKEN)

        generated = torch.cat([generated, next_token], dim=1)

    layouts = []
    for i in range(num_samples):
        tokens = generated[i].cpu().tolist()
        elements = tokens_to_layout(tokens)
        layouts.append(elements)

    valid_count = sum(1 for l in layouts if len(l) >= 1)
    print(f"[Ornekleme] Tamamlandi. Gecerli layout: {valid_count}/{num_samples}")

    return layouts


# ==============================================================================
# Sınıf-Koşullu Üretim (Class-Conditioned)
# ==============================================================================

def _build_conditioned_prompt(class_list):
    """
    Sınıf listesinden koşullu prompt token dizisi oluşturur.
    Sınıf token'ları sabit, koordinat ve stil pozisyonlarına placeholder (None) konur.

    class_list: sınıf adları veya ID'leri listesi
                ör: ["Panel", "Button", "Button", "TextInput", "Image"]
                ör: [0, 1, 1, 2, 9]

    Returns: (prompt_tokens, gen_positions)
        prompt_tokens: [BOS, cls1, None, None, None, None, None, cls2, ...]
        gen_positions: model tarafından doldurulacak pozisyon indeksleri (koordinat + stil)
    """
    prompt_tokens = [BOS_TOKEN]
    gen_positions = []

    for cls in class_list:
        # Sınıf adı veya ID kabul et
        if isinstance(cls, str):
            cls_name = cls.strip()
            cls_id = None
            for i, name in enumerate(COMPONENT_CLASSES):
                if name.lower() == cls_name.lower():
                    cls_id = i
                    break
            if cls_id is None:
                print(f"  [UYARI] Bilinmeyen sinif: '{cls_name}', atlaniyor.")
                continue
        else:
            cls_id = int(cls)
            if cls_id < 0 or cls_id >= NUM_CLASSES:
                continue

        cls_token = class_to_token(cls_id)
        prompt_tokens.append(cls_token)

        # 4 koordinat + 1 stil = 5 pozisyonu işaretle
        for _ in range(5):
            pos = len(prompt_tokens)
            gen_positions.append(pos)
            prompt_tokens.append(None)  # Placeholder

    return prompt_tokens, gen_positions


@torch.no_grad()
def sample_conditioned(model, class_list, num_samples=1, temperature=TEMPERATURE,
                       top_k=TOP_K, top_p=TOP_P):
    """
    Sınıf-koşullu layout üretimi.

    Kullanıcı hangi UI elemanlarını istediğini belirtir,
    model her eleman için koordinatları (x_min, y_min, x_max, y_max) üretir.

    Args:
        model: Eğitilmiş LayoutTransformer
        class_list: İstenen sınıflar listesi
                    ör: ["Panel", "Button", "Button", "TextInput"]
                    ör: [0, 1, 1, 2]
        num_samples: Kaç farklı layout üretilecek
        temperature: Örnekleme sıcaklığı
        top_k: Top-k sampling (0=kapalı)
        top_p: Nucleus sampling (0=kapalı)

    Returns:
        list of list: Her biri eleman listesi [[cls, x1, y1, x2, y2], ...]
    """
    model.eval()

    # Sınıf adlarını göster
    class_names = []
    for cls in class_list:
        if isinstance(cls, str):
            class_names.append(cls)
        elif 0 <= int(cls) < NUM_CLASSES:
            class_names.append(COMPONENT_CLASSES[int(cls)])
    print(f"\n[Kosullu Ornekleme] Siniflar: {class_names}")
    print(f"  {num_samples} adet varyasyon uretiliyor...")

    prompt_template, coord_positions = _build_conditioned_prompt(class_list)
    total_len = len(prompt_template)  # BOS + n*(cls+4coords)

    all_layouts = []

    for sample_idx in range(num_samples):
        # Prompt'u kopyala, sabit token'ları yerleştir
        current_seq = []
        gen_counter = 0  # Kaçıncı generate pozisyonundayız
        for tok in prompt_template:
            if tok is not None:
                current_seq.append(tok)
                # Sabit token eklendiyse devam et
            else:
                # Bu pozisyon model tarafından doldurulacak
                input_tensor = torch.tensor([current_seq], dtype=torch.long, device=DEVICE)
                logits = model(input_tensor)
                next_logits = logits[0, -1, :]

                # Her elemanda 5 generate pozisyonu var: 4 koordinat + 1 stil
                pos_in_gen = gen_counter % 5  # 0-3 = koordinat, 4 = stil

                valid_mask = torch.zeros(VOCAB_SIZE, device=DEVICE)
                if pos_in_gen < 4:
                    # Koordinat pozisyonu
                    for b in range(NUM_COORD_BINS):
                        valid_mask[COORD_OFFSET + b] = 1.0
                else:
                    # Stil pozisyonu
                    for s in range(NUM_STYLES):
                        valid_mask[STYLE_OFFSET + s] = 1.0

                next_logits = next_logits + (1 - valid_mask) * (-1e10)

                filtered = top_k_top_p_filtering(
                    next_logits.unsqueeze(0).clone(),
                    top_k=top_k, top_p=top_p, temperature=temperature
                )
                probs = torch.softmax(filtered[0], dim=-1)
                next_token = torch.multinomial(probs, num_samples=1).item()
                current_seq.append(next_token)
                gen_counter += 1

        # EOS ekle
        current_seq.append(EOS_TOKEN)

        # Token dizisini layout'a çevir
        elements = tokens_to_layout(current_seq)
        all_layouts.append(elements)

    valid_count = sum(1 for l in all_layouts if len(l) >= 1)
    print(f"[Kosullu Ornekleme] Tamamlandi. Gecerli: {valid_count}/{num_samples}")

    return all_layouts


# ==============================================================================
# JSON Kaydetme
# ==============================================================================

def layouts_to_json(layouts, filename="generated_layouts.json"):
    """Üretilen layout'ları JSON olarak kaydeder."""
    results = []
    for i, elements in enumerate(layouts):
        layout = {"id": i, "elements": []}
        for elem in elements:
            cls_id = int(elem[0])
            cls_name = COMPONENT_CLASSES[cls_id] if 0 <= cls_id < NUM_CLASSES else "Unknown"
            style_id = int(elem[5]) if len(elem) > 5 else 0
            layout["elements"].append({
                "class": cls_name,
                "class_id": cls_id,
                "x_min": round(elem[1], 4),
                "y_min": round(elem[2], 4),
                "x_max": round(elem[3], 4),
                "y_max": round(elem[4], 4),
                "style_id": style_id,
            })
        results.append(layout)

    path = os.path.join(SAMPLES_DIR, filename)
    os.makedirs(SAMPLES_DIR, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[JSON] {len(results)} layout kaydedildi: {path}")
    return results
