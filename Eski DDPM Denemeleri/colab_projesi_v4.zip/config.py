"""
config.py — Merkezi Hiperparametre ve Konfigürasyon Dosyası

LayoutTransformer ile UI Layout Üretimi projesi
için tüm ayarlar bu dosyada tanımlanmıştır.
"""

import torch
import os

# ==============================================================================
# Cihaz Ayarı
# ==============================================================================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ==============================================================================
# Veri Seti Ayarları
# ==============================================================================
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
RICO_JSON_DIR = os.path.join(DATA_DIR, "rico_jsons")
RICO_IMAGE_DIR = os.path.join(DATA_DIR, "rico_images")

# Bileşen sınıfları (RICO veri setinden filtrelenen temel UI elemanları)
COMPONENT_CLASSES = [
    "Panel",          # 0
    "Button",         # 1
    "TextInput",      # 2
    "Label",          # 3
    "Icon",           # 4
    "CheckBox",       # 5
    "Dropdown",       # 6
    "Slider",         # 7
    "Toggle",         # 8
    "Image",          # 9
]
NUM_CLASSES = len(COMPONENT_CLASSES)

# Koordinat ayrıklaştırma: [0, 1] aralığı NUM_COORD_BINS kutucuğa bölünür
NUM_COORD_BINS = 32

# Stil token'ları: her eleman için görsel stil varyasyonu
NUM_STYLES = 8

# Özel tokenler
PAD_TOKEN = 0
BOS_TOKEN = 1
EOS_TOKEN = 2
COORD_OFFSET = 3                          # Koordinat token'ları 3'ten başlar
CLASS_OFFSET = COORD_OFFSET + NUM_COORD_BINS  # Sınıf token'ları koordinatlardan sonra
STYLE_OFFSET = CLASS_OFFSET + NUM_CLASSES  # Stil token'ları sınıflardan sonra
VOCAB_SIZE = STYLE_OFFSET + NUM_STYLES    # Toplam kelime hazinesi boyutu

# Her eleman 6 token: [class, x_min, y_min, x_max, y_max, style]
TOKENS_PER_ELEMENT = 6

# Sabit boyutlu padding için maksimum sayılar
MAX_ELEMENTS = 25       # Bir layout'taki maksimum eleman sayısı (panel + bileşen)
MAX_SEQ_LEN = MAX_ELEMENTS * TOKENS_PER_ELEMENT + 2  # +2 BOS ve EOS için

# ==============================================================================
# Normalizasyon Yardımcıları (eski kod uyumluluğu için korunuyor)
# ==============================================================================
MAX_PANELS = 5
MAX_COMPONENTS = 20
FEATURE_DIM = 5
PANEL_FEATURE_DIM = 5
COMPONENT_FEATURE_DIM = 6
MOCK_DATASET_SIZE = 2000

def normalize_class_id(cls_id):
    return (cls_id + 1) / (NUM_CLASSES + 1)

def denormalize_class_id(cls_norm):
    cls_idx = int(round(cls_norm * (NUM_CLASSES + 1))) - 1
    return max(-1, min(cls_idx, NUM_CLASSES - 1))

def normalize_parent_idx(parent_idx):
    return (parent_idx + 1) / (MAX_PANELS + 1)

def denormalize_parent_idx(parent_norm):
    return int(round(parent_norm * (MAX_PANELS + 1))) - 1


# ==============================================================================
# Koordinat Dönüştürme Fonksiyonları
# ==============================================================================
def coord_to_token(val):
    """[0, 1] aralığındaki koordinatı token'a çevirir."""
    val = max(0.0, min(1.0, val))
    bin_idx = int(val * (NUM_COORD_BINS - 1))
    return bin_idx + COORD_OFFSET

def token_to_coord(tok):
    """Token'ı [0, 1] aralığındaki koordinata çevirir."""
    bin_idx = tok - COORD_OFFSET
    return bin_idx / (NUM_COORD_BINS - 1)

def class_to_token(cls_id):
    """Sınıf ID'sini token'a çevirir."""
    return cls_id + CLASS_OFFSET

def token_to_class(tok):
    """Token'ı sınıf ID'sine çevirir."""
    return tok - CLASS_OFFSET

def style_to_token(style_id):
    """Stil ID'sini token'a çevirir."""
    return style_id + STYLE_OFFSET

def token_to_style(tok):
    """Token'ı stil ID'sine çevirir."""
    return tok - STYLE_OFFSET


# ==============================================================================
# Model Mimarisi Ayarları
# ==============================================================================
HIDDEN_DIM = 256        # Transformer gizli katman boyutu
NUM_LAYERS = 6          # Transformer katman sayısı
NHEAD = 8               # Dikkat mekanizması kafa sayısı
DROPOUT = 0.1           # Dropout oranı

# ==============================================================================
# Eğitim Ayarları
# ==============================================================================
BATCH_SIZE = 128        # A100 GPU ile 128 batch rahat çalışır
NUM_EPOCHS = 200        # Transformer daha hızlı converge eder
LEARNING_RATE = 3e-4    # Adam için standart
WEIGHT_DECAY = 1e-4
GRAD_CLIP = 1.0
SAVE_EVERY = 10         # Her kaç epoch'ta bir checkpoint kaydet
EARLY_STOP_PATIENCE = 30

LR_WARMUP_STEPS = 500
LR_MIN = 1e-6

# ==============================================================================
# Örnekleme Ayarları
# ==============================================================================
NUM_SAMPLES = 100       # Değerlendirme için üretilecek örnek sayısı
TEMPERATURE = 0.9       # Örnekleme sıcaklığı (düşük = daha deterministik)
TOP_K = 0               # Top-k örnekleme (0 = kapalı)
TOP_P = 0.9             # Nucleus sampling (0 = kapalı)

# ==============================================================================
# Görselleştirme
# ==============================================================================
# Rendering için RGB renk kodları (0-255)
CLASS_COLORS_RGB = {
    0: (230, 230, 230),  # Panel
    1: (33, 150, 243),   # Button
    2: (255, 193, 7),    # TextInput
    3: (60, 60, 60),     # Label
    4: (156, 39, 176),   # Icon
    5: (76, 175, 80),    # CheckBox
    6: (255, 87, 34),    # Dropdown
    7: (0, 188, 212),    # Slider
    8: (233, 30, 99),    # Toggle
    9: (139, 195, 74),   # Image
}

# Görselleştirme için RGBA renk kodları (0-1)
CLASS_COLORS_VIZ = {
    0: (0.2, 0.4, 0.8, 0.3),    # Panel
    1: (0.9, 0.3, 0.3, 0.7),    # Button
    2: (0.3, 0.8, 0.3, 0.7),    # TextInput
    3: (0.9, 0.9, 0.2, 0.7),    # Label
    4: (0.6, 0.3, 0.9, 0.7),    # Icon
    5: (0.3, 0.9, 0.9, 0.7),    # CheckBox
    6: (0.9, 0.6, 0.2, 0.7),    # Dropdown
    7: (0.5, 0.5, 0.5, 0.7),    # Slider
    8: (0.2, 0.7, 0.5, 0.7),    # Toggle
    9: (0.8, 0.4, 0.6, 0.7),    # Image
}

# ==============================================================================
# Stil Paletleri (Mockup Renderer için)
# Her sınıf için 8 stil varyasyonu: (fill_color, text/accent_color, label)
# ==============================================================================
STYLE_PALETTES = {
    # Panel stilleri
    0: {
        0: ((255, 255, 255), (220, 220, 220), "White"),
        1: ((240, 240, 245), (200, 200, 210), "Light Gray"),
        2: ((227, 242, 253), (144, 202, 249), "Light Blue"),
        3: ((232, 245, 233), (165, 214, 167), "Light Green"),
        4: ((40, 40, 50),    (70, 70, 85),    "Dark"),
        5: ((255, 248, 225), (255, 224, 130), "Cream"),
        6: ((243, 229, 245), (206, 147, 216), "Lavender"),
        7: ((224, 247, 250), (128, 222, 234), "Ice Blue"),
    },
    # Button stilleri
    1: {
        0: ((33, 150, 243),  (255, 255, 255), "Submit"),
        1: ((76, 175, 80),   (255, 255, 255), "OK"),
        2: ((255, 152, 0),   (255, 255, 255), "Warning"),
        3: ((244, 67, 54),   (255, 255, 255), "Delete"),
        4: ((55, 55, 65),    (255, 255, 255), "Dark"),
        5: ((255, 255, 255), (33, 150, 243),  "Outline"),
        6: ((156, 39, 176),  (255, 255, 255), "Action"),
        7: ((0, 150, 136),   (255, 255, 255), "Confirm"),
    },
    # TextInput stilleri
    2: {
        0: ((255, 255, 255), (180, 180, 180), "Type here..."),
        1: ((255, 255, 255), (180, 180, 180), "Email"),
        2: ((255, 255, 255), (180, 180, 180), "Search..."),
        3: ((255, 255, 255), (180, 180, 180), "Password"),
        4: ((245, 245, 245), (160, 160, 160), "Username"),
        5: ((255, 255, 255), (180, 180, 180), "Phone"),
        6: ((255, 255, 255), (180, 180, 180), "Address"),
        7: ((248, 248, 255), (150, 150, 180), "Message..."),
    },
    # Label stilleri
    3: {
        0: ((245, 245, 245), (60, 60, 60),    "Dark Text"),
        1: ((245, 245, 245), (100, 100, 100),  "Gray Text"),
        2: ((245, 245, 245), (33, 150, 243),   "Blue Text"),
        3: ((245, 245, 245), (76, 175, 80),    "Green Text"),
        4: ((245, 245, 245), (244, 67, 54),    "Red Text"),
        5: ((245, 245, 245), (156, 39, 176),   "Purple Text"),
        6: ((245, 245, 245), (130, 130, 130),  "Light Text"),
        7: ((245, 245, 245), (0, 150, 136),    "Teal Text"),
    },
    # Icon stilleri
    4: {
        0: ((156, 39, 176),  (200, 170, 210), "Purple"),
        1: ((33, 150, 243),  (144, 202, 249), "Blue"),
        2: ((244, 67, 54),   (255, 171, 145), "Red"),
        3: ((76, 175, 80),   (165, 214, 167), "Green"),
        4: ((255, 152, 0),   (255, 204, 128), "Orange"),
        5: ((55, 55, 65),    (140, 140, 155), "Dark"),
        6: ((0, 150, 136),   (128, 222, 234), "Teal"),
        7: ((233, 30, 99),   (248, 187, 208), "Pink"),
    },
    # CheckBox stilleri
    5: {
        0: ((76, 175, 80),   (56, 142, 60),   "Green Checked"),
        1: ((33, 150, 243),  (25, 118, 210),  "Blue Checked"),
        2: ((255, 255, 255), (180, 180, 180),  "Unchecked"),
        3: ((156, 39, 176),  (123, 31, 162),  "Purple Checked"),
        4: ((244, 67, 54),   (211, 47, 47),   "Red Checked"),
        5: ((255, 255, 255), (200, 200, 200),  "Unchecked Light"),
        6: ((0, 150, 136),   (0, 121, 107),   "Teal Checked"),
        7: ((255, 152, 0),   (245, 124, 0),   "Orange Checked"),
    },
    # Dropdown stilleri
    6: {
        0: ((255, 255, 255), (120, 120, 120), "Select"),
        1: ((255, 255, 255), (120, 120, 120), "Category"),
        2: ((255, 255, 255), (120, 120, 120), "Country"),
        3: ((255, 255, 255), (120, 120, 120), "Language"),
        4: ((245, 245, 245), (100, 100, 100), "Sort by"),
        5: ((255, 255, 255), (120, 120, 120), "Filter"),
        6: ((255, 255, 255), (120, 120, 120), "Size"),
        7: ((248, 248, 255), (100, 100, 130), "Options"),
    },
    # Slider stilleri
    7: {
        0: ((0, 188, 212),   (200, 200, 200), "Teal"),
        1: ((33, 150, 243),  (200, 200, 200), "Blue"),
        2: ((76, 175, 80),   (200, 200, 200), "Green"),
        3: ((255, 152, 0),   (200, 200, 200), "Orange"),
        4: ((244, 67, 54),   (200, 200, 200), "Red"),
        5: ((156, 39, 176),  (200, 200, 200), "Purple"),
        6: ((233, 30, 99),   (200, 200, 200), "Pink"),
        7: ((55, 55, 65),    (180, 180, 180), "Dark"),
    },
    # Toggle stilleri
    8: {
        0: ((76, 175, 80),   (255, 255, 255), "Green ON"),
        1: ((33, 150, 243),  (255, 255, 255), "Blue ON"),
        2: ((200, 200, 200), (255, 255, 255), "Gray OFF"),
        3: ((156, 39, 176),  (255, 255, 255), "Purple ON"),
        4: ((255, 152, 0),   (255, 255, 255), "Orange ON"),
        5: ((180, 180, 180), (255, 255, 255), "Light OFF"),
        6: ((0, 150, 136),   (255, 255, 255), "Teal ON"),
        7: ((244, 67, 54),   (255, 255, 255), "Red ON"),
    },
    # Image stilleri
    9: {
        0: ((220, 225, 230), (180, 190, 200), "Landscape"),
        1: ((230, 220, 220), (200, 180, 180), "Portrait"),
        2: ((220, 230, 220), (180, 200, 180), "Nature"),
        3: ((225, 225, 235), (190, 190, 210), "Abstract"),
        4: ((235, 230, 220), (210, 200, 180), "Product"),
        5: ((215, 225, 235), (170, 190, 210), "Urban"),
        6: ((230, 225, 215), (200, 190, 170), "Food"),
        7: ((220, 220, 230), (185, 185, 200), "Camera"),
    },
}

IMAGE_SIZE = 64
IMAGE_CHANNELS = 3

# ==============================================================================
# Çıktı Dizinleri
# ==============================================================================
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")
CHECKPOINT_DIR = os.path.join(OUTPUT_DIR, "checkpoints")
FIGURES_DIR = os.path.join(OUTPUT_DIR, "figures")
SAMPLES_DIR = os.path.join(OUTPUT_DIR, "samples")

for d in [DATA_DIR, OUTPUT_DIR, CHECKPOINT_DIR, FIGURES_DIR, SAMPLES_DIR]:
    os.makedirs(d, exist_ok=True)
